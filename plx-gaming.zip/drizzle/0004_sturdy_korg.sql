ALTER TABLE `tournaments` MODIFY COLUMN `status` enum('draft','upcoming','live','completed','closed','cancelled') NOT NULL DEFAULT 'draft';--> statement-breakpoint
ALTER TABLE `tournaments` ADD `bannerUrl` text;--> statement-breakpoint
ALTER TABLE `tournaments` ADD `game` varchar(64) DEFAULT 'Free Fire' NOT NULL;--> statement-breakpoint
ALTER TABLE `tournaments` ADD `registrationOpen` boolean DEFAULT true NOT NULL;--> statement-breakpoint
ALTER TABLE `tournaments` ADD `matchId` varchar(128);--> statement-breakpoint
ALTER TABLE `tournaments` ADD `instructions` text;--> statement-breakpoint
ALTER TABLE `tournaments` ADD `roomCredentialsPublished` boolean DEFAULT false NOT NULL;