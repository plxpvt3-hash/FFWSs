CREATE TABLE `telegramDigitalProductPurchases` (
	`id` int AUTO_INCREMENT NOT NULL,
	`productId` int NOT NULL,
	`userId` int NOT NULL,
	`priceCredits` int NOT NULL,
	`deliveredAt` timestamp NOT NULL DEFAULT (now()),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `telegramDigitalProductPurchases_id` PRIMARY KEY(`id`),
	CONSTRAINT `telegram_product_purchase_user_product_unique` UNIQUE(`productId`,`userId`)
);
--> statement-breakpoint
CREATE TABLE `telegramDigitalProducts` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(120) NOT NULL,
	`description` varchar(500),
	`priceCredits` int NOT NULL,
	`deliveryUrl` text NOT NULL,
	`isActive` boolean NOT NULL DEFAULT true,
	`createdBy` int NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `telegramDigitalProducts_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `telegramLinkCodes` (
	`id` int AUTO_INCREMENT NOT NULL,
	`codeHash` varchar(64) NOT NULL,
	`userId` int NOT NULL,
	`expiresAt` timestamp NOT NULL,
	`usedAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `telegramLinkCodes_id` PRIMARY KEY(`id`),
	CONSTRAINT `telegramLinkCodes_codeHash_unique` UNIQUE(`codeHash`)
);
--> statement-breakpoint
CREATE TABLE `telegramPublicAccounts` (
	`id` int AUTO_INCREMENT NOT NULL,
	`telegramUserId` varchar(32) NOT NULL,
	`plxUserId` int,
	`username` varchar(64),
	`firstName` varchar(128),
	`referralCode` varchar(32) NOT NULL,
	`referredByTelegramUserId` varchar(32),
	`referralRewardGranted` boolean NOT NULL DEFAULT false,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `telegramPublicAccounts_id` PRIMARY KEY(`id`),
	CONSTRAINT `telegramPublicAccounts_telegramUserId_unique` UNIQUE(`telegramUserId`),
	CONSTRAINT `telegramPublicAccounts_plxUserId_unique` UNIQUE(`plxUserId`),
	CONSTRAINT `telegramPublicAccounts_referralCode_unique` UNIQUE(`referralCode`)
);
--> statement-breakpoint
CREATE TABLE `telegramPublicActionStates` (
	`id` int AUTO_INCREMENT NOT NULL,
	`telegramUserId` varchar(32) NOT NULL,
	`action` enum('redeem') NOT NULL,
	`expiresAt` timestamp NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `telegramPublicActionStates_id` PRIMARY KEY(`id`),
	CONSTRAINT `telegramPublicActionStates_telegramUserId_unique` UNIQUE(`telegramUserId`)
);
--> statement-breakpoint
CREATE TABLE `telegramRedeemClaims` (
	`id` int AUTO_INCREMENT NOT NULL,
	`redeemCodeId` int NOT NULL,
	`telegramUserId` varchar(32) NOT NULL,
	`userId` int NOT NULL,
	`creditsAwarded` int NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `telegramRedeemClaims_id` PRIMARY KEY(`id`),
	CONSTRAINT `telegram_redeem_claim_code_telegram_unique` UNIQUE(`redeemCodeId`,`telegramUserId`),
	CONSTRAINT `telegram_redeem_claim_code_user_unique` UNIQUE(`redeemCodeId`,`userId`)
);
--> statement-breakpoint
CREATE TABLE `telegramRedeemCodes` (
	`id` int AUTO_INCREMENT NOT NULL,
	`code` varchar(64) NOT NULL,
	`rewardCredits` int NOT NULL,
	`maxRedemptions` int NOT NULL DEFAULT 1,
	`redemptionCount` int NOT NULL DEFAULT 0,
	`isActive` boolean NOT NULL DEFAULT true,
	`expiresAt` timestamp,
	`createdBy` int NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `telegramRedeemCodes_id` PRIMARY KEY(`id`),
	CONSTRAINT `telegramRedeemCodes_code_unique` UNIQUE(`code`)
);
--> statement-breakpoint
ALTER TABLE `telegramDigitalProductPurchases` ADD CONSTRAINT `telegramDigitalProductPurchases_productId_telegramDigitalProducts_id_fk` FOREIGN KEY (`productId`) REFERENCES `telegramDigitalProducts`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `telegramDigitalProductPurchases` ADD CONSTRAINT `telegramDigitalProductPurchases_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `telegramDigitalProducts` ADD CONSTRAINT `telegramDigitalProducts_createdBy_users_id_fk` FOREIGN KEY (`createdBy`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `telegramLinkCodes` ADD CONSTRAINT `telegramLinkCodes_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `telegramPublicAccounts` ADD CONSTRAINT `telegramPublicAccounts_plxUserId_users_id_fk` FOREIGN KEY (`plxUserId`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `telegramRedeemClaims` ADD CONSTRAINT `telegramRedeemClaims_redeemCodeId_telegramRedeemCodes_id_fk` FOREIGN KEY (`redeemCodeId`) REFERENCES `telegramRedeemCodes`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `telegramRedeemClaims` ADD CONSTRAINT `telegramRedeemClaims_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `telegramRedeemCodes` ADD CONSTRAINT `telegramRedeemCodes_createdBy_users_id_fk` FOREIGN KEY (`createdBy`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
CREATE INDEX `telegram_product_purchase_user_created_idx` ON `telegramDigitalProductPurchases` (`userId`,`createdAt`);--> statement-breakpoint
CREATE INDEX `telegram_product_active_created_idx` ON `telegramDigitalProducts` (`isActive`,`createdAt`);--> statement-breakpoint
CREATE INDEX `telegram_link_code_user_expiry_idx` ON `telegramLinkCodes` (`userId`,`expiresAt`);--> statement-breakpoint
CREATE INDEX `telegram_public_referrer_idx` ON `telegramPublicAccounts` (`referredByTelegramUserId`);--> statement-breakpoint
CREATE INDEX `telegram_public_plx_user_idx` ON `telegramPublicAccounts` (`plxUserId`);--> statement-breakpoint
CREATE INDEX `telegram_public_action_expiry_idx` ON `telegramPublicActionStates` (`expiresAt`);--> statement-breakpoint
CREATE INDEX `telegram_redeem_claim_user_created_idx` ON `telegramRedeemClaims` (`userId`,`createdAt`);--> statement-breakpoint
CREATE INDEX `telegram_redeem_active_expiry_idx` ON `telegramRedeemCodes` (`isActive`,`expiresAt`);