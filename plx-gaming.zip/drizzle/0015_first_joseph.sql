ALTER TABLE `supportTickets` DROP FOREIGN KEY `st_tg_admin_fk`;
--> statement-breakpoint
ALTER TABLE `supportTickets` DROP COLUMN `assignedTelegramAdminId`;--> statement-breakpoint
DROP TABLE `telegramDigitalProductPurchases`;--> statement-breakpoint
DROP TABLE `telegramRedeemClaims`;--> statement-breakpoint
DROP TABLE `telegramDigitalProducts`;--> statement-breakpoint
DROP TABLE `telegramLinkCodes`;--> statement-breakpoint
DROP TABLE `telegramPublicAccounts`;--> statement-breakpoint
DROP TABLE `telegramPublicActionStates`;--> statement-breakpoint
DROP TABLE `telegramRedeemCodes`;--> statement-breakpoint
DROP TABLE `telegramWebhookUpdates`;--> statement-breakpoint
DROP TABLE `telegramAdminAccounts`;
