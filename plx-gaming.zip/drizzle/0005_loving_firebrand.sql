ALTER TABLE `tournamentEntries` ADD `playerNickname` varchar(32);--> statement-breakpoint
ALTER TABLE `tournamentEntries` ADD `playerUid` varchar(32);--> statement-breakpoint
ALTER TABLE `tournamentEntries` ADD CONSTRAINT `entry_tournament_uid_unique` UNIQUE(`tournamentId`,`playerUid`);