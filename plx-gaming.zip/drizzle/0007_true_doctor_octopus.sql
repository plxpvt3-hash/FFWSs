CREATE TABLE `adminAccessSessions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`tokenHash` varchar(64) NOT NULL,
	`expiresAt` timestamp NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`revokedAt` timestamp,
	CONSTRAINT `adminAccessSessions_id` PRIMARY KEY(`id`),
	CONSTRAINT `adminAccessSessions_tokenHash_unique` UNIQUE(`tokenHash`)
);
--> statement-breakpoint
ALTER TABLE `adminAccessSessions` ADD CONSTRAINT `adminAccessSessions_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
CREATE INDEX `admin_access_session_user_expiry_idx` ON `adminAccessSessions` (`userId`,`expiresAt`);