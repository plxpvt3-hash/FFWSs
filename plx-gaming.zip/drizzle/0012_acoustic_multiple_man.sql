CREATE TABLE `supportTicketMessages` (
	`id` int AUTO_INCREMENT NOT NULL,
	`ticketId` int NOT NULL,
	`authorType` enum('player','admin','system') NOT NULL,
	`authorUserId` int,
	`body` text NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `supportTicketMessages_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `supportTickets` (
	`id` int AUTO_INCREMENT NOT NULL,
	`ticketCode` varchar(32) NOT NULL,
	`userId` int,
	`subject` varchar(160) NOT NULL,
	`status` enum('open','pending','resolved','closed') NOT NULL DEFAULT 'open',
	`assignedTelegramAdminId` int,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `supportTickets_id` PRIMARY KEY(`id`),
	CONSTRAINT `supportTickets_ticketCode_unique` UNIQUE(`ticketCode`)
);
--> statement-breakpoint
CREATE TABLE `telegramAdminAccounts` (
	`id` int AUTO_INCREMENT NOT NULL,
	`telegramUserId` varchar(32) NOT NULL,
	`plxAdminUserId` int NOT NULL,
	`role` enum('super_admin','admin','support','moderator') NOT NULL DEFAULT 'admin',
	`isActive` boolean NOT NULL DEFAULT true,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `telegramAdminAccounts_id` PRIMARY KEY(`id`),
	CONSTRAINT `telegramAdminAccounts_telegramUserId_unique` UNIQUE(`telegramUserId`)
);
--> statement-breakpoint
CREATE TABLE `telegramWebhookUpdates` (
	`id` int AUTO_INCREMENT NOT NULL,
	`telegramUpdateId` varchar(32) NOT NULL,
	`receivedAt` timestamp NOT NULL DEFAULT (now()),
	`processedAt` timestamp,
	CONSTRAINT `telegramWebhookUpdates_id` PRIMARY KEY(`id`),
	CONSTRAINT `telegramWebhookUpdates_telegramUpdateId_unique` UNIQUE(`telegramUpdateId`)
);
--> statement-breakpoint
ALTER TABLE `supportTicketMessages` ADD CONSTRAINT `supportTicketMessages_ticketId_supportTickets_id_fk` FOREIGN KEY (`ticketId`) REFERENCES `supportTickets`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `supportTicketMessages` ADD CONSTRAINT `supportTicketMessages_authorUserId_users_id_fk` FOREIGN KEY (`authorUserId`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `supportTickets` ADD CONSTRAINT `supportTickets_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `supportTickets` ADD CONSTRAINT `st_tg_admin_fk` FOREIGN KEY (`assignedTelegramAdminId`) REFERENCES `telegramAdminAccounts`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `telegramAdminAccounts` ADD CONSTRAINT `telegramAdminAccounts_plxAdminUserId_users_id_fk` FOREIGN KEY (`plxAdminUserId`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
CREATE INDEX `support_ticket_message_created_idx` ON `supportTicketMessages` (`ticketId`,`createdAt`);--> statement-breakpoint
CREATE INDEX `support_ticket_status_created_idx` ON `supportTickets` (`status`,`createdAt`);--> statement-breakpoint
CREATE INDEX `support_ticket_user_created_idx` ON `supportTickets` (`userId`,`createdAt`);--> statement-breakpoint
CREATE INDEX `telegram_admin_active_role_idx` ON `telegramAdminAccounts` (`isActive`,`role`);--> statement-breakpoint
CREATE INDEX `telegram_update_received_idx` ON `telegramWebhookUpdates` (`receivedAt`);
