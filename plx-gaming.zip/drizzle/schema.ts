import {
  boolean,
  index,
  int,
  mysqlEnum,
  mysqlTable,
  text,
  timestamp,
  uniqueIndex,
  varchar,
} from "drizzle-orm/mysql-core";

/** Core Manus OAuth user identity, extended with player-profile and access controls. */
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  isBlocked: boolean("isBlocked").default(false).notNull(),
  playerName: varchar("playerName", { length: 64 }),
  gameUid: varchar("gameUid", { length: 32 }),
  avatarUrl: text("avatarUrl"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
}, (table) => [
  uniqueIndex("users_email_unique").on(table.email),
]);

/** Local sign-in secret material. Password hashes are never selected or sent to the client. */
export const localCredentials = mysqlTable("localCredentials", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().unique().references(() => users.id),
  passwordHash: varchar("passwordHash", { length: 255 }).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

/** Opaque, hash-only local session records; raw session tokens exist only in an HTTP-only cookie. */
export const localSessions = mysqlTable("localSessions", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().references(() => users.id),
  tokenHash: varchar("tokenHash", { length: 64 }).notNull().unique(),
  expiresAt: timestamp("expiresAt").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  revokedAt: timestamp("revokedAt"),
}, (table) => [
  index("local_session_user_expiry_idx").on(table.userId, table.expiresAt),
]);

export const wallets = mysqlTable("wallets", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().unique().references(() => users.id),
  balance: int("balance").default(0).notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const tournaments = mysqlTable("tournaments", {
  id: int("id").autoincrement().primaryKey(),
  slug: varchar("slug", { length: 96 }).notNull().unique(),
  name: varchar("name", { length: 128 }).notNull(),
  bannerUrl: text("bannerUrl"),
  game: varchar("game", { length: 64 }).default("Free Fire").notNull(),
  mode: mysqlEnum("mode", ["solo", "duo", "squad"]).notNull(),
  map: varchar("map", { length: 64 }).notNull(),
  startsAt: timestamp("startsAt").notNull(),
  entryFee: int("entryFee").default(0).notNull(),
  prizePool: int("prizePool").default(0).notNull(),
  totalSlots: int("totalSlots").notNull(),
  filledSlots: int("filledSlots").default(0).notNull(),
  registrationOpen: boolean("registrationOpen").default(true).notNull(),
  status: mysqlEnum("status", ["draft", "upcoming", "live", "completed", "closed", "cancelled"])
    .default("draft")
    .notNull(),
  matchId: varchar("matchId", { length: 128 }),
  rules: text("rules"),
  instructions: text("instructions"),
  roomId: varchar("roomId", { length: 128 }),
  roomPassword: varchar("roomPassword", { length: 128 }),
  roomCredentialsPublished: boolean("roomCredentialsPublished").default(false).notNull(),
  resultPublished: boolean("resultPublished").default(false).notNull(),
  createdBy: int("createdBy").references(() => users.id),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => [
  index("tournament_status_starts_idx").on(table.status, table.startsAt),
]);

export const tournamentEntries = mysqlTable("tournamentEntries", {
  id: int("id").autoincrement().primaryKey(),
  tournamentId: int("tournamentId").notNull().references(() => tournaments.id),
  userId: int("userId").notNull().references(() => users.id),
  playerNickname: varchar("playerNickname", { length: 32 }),
  playerUid: varchar("playerUid", { length: 32 }),
  teamName: varchar("teamName", { length: 64 }),
  status: mysqlEnum("status", ["registered", "withdrawn", "disqualified"])
    .default("registered")
    .notNull(),
  joinedAt: timestamp("joinedAt").defaultNow().notNull(),
  rank: int("rank"),
  kills: int("kills").default(0).notNull(),
  score: int("score").default(0).notNull(),
  prizeAwarded: int("prizeAwarded").default(0).notNull(),
  prizeCredited: boolean("prizeCredited").default(false).notNull(),
}, (table) => [
  uniqueIndex("entry_user_tournament_unique").on(table.tournamentId, table.userId),
  uniqueIndex("entry_tournament_uid_unique").on(table.tournamentId, table.playerUid),
  index("entry_tournament_status_idx").on(table.tournamentId, table.status),
  index("entry_user_joined_idx").on(table.userId, table.joinedAt),
]);

export const walletTransactions = mysqlTable("walletTransactions", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().references(() => users.id),
  direction: mysqlEnum("direction", ["credit", "debit"]).notNull(),
  type: mysqlEnum("type", ["credit_purchase", "tournament_entry", "prize_winning", "refund", "admin_adjustment"])
    .notNull(),
  amount: int("amount").notNull(),
  balanceAfter: int("balanceAfter").notNull(),
  referenceType: varchar("referenceType", { length: 40 }),
  referenceId: varchar("referenceId", { length: 64 }),
  note: varchar("note", { length: 240 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (table) => [
  index("wallet_transaction_user_created_idx").on(table.userId, table.createdAt),
]);

export const creditPackages = mysqlTable("creditPackages", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 80 }).notNull(),
  credits: int("credits").notNull(),
  priceInr: int("priceInr").notNull(),
  isActive: boolean("isActive").default(true).notNull(),
  sortOrder: int("sortOrder").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const paymentRequests = mysqlTable("paymentRequests", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().references(() => users.id),
  packageId: int("packageId").notNull().references(() => creditPackages.id),
  creditsRequested: int("creditsRequested").notNull(),
  amountPaid: int("amountPaid").notNull(),
  utr: varchar("utr", { length: 100 }).notNull().unique(),
  screenshotKey: varchar("screenshotKey", { length: 255 }).notNull(),
  screenshotUrl: text("screenshotUrl").notNull(),
  status: mysqlEnum("status", ["pending", "approved", "rejected"])
    .default("pending")
    .notNull(),
  reviewNote: varchar("reviewNote", { length: 240 }),
  reviewedBy: int("reviewedBy").references(() => users.id),
  reviewedAt: timestamp("reviewedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (table) => [
  index("payment_request_status_created_idx").on(table.status, table.createdAt),
  index("payment_request_user_created_idx").on(table.userId, table.createdAt),
]);

export const platformSettings = mysqlTable("platformSettings", {
  id: int("id").autoincrement().primaryKey(),
  settingKey: varchar("settingKey", { length: 80 }).notNull().unique(),
  settingValue: text("settingValue"),
  updatedBy: int("updatedBy").references(() => users.id),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

/** Administrator-managed official PLX social media destinations. */
export const socialProfiles = mysqlTable("socialProfiles", {
  id: int("id").autoincrement().primaryKey(),
  platform: mysqlEnum("platform", ["instagram", "telegram", "youtube", "whatsapp", "facebook", "discord", "twitter"]).notNull().unique(),
  handle: varchar("handle", { length: 128 }).notNull(),
  profileUrl: varchar("profileUrl", { length: 2048 }).notNull(),
  isEnabled: boolean("isEnabled").default(true).notNull(),
  sortOrder: int("sortOrder").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => [
  index("social_profile_enabled_order_idx").on(table.isEnabled, table.sortOrder),
]);

export const announcements = mysqlTable("announcements", {
  id: int("id").autoincrement().primaryKey(),
  message: varchar("message", { length: 280 }).notNull(),
  isActive: boolean("isActive").default(true).notNull(),
  createdBy: int("createdBy").references(() => users.id),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const adminActivity = mysqlTable("adminActivity", {
  id: int("id").autoincrement().primaryKey(),
  actorId: int("actorId").notNull().references(() => users.id),
  action: varchar("action", { length: 96 }).notNull(),
  targetType: varchar("targetType", { length: 48 }).notNull(),
  targetId: varchar("targetId", { length: 64 }),
  details: text("details"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (table) => [
  index("admin_activity_actor_created_idx").on(table.actorId, table.createdAt),
]);

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;
export type Tournament = typeof tournaments.$inferSelect;
export type TournamentEntry = typeof tournamentEntries.$inferSelect;
export type WalletTransaction = typeof walletTransactions.$inferSelect;
