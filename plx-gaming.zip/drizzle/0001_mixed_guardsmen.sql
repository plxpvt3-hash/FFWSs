CREATE TABLE `adminActivity` (
	`id` int AUTO_INCREMENT NOT NULL,
	`actorId` int NOT NULL,
	`action` varchar(96) NOT NULL,
	`targetType` varchar(48) NOT NULL,
	`targetId` varchar(64),
	`details` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `adminActivity_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `announcements` (
	`id` int AUTO_INCREMENT NOT NULL,
	`message` varchar(280) NOT NULL,
	`isActive` boolean NOT NULL DEFAULT true,
	`createdBy` int,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `announcements_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `creditPackages` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(80) NOT NULL,
	`credits` int NOT NULL,
	`priceInr` int NOT NULL,
	`isActive` boolean NOT NULL DEFAULT true,
	`sortOrder` int NOT NULL DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `creditPackages_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `paymentRequests` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`packageId` int NOT NULL,
	`creditsRequested` int NOT NULL,
	`amountPaid` int NOT NULL,
	`utr` varchar(100) NOT NULL,
	`screenshotKey` varchar(255) NOT NULL,
	`screenshotUrl` text NOT NULL,
	`status` enum('pending','approved','rejected') NOT NULL DEFAULT 'pending',
	`reviewNote` varchar(240),
	`reviewedBy` int,
	`reviewedAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `paymentRequests_id` PRIMARY KEY(`id`),
	CONSTRAINT `paymentRequests_utr_unique` UNIQUE(`utr`)
);
--> statement-breakpoint
CREATE TABLE `platformSettings` (
	`id` int AUTO_INCREMENT NOT NULL,
	`settingKey` varchar(80) NOT NULL,
	`settingValue` text,
	`updatedBy` int,
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `platformSettings_id` PRIMARY KEY(`id`),
	CONSTRAINT `platformSettings_settingKey_unique` UNIQUE(`settingKey`)
);
--> statement-breakpoint
CREATE TABLE `tournamentEntries` (
	`id` int AUTO_INCREMENT NOT NULL,
	`tournamentId` int NOT NULL,
	`userId` int NOT NULL,
	`teamName` varchar(64),
	`status` enum('registered','withdrawn','disqualified') NOT NULL DEFAULT 'registered',
	`joinedAt` timestamp NOT NULL DEFAULT (now()),
	`rank` int,
	`kills` int NOT NULL DEFAULT 0,
	`score` int NOT NULL DEFAULT 0,
	`prizeAwarded` int NOT NULL DEFAULT 0,
	`prizeCredited` boolean NOT NULL DEFAULT false,
	CONSTRAINT `tournamentEntries_id` PRIMARY KEY(`id`),
	CONSTRAINT `entry_user_tournament_unique` UNIQUE(`tournamentId`,`userId`)
);
--> statement-breakpoint
CREATE TABLE `tournaments` (
	`id` int AUTO_INCREMENT NOT NULL,
	`slug` varchar(96) NOT NULL,
	`name` varchar(128) NOT NULL,
	`mode` enum('solo','duo','squad') NOT NULL,
	`map` varchar(64) NOT NULL,
	`startsAt` timestamp NOT NULL,
	`entryFee` int NOT NULL DEFAULT 0,
	`prizePool` int NOT NULL DEFAULT 0,
	`totalSlots` int NOT NULL,
	`status` enum('draft','upcoming','live','completed','cancelled') NOT NULL DEFAULT 'draft',
	`rules` text,
	`roomId` varchar(128),
	`roomPassword` varchar(128),
	`resultPublished` boolean NOT NULL DEFAULT false,
	`createdBy` int,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `tournaments_id` PRIMARY KEY(`id`),
	CONSTRAINT `tournaments_slug_unique` UNIQUE(`slug`)
);
--> statement-breakpoint
CREATE TABLE `walletTransactions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`direction` enum('credit','debit') NOT NULL,
	`type` enum('credit_purchase','tournament_entry','prize_winning','refund','admin_adjustment') NOT NULL,
	`amount` int NOT NULL,
	`balanceAfter` int NOT NULL,
	`referenceType` varchar(40),
	`referenceId` varchar(64),
	`note` varchar(240),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `walletTransactions_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `wallets` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`balance` int NOT NULL DEFAULT 0,
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `wallets_id` PRIMARY KEY(`id`),
	CONSTRAINT `wallets_userId_unique` UNIQUE(`userId`)
);
--> statement-breakpoint
ALTER TABLE `users` ADD `isBlocked` boolean DEFAULT false NOT NULL;--> statement-breakpoint
ALTER TABLE `users` ADD `playerName` varchar(64);--> statement-breakpoint
ALTER TABLE `users` ADD `gameUid` varchar(32);--> statement-breakpoint
ALTER TABLE `users` ADD `avatarUrl` text;--> statement-breakpoint
ALTER TABLE `adminActivity` ADD CONSTRAINT `adminActivity_actorId_users_id_fk` FOREIGN KEY (`actorId`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `announcements` ADD CONSTRAINT `announcements_createdBy_users_id_fk` FOREIGN KEY (`createdBy`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `paymentRequests` ADD CONSTRAINT `paymentRequests_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `paymentRequests` ADD CONSTRAINT `paymentRequests_packageId_creditPackages_id_fk` FOREIGN KEY (`packageId`) REFERENCES `creditPackages`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `paymentRequests` ADD CONSTRAINT `paymentRequests_reviewedBy_users_id_fk` FOREIGN KEY (`reviewedBy`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `platformSettings` ADD CONSTRAINT `platformSettings_updatedBy_users_id_fk` FOREIGN KEY (`updatedBy`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `tournamentEntries` ADD CONSTRAINT `tournamentEntries_tournamentId_tournaments_id_fk` FOREIGN KEY (`tournamentId`) REFERENCES `tournaments`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `tournamentEntries` ADD CONSTRAINT `tournamentEntries_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `tournaments` ADD CONSTRAINT `tournaments_createdBy_users_id_fk` FOREIGN KEY (`createdBy`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `walletTransactions` ADD CONSTRAINT `walletTransactions_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `wallets` ADD CONSTRAINT `wallets_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
CREATE INDEX `admin_activity_actor_created_idx` ON `adminActivity` (`actorId`,`createdAt`);--> statement-breakpoint
CREATE INDEX `payment_request_status_created_idx` ON `paymentRequests` (`status`,`createdAt`);--> statement-breakpoint
CREATE INDEX `payment_request_user_created_idx` ON `paymentRequests` (`userId`,`createdAt`);--> statement-breakpoint
CREATE INDEX `entry_tournament_status_idx` ON `tournamentEntries` (`tournamentId`,`status`);--> statement-breakpoint
CREATE INDEX `entry_user_joined_idx` ON `tournamentEntries` (`userId`,`joinedAt`);--> statement-breakpoint
CREATE INDEX `tournament_status_starts_idx` ON `tournaments` (`status`,`startsAt`);--> statement-breakpoint
CREATE INDEX `wallet_transaction_user_created_idx` ON `walletTransactions` (`userId`,`createdAt`);