CREATE TABLE `googleOAuthIdentities` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`googleSubject` varchar(255) NOT NULL,
	`email` varchar(320) NOT NULL,
	`emailVerified` boolean NOT NULL DEFAULT true,
	`linkedAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `googleOAuthIdentities_id` PRIMARY KEY(`id`),
	CONSTRAINT `googleOAuthIdentities_userId_unique` UNIQUE(`userId`),
	CONSTRAINT `googleOAuthIdentities_googleSubject_unique` UNIQUE(`googleSubject`)
);
--> statement-breakpoint
CREATE TABLE `googleOAuthStates` (
	`id` int AUTO_INCREMENT NOT NULL,
	`stateHash` varchar(64) NOT NULL,
	`intent` enum('login','link') NOT NULL,
	`userId` int,
	`nextPath` varchar(512) NOT NULL,
	`expiresAt` timestamp NOT NULL,
	`usedAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `googleOAuthStates_id` PRIMARY KEY(`id`),
	CONSTRAINT `googleOAuthStates_stateHash_unique` UNIQUE(`stateHash`)
);
--> statement-breakpoint
ALTER TABLE `googleOAuthIdentities` ADD CONSTRAINT `googleOAuthIdentities_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `googleOAuthStates` ADD CONSTRAINT `googleOAuthStates_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
CREATE INDEX `google_oauth_email_idx` ON `googleOAuthIdentities` (`email`);--> statement-breakpoint
CREATE INDEX `google_oauth_state_expiry_idx` ON `googleOAuthStates` (`expiresAt`);