CREATE TABLE `withdrawalRequests` (
	`id` int AUTO_INCREMENT NOT NULL,
	`withdrawalCode` varchar(40) NOT NULL,
	`userId` int NOT NULL,
	`activeUserKey` varchar(24),
	`upiId` varchar(160) NOT NULL,
	`amount` int NOT NULL,
	`status` enum('pending','approved','processing','paid','rejected') NOT NULL DEFAULT 'pending',
	`rejectionReason` varchar(240),
	`approvedBy` int,
	`approvedAt` timestamp,
	`processingBy` int,
	`processingAt` timestamp,
	`paidBy` int,
	`paidAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `withdrawalRequests_id` PRIMARY KEY(`id`),
	CONSTRAINT `withdrawalRequests_withdrawalCode_unique` UNIQUE(`withdrawalCode`),
	CONSTRAINT `withdrawalRequests_activeUserKey_unique` UNIQUE(`activeUserKey`)
);
--> statement-breakpoint
CREATE TABLE `withdrawalStatusHistory` (
	`id` int AUTO_INCREMENT NOT NULL,
	`withdrawalRequestId` int NOT NULL,
	`status` enum('pending','approved','processing','paid','rejected') NOT NULL,
	`actorType` enum('player','admin','system') NOT NULL,
	`actorId` int,
	`note` varchar(240),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `withdrawalStatusHistory_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `walletTransactions` MODIFY COLUMN `type` enum('credit_purchase','tournament_entry','prize_winning','refund','admin_adjustment','withdrawal_hold','withdrawal_reversal') NOT NULL;--> statement-breakpoint
ALTER TABLE `walletTransactions` ADD `balanceCategory` enum('credits','winning','bonus') DEFAULT 'credits' NOT NULL;--> statement-breakpoint
ALTER TABLE `wallets` ADD `winningBalance` int DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE `wallets` ADD `bonusBalance` int DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE `withdrawalRequests` ADD CONSTRAINT `withdrawalRequests_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `withdrawalRequests` ADD CONSTRAINT `withdrawalRequests_approvedBy_users_id_fk` FOREIGN KEY (`approvedBy`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `withdrawalRequests` ADD CONSTRAINT `withdrawalRequests_processingBy_users_id_fk` FOREIGN KEY (`processingBy`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `withdrawalRequests` ADD CONSTRAINT `withdrawalRequests_paidBy_users_id_fk` FOREIGN KEY (`paidBy`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `withdrawalStatusHistory` ADD CONSTRAINT `wd_hist_request_fk` FOREIGN KEY (`withdrawalRequestId`) REFERENCES `withdrawalRequests`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `withdrawalStatusHistory` ADD CONSTRAINT `wd_hist_actor_fk` FOREIGN KEY (`actorId`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
CREATE INDEX `withdrawal_status_created_idx` ON `withdrawalRequests` (`status`,`createdAt`);--> statement-breakpoint
CREATE INDEX `withdrawal_user_created_idx` ON `withdrawalRequests` (`userId`,`createdAt`);--> statement-breakpoint
CREATE INDEX `withdrawal_history_request_created_idx` ON `withdrawalStatusHistory` (`withdrawalRequestId`,`createdAt`);
