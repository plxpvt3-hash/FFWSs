ALTER TABLE `telegramDigitalProductPurchases` DROP FOREIGN KEY `telegramDigitalProductPurchases_productId_telegramDigitalProducts_id_fk`;
--> statement-breakpoint
ALTER TABLE `telegramDigitalProductPurchases` DROP FOREIGN KEY `telegramDigitalProductPurchases_userId_users_id_fk`;
--> statement-breakpoint
ALTER TABLE `telegramDigitalProducts` DROP FOREIGN KEY `telegramDigitalProducts_createdBy_users_id_fk`;
--> statement-breakpoint
ALTER TABLE `telegramLinkCodes` DROP FOREIGN KEY `telegramLinkCodes_userId_users_id_fk`;
--> statement-breakpoint
ALTER TABLE `telegramPublicAccounts` DROP FOREIGN KEY `telegramPublicAccounts_plxUserId_users_id_fk`;
--> statement-breakpoint
ALTER TABLE `telegramRedeemClaims` DROP FOREIGN KEY `telegramRedeemClaims_redeemCodeId_telegramRedeemCodes_id_fk`;
--> statement-breakpoint
ALTER TABLE `telegramRedeemClaims` DROP FOREIGN KEY `telegramRedeemClaims_userId_users_id_fk`;
--> statement-breakpoint
ALTER TABLE `telegramRedeemCodes` DROP FOREIGN KEY `telegramRedeemCodes_createdBy_users_id_fk`;
--> statement-breakpoint
ALTER TABLE `telegramDigitalProductPurchases` ADD CONSTRAINT `tdpp_product_fk` FOREIGN KEY (`productId`) REFERENCES `telegramDigitalProducts`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `telegramDigitalProductPurchases` ADD CONSTRAINT `tdpp_user_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `telegramDigitalProducts` ADD CONSTRAINT `tdp_creator_fk` FOREIGN KEY (`createdBy`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `telegramLinkCodes` ADD CONSTRAINT `tlc_user_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `telegramPublicAccounts` ADD CONSTRAINT `tpa_user_fk` FOREIGN KEY (`plxUserId`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `telegramRedeemClaims` ADD CONSTRAINT `trclaim_code_fk` FOREIGN KEY (`redeemCodeId`) REFERENCES `telegramRedeemCodes`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `telegramRedeemClaims` ADD CONSTRAINT `trclaim_user_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `telegramRedeemCodes` ADD CONSTRAINT `trc_creator_fk` FOREIGN KEY (`createdBy`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action;