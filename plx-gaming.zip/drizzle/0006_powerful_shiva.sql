CREATE TABLE `socialProfiles` (
	`id` int AUTO_INCREMENT NOT NULL,
	`platform` enum('instagram','telegram','youtube','whatsapp','facebook','discord','twitter') NOT NULL,
	`handle` varchar(128) NOT NULL,
	`profileUrl` varchar(2048) NOT NULL,
	`isEnabled` boolean NOT NULL DEFAULT true,
	`sortOrder` int NOT NULL DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `socialProfiles_id` PRIMARY KEY(`id`),
	CONSTRAINT `socialProfiles_platform_unique` UNIQUE(`platform`)
);
--> statement-breakpoint
CREATE INDEX `social_profile_enabled_order_idx` ON `socialProfiles` (`isEnabled`,`sortOrder`);