# PLX Telegram Administration Bot Architecture

## Boundary

The Telegram bot is an **alternative administrative interface**, not a privileged host process. It will be exposed only through `POST /api/telegram/webhook`, verify Telegram's webhook secret before accepting updates, and call explicit PLX server services backed by the existing MySQL/TiDB database. It will not execute uploaded files, spawn processes, access the shell, poll continuously, or use a separate SQLite database.

## Identity and authorization

Every update is matched to a server-side `telegram_admin_accounts` record by immutable Telegram numeric user ID. A record is active only when linked to an active PLX administrator/service identity. The allowed roles are `super_admin`, `admin`, `support`, and `moderator`; each command and callback declares its minimum role. An optional bootstrap allowlist is consumed only when no Telegram administrator records exist, then its Telegram IDs are persisted in the table.

| Role | Approved PLX operations |
|---|---|
| `super_admin` | Role administration, settings, all administrative actions, and audit review. |
| `admin` | Users, tournaments, live control, results, payments, withdrawals, bonuses, and broadcasts. |
| `moderator` | Read tournament/player data and update permitted tournament/live/result state; no wallet or payment operations. |
| `support` | Read and update support-ticket workflow only; no wallet, player, or tournament mutation rights. |

## Delivery and duplicate protection

Telegram `update_id` values are stored in `telegram_webhook_updates` under a unique constraint before dispatch. Re-delivered updates therefore cannot re-run financial or status-changing callbacks. High-risk callbacks add a confirmation step and then call the same transactional PLX domain service used by the website administration routes. Payment review, withdrawal review, result publishing, and wallet adjustments retain database status checks, conditional updates, ledgers, and administrator audit activity.

## Conversation model

The bot uses inline menu callbacks for safe read actions and explicit confirmation callbacks for mutations. Text commands provide bounded, auditable pathways for operations that require typed values. Initial commands include `/admin`, `/user <id>`, `/bonus <userId> <amount> <reason>`, `/announce <message>`, `/setting <key> <value>`, `/grant <telegramId> <role>`, and `/revoke <telegramId>`. Administrative mutation commands always produce a confirmation callback before committing.

## Secrets and configuration

`TELEGRAM_BOT_TOKEN`, `TELEGRAM_WEBHOOK_SECRET`, and `TELEGRAM_SUPER_ADMIN_IDS` are server-only project secrets. The source repository contains neither token nor admin IDs. `TELEGRAM_WEBHOOK_URL` is a non-secret deployment configuration used only when registering the webhook. Telegram must be configured to send only `message` and `callback_query` updates to the HTTPS webhook URL with the same secret token.

## User-facing data handling

Bot messages reveal only information permitted by the role. Passwords, session tokens, full UPI destinations, payment proofs, and bot tokens are never transmitted. UPI IDs are masked in withdrawal summaries. The existing website remains the source of truth; the bot never fabricates balances, rankings, live data, or results.
