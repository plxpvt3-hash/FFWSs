# PLX Google OAuth Operations

PLX uses Google’s server-side OAuth 2.0 authorization-code flow. The browser only starts the provider redirect; the authorization code is exchanged on the PLX server using server-only credentials. PLX creates a short-lived, single-use state record and validates it against an HTTP-only cookie before accepting a callback. This prevents callback CSRF and does not store OAuth tokens in browser storage.

## Google Cloud Configuration

Create a **Web application** OAuth client in Google Cloud and register this exact production redirect URI:

```text
https://plxgaming-kov2vkkf.manus.space/api/auth/google/callback
```

Configure `GOOGLE_OAUTH_CLIENT_ID` and `GOOGLE_OAUTH_CLIENT_SECRET` only as server-side project secrets. Do not add either value to Vite environment variables, source code, browser storage, or client logs. Google requires the redirect URI used by the authorization request to exactly match an authorized redirect URI. [1]

## PLX Account Behavior

When Google confirms an email address as verified, PLX links that identity to an existing account with the same email rather than creating a duplicate. New verified Google identities receive a PLX account and profile using the Google name and, when available, profile image. Player-controlled profile updates remain authoritative after that initial synchronization.

Users can connect Google from Profile. They can disconnect it only after a local PLX password exists, ensuring that every disconnected profile retains a safe sign-in and recovery method. PLX local sessions remain opaque, HTTP-only cookies with expiry and logout revocation.

## Verification Checklist

| Check | Expected result |
|---|---|
| Open **Continue with Google** | Google account selection uses `openid email profile` scopes and the configured callback URI. |
| Verified existing email | The existing PLX profile is signed in and gains a single Google identity link. |
| New verified Google email | A new player account receives the Google name and available avatar. |
| Unverified or failed callback | PLX returns a generic authentication error without creating an account or exposing provider details. |
| Unlink Google | PLX rejects the request unless the profile has a local password. |

## Reference

[1] [Google OAuth 2.0 for Web Server Applications](https://developers.google.com/identity/protocols/oauth2/web-server)
