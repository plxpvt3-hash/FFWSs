# PLX Withdrawal System

PLX treats **Tournament Credits**, **winning balance**, and **bonus balance** as separate balance categories. Tournament entry continues to deduct only Tournament Credits. Withdrawal requests are funded solely from the player’s eligible winning balance and are never calculated by the browser.

## Player Flow

1. The signed-in player opens Wallet and reviews the three balance categories.
2. The player enters a whole-number amount and a valid UPI ID or UPI-linked mobile destination.
3. The protected server validates the configured minimum amount, winning-balance availability, and active-request restriction inside a database transaction.
4. The server debits eligible winnings, assigns a unique `WD-…` identifier, and writes append-only ledger and lifecycle-history records.
5. The player sees only their own withdrawal history, status, request time, destination, and rejection reason when applicable.

## Administrator Flow

The code-protected Admin console exposes **Withdrawals** with lifecycle filters and minimum-withdrawal configuration. Only authenticated administrator procedures can advance a request:

| Current state | Permitted next state |
|---|---|
| Pending | Approved or Rejected |
| Approved | Processing or Rejected |
| Processing | Paid or Rejected |
| Paid / Rejected | No further transition |

Rejection requires a reason and returns the previously held eligible winnings through a server-side ledger entry. Every state event is preserved in append-only withdrawal history and administrator audit records. A paid request can never be reopened through the application workflow.

## Security Properties

- Player wallet and withdrawal queries are self-scoped to the authenticated account.
- No balance, payout status, administrator credential, or database credential is client-controlled.
- Request creation, balance deduction, active-request checks, unique request identity, audit entries, and history entries are atomic server-side work.
- Google OAuth, email/password login, code-only Admin Access, the tournament system, and UPI credit top-ups remain independent of payout credentials and lifecycle management.

## Ledger Integrity and Database Verification

The application exposes **no mutation procedure** for `walletTransactions` or `withdrawalStatusHistory`: server operations only insert ledger and lifecycle records. The verified live schema has a unique `withdrawalCode`, a single-active-request unique key (`activeUserKey`), player/status indexes for review queues, and a request-history index for audit retrieval.

PLX runs on TiDB, which does not support SQL triggers or stored procedures; consequently, database trigger-based write rejection is not available. The enforced boundary is the server-side procedure layer: no browser route can update/delete ledger or status-history rows, and all balance mutations occur in a database transaction that records the corresponding entry. [1]

## Reference

[1] [TiDB Architecture FAQs — MySQL Compatibility](https://docs.pingcap.com/tidb/stable/tidb-faq/)
