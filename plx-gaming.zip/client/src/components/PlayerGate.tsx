import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Loader2, LockKeyhole } from "lucide-react";
import { useLocation } from "wouter";

export function PlayerGate({ children }: { children: React.ReactNode }) {
  const [, setLocation] = useLocation();
  const { user, loading } = useAuth();
  if (loading) return <div className="mx-auto grid min-h-[55vh] max-w-md place-items-center px-4 text-center"><div className="w-full rounded-3xl border border-cyan-300/15 bg-[radial-gradient(circle_at_50%_0%,rgba(47,225,255,.1),transparent_55%),#0c1325] p-8 shadow-[0_0_45px_rgba(35,220,255,.04)]"><span className="mx-auto grid h-12 w-12 place-items-center rounded-2xl border border-cyan-300/20 bg-cyan-300/[.07] text-cyan-200"><Loader2 className="h-5 w-5 animate-spin" /></span><p className="mt-5 text-[10px] font-black tracking-[.16em] text-cyan-200">SECURE PLX SESSION</p><p className="mt-2 font-display text-xl font-bold text-white">Preparing your player area</p><p className="mt-2 text-sm leading-6 text-slate-400">Loading your wallet, tournament records, and secure payment options.</p></div></div>;
  if (!user) return <div className="mx-auto grid min-h-[55vh] max-w-md place-items-center px-4 text-center"><div className="rounded-3xl border border-cyan-300/15 bg-[#0c1325] p-8"><span className="mx-auto grid h-12 w-12 place-items-center rounded-2xl bg-cyan-300/10 text-cyan-200"><LockKeyhole size={22} /></span><h1 className="mt-5 font-display text-2xl font-bold text-white">Sign in to your PLX account</h1><p className="mt-3 text-sm leading-6 text-slate-400">Use your PLX email and password to view your player dashboard, Credits wallet, and tournament records.</p><Button onClick={() => setLocation("/auth")} className="mt-6 h-11 w-full rounded-xl bg-cyan-300 font-black tracking-[.08em] text-[#051321]">SIGN IN TO PLX</Button></div></div>;
  return <>{children}</>;
}
