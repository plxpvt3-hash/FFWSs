import { Link } from "wouter";

export function PlxBrand({ compact = false, logoUrl }: { compact?: boolean; logoUrl?: string }) {
  return (
    <Link href="/" className="group inline-flex items-center gap-2.5 rounded-xl outline-none focus-visible:ring-2 focus-visible:ring-violet-300">
      <span className="relative grid h-9 w-9 place-items-center overflow-hidden rounded-[11px] border border-violet-300/45 bg-[#180d2a] shadow-[0_0_24px_rgba(140,76,255,.2)]">
        <span className="absolute inset-[3px] rounded-[8px] border border-violet-400/40" />
        {logoUrl ? <img src={logoUrl} alt="PLX Gaming" className="relative h-full w-full object-cover" /> : <span className="relative font-display text-lg font-black tracking-[-0.18em] text-violet-200">P</span>}
      </span>
      {!compact && (
        <span className="leading-none">
          <span className="block font-display text-lg font-extrabold tracking-[0.12em] text-white">PLX</span>
          <span className="mt-1 block text-[8px] font-bold tracking-[0.28em] text-violet-300/90">TOURNAMENT</span>
        </span>
      )}
    </Link>
  );
}
