import { Link } from "wouter";

export function PlxBrand({ compact = false, logoUrl }: { compact?: boolean; logoUrl?: string }) {
  return (
    <Link href="/" className="group inline-flex items-center gap-2.5 outline-none focus-visible:ring-2 focus-visible:ring-cyan-300 rounded-xl">
      <span className="relative grid h-9 w-9 place-items-center overflow-hidden rounded-[11px] border border-cyan-300/45 bg-[#0d1931] shadow-[0_0_24px_rgba(35,220,255,.18)]">
        <span className="absolute inset-[3px] rounded-[8px] border border-violet-400/40" />
        {logoUrl ? <img src={logoUrl} alt="PLX Gaming" className="relative h-full w-full object-cover" /> : <span className="relative font-display text-lg font-black tracking-[-0.18em] text-cyan-200">P</span>}
      </span>
      {!compact && (
        <span className="leading-none">
          <span className="block font-display text-lg font-extrabold tracking-[0.12em] text-white">PLX</span>
          <span className="block mt-1 text-[8px] font-bold tracking-[0.28em] text-cyan-300/80">GAMING</span>
        </span>
      )}
    </Link>
  );
}
