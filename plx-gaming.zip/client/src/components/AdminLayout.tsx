import DashboardLayout, { DashboardNavItem } from "@/components/DashboardLayout";
import { PlxBrand } from "@/components/PlxBrand";
import { Button } from "@/components/ui/button";
import { Activity, CreditCard, Landmark, LayoutDashboard, LogOut, ReceiptText, Settings2, Share2, ShieldAlert, Sparkles, Swords, Trophy, UsersRound } from "lucide-react";
import { Link } from "wouter";
import React, { useState, type ReactNode } from "react";
import { toast } from "sonner";
import { Input } from "@/components/ui/input";
import { trpc } from "@/lib/trpc";

const items: DashboardNavItem[] = [
  { icon: LayoutDashboard, label: "Overview", path: "/admin" },
  { icon: Sparkles, label: "Home Content", path: "/admin/home" },
  { icon: Swords, label: "Tournaments", path: "/admin/tournaments" },
  { icon: UsersRound, label: "Players", path: "/admin/users" },
  { icon: UsersRound, label: "Participants", path: "/admin/participants" },
  { icon: ReceiptText, label: "Payments", path: "/admin/payments" },
  { icon: Landmark, label: "Withdrawals", path: "/admin/withdrawals" },
  { icon: Trophy, label: "Results", path: "/admin/results" },
  { icon: Trophy, label: "Leaderboard", path: "/admin/leaderboard" },
  { icon: CreditCard, label: "Credits", path: "/admin/packages" },
  { icon: Share2, label: "Social Media", path: "/admin/social" },
  { icon: Settings2, label: "Settings", path: "/admin/settings" },
];

export function AdminGate({ children }: { children: ReactNode }) {
  const [isLoggingOut, setIsLoggingOut] = useState(false);
  const [code, setCode] = useState("");
  const status = trpc.adminAuth.status.useQuery();
  const login = trpc.adminAuth.login.useMutation({ onSuccess: () => void status.refetch(), onError: (error) => toast.error(error.message || "Invalid admin code") });
  const adminLogout = trpc.adminAuth.logout.useMutation({ onSuccess: () => void status.refetch() });

  const endAdministratorSession = async () => {
    setIsLoggingOut(true);
    try {
      await adminLogout.mutateAsync();
      toast.success("Administrator session ended");
    } catch {
      toast.error("Unable to sign out securely. Please try again.");
    } finally {
      setIsLoggingOut(false);
    }
  };

  if (status.isLoading) return <div className="grid min-h-screen place-items-center bg-[#070b16]"><Activity className="h-7 w-7 animate-spin text-violet-200" /></div>;
  if (!status.data?.verified) return <div className="grid min-h-screen place-items-center bg-[#070b16] px-4"><form onSubmit={(event) => { event.preventDefault(); login.mutate({ code }); }} className="w-full max-w-md rounded-3xl border border-violet-200/20 bg-[#0c1325] p-8 shadow-[0_0_70px_rgba(137,80,255,.18)]"><div className="mx-auto grid h-12 w-12 place-items-center rounded-2xl border border-violet-200/25 bg-violet-300/10"><ShieldAlert className="h-6 w-6 text-violet-200" /></div><p className="mt-6 text-center text-[10px] font-black tracking-[.22em] text-violet-200">PLX GAMING CONTROL</p><h1 className="mt-2 text-center font-display text-3xl font-bold text-white">Admin Access</h1><p className="mt-3 text-center text-sm text-slate-400">Enter the administrator login code to continue.</p><label className="mt-7 block text-[10px] font-black tracking-[.14em] text-slate-300">ENTER ADMIN CODE</label><Input value={code} onChange={(event) => setCode(event.target.value)} inputMode="numeric" autoComplete="one-time-code" className="mt-2 h-12 border-violet-200/20 bg-[#07101f] text-center text-lg tracking-[.35em] text-white" /><Button type="submit" disabled={login.isPending || !code} className="mt-5 h-12 w-full bg-gradient-to-r from-violet-500 to-fuchsia-500 font-black tracking-[.14em] text-white">{login.isPending ? "VERIFYING" : "LOGIN"}</Button></form></div>;
  return <DashboardLayout items={items} title="PLX CONTROL"><div className="mb-7 flex flex-wrap items-center justify-between gap-3 border-b border-violet-200/[.10] pb-5"><div className="flex items-center gap-3"><PlxBrand /><span className="rounded-full border border-violet-300/20 bg-violet-300/[.09] px-2.5 py-1 text-[9px] font-black tracking-[.13em] text-violet-100">ADMIN CONSOLE</span></div><div className="flex items-center gap-3"><Link href="/" className="text-xs font-bold text-slate-400 transition hover:text-violet-100">VIEW PLAYER SITE</Link><Button onClick={() => void endAdministratorSession()} disabled={isLoggingOut} variant="outline" className="h-9 border-rose-300/20 bg-rose-300/[.05] px-3 text-[10px] font-black tracking-[.1em] text-rose-100 hover:bg-rose-300/[.12]"><LogOut className="mr-1.5 h-3.5 w-3.5" />{isLoggingOut ? "SIGNING OUT" : "ADMIN LOGOUT"}</Button></div></div>{children}</DashboardLayout>;
}

function AdminMessage({ title, description, action, href, onClick }: { title: string; description: string; action: string; href?: string; onClick?: () => void }) { return <div className="grid min-h-screen place-items-center bg-[#070b16] px-4 text-center"><div className="max-w-md rounded-3xl border border-rose-300/15 bg-[#0c1325] p-8"><ShieldAlert className="mx-auto h-10 w-10 text-rose-200" /><h1 className="mt-5 font-display text-2xl font-bold text-white">{title}</h1><p className="mt-3 text-sm leading-6 text-slate-400">{description}</p>{href ? <Link href={href}><Button className="mt-6 bg-gradient-to-r from-violet-500 to-fuchsia-500 font-black text-white">{action}</Button></Link> : <Button onClick={onClick} className="mt-6 bg-gradient-to-r from-violet-500 to-fuchsia-500 font-black text-white">{action}</Button>}</div></div>; }
