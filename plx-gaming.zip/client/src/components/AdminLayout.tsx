import DashboardLayout, { DashboardNavItem } from "@/components/DashboardLayout";
import { PlxBrand } from "@/components/PlxBrand";
import { useAuth } from "@/_core/hooks/useAuth";
import { startLogin } from "@/const";
import { Button } from "@/components/ui/button";
import { Activity, CreditCard, LayoutDashboard, Megaphone, ReceiptText, Settings2, Share2, ShieldAlert, Sparkles, Swords, Trophy, UsersRound } from "lucide-react";
import { Link } from "wouter";

const items: DashboardNavItem[] = [
  { icon: LayoutDashboard, label: "Overview", path: "/admin" },
  { icon: Sparkles, label: "Home Content", path: "/admin/home" },
  { icon: Swords, label: "Tournaments", path: "/admin/tournaments" },
  { icon: UsersRound, label: "Players", path: "/admin/users" },
  { icon: UsersRound, label: "Participants", path: "/admin/participants" },
  { icon: ReceiptText, label: "Payments", path: "/admin/payments" },
  { icon: Trophy, label: "Results", path: "/admin/results" },
  { icon: Trophy, label: "Leaderboard", path: "/admin/leaderboard" },
  { icon: CreditCard, label: "Credits", path: "/admin/packages" },
  { icon: Share2, label: "Social Media", path: "/admin/social" },
  { icon: Settings2, label: "Settings", path: "/admin/settings" },
];

export function AdminGate({ children }: { children: React.ReactNode }) {
  const { user, loading } = useAuth();
  if (loading) return <div className="grid min-h-screen place-items-center bg-[#070b16]"><Activity className="h-7 w-7 animate-spin text-cyan-200" /></div>;
  if (!user) return <AdminMessage title="Administrator sign-in required" description="Use the owner-authorized Manus account to access PLX administration." action="SIGN IN" onClick={() => startLogin()} />;
  if (user.role !== "admin") return <AdminMessage title="Administrator access only" description="This console is protected. Your current PLX account does not have the required role." action="RETURN TO PLX" href="/" />;
  return <DashboardLayout items={items} title="PLX CONTROL"><div className="mb-7 flex flex-wrap items-center justify-between gap-3 border-b border-white/[.07] pb-5"><div className="flex items-center gap-3"><PlxBrand /><span className="rounded-full border border-violet-300/20 bg-violet-300/[.09] px-2.5 py-1 text-[9px] font-black tracking-[.13em] text-violet-100">ADMIN CONSOLE</span></div><Link href="/" className="text-xs font-bold text-slate-400 transition hover:text-cyan-200">VIEW PLAYER SITE</Link></div>{children}</DashboardLayout>;
}

function AdminMessage({ title, description, action, href, onClick }: { title: string; description: string; action: string; href?: string; onClick?: () => void }) { return <div className="grid min-h-screen place-items-center bg-[#070b16] px-4 text-center"><div className="max-w-md rounded-3xl border border-rose-300/15 bg-[#0c1325] p-8"><ShieldAlert className="mx-auto h-10 w-10 text-rose-200" /><h1 className="mt-5 font-display text-2xl font-bold text-white">{title}</h1><p className="mt-3 text-sm leading-6 text-slate-400">{description}</p>{href ? <Link href={href}><Button className="mt-6 bg-cyan-300 font-black text-[#051321]">{action}</Button></Link> : <Button onClick={onClick} className="mt-6 bg-cyan-300 font-black text-[#051321]">{action}</Button>}</div></div>; }
