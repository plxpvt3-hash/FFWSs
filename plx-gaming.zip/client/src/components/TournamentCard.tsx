import { Badge } from "@/components/ui/badge";
import { formatCredits, formatDateShort, titleCase } from "@/lib/format";
import { CalendarClock, Gamepad2, MapPinned, UsersRound } from "lucide-react";
import { useEffect, useState } from "react";
import { Link } from "wouter";
import { JoinTournamentButton } from "./JoinTournamentButton";

export type TournamentCardItem = {
  id: number; slug: string; name: string; bannerUrl?: string | null; game?: string; mode: "solo" | "duo" | "squad"; map: string; startsAt: Date | string; entryFee: number; prizePool: number; totalSlots: number; filledSlots: number; remainingSlots: number; status: "draft" | "upcoming" | "live" | "completed" | "closed" | "cancelled"; registrationOpen: boolean; hasJoined?: boolean;
};

function Countdown({ startsAt, status }: { startsAt: Date | string; status: string }) {
  const [now, setNow] = useState(Date.now());
  useEffect(() => { const timer = window.setInterval(() => setNow(Date.now()), 1000); return () => window.clearInterval(timer); }, []);
  if (status === "live") return <span className="text-emerald-300">LIVE NOW</span>;
  if (status !== "upcoming") return <span>{titleCase(status)}</span>;
  const distance = Math.max(0, new Date(startsAt).getTime() - now);
  const hours = Math.floor(distance / 3_600_000);
  const minutes = Math.floor((distance % 3_600_000) / 60_000);
  const seconds = Math.floor((distance % 60_000) / 1000);
  return <span>{distance ? `${String(hours).padStart(2, "0")}:${String(minutes).padStart(2, "0")}:${String(seconds).padStart(2, "0")}` : "STARTING"}</span>;
}

const statusTone: Record<string, string> = { upcoming: "border-cyan-300/25 bg-cyan-300/10 text-cyan-200", live: "border-emerald-300/25 bg-emerald-300/10 text-emerald-200", completed: "border-violet-300/25 bg-violet-300/10 text-violet-200", closed: "border-orange-300/25 bg-orange-300/10 text-orange-200", cancelled: "border-rose-300/25 bg-rose-300/10 text-rose-200", draft: "border-slate-300/20 bg-slate-300/10 text-slate-300" };

export function TournamentCard({ tournament, featured = false }: { tournament: TournamentCardItem; featured?: boolean }) {
  const filled = Math.min(100, Math.round((tournament.filledSlots / tournament.totalSlots) * 100));
  return <article className={`group relative overflow-hidden rounded-2xl border border-white/[.09] bg-[#0d1426]/92 transition duration-300 hover:-translate-y-1 hover:border-cyan-300/25 hover:shadow-[0_18px_45px_rgba(0,0,0,.28)] ${featured ? "ring-1 ring-cyan-300/10" : ""}`}>
    <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-cyan-300/60 to-transparent opacity-0 transition group-hover:opacity-100" />
    <div className="relative h-24 overflow-hidden bg-[linear-gradient(110deg,rgba(20,76,104,.55),rgba(23,19,58,.5)),radial-gradient(circle_at_82%_35%,rgba(255,137,34,.35),transparent_30%)] p-4">{tournament.bannerUrl ? <img src={tournament.bannerUrl} alt="" className="absolute inset-0 h-full w-full object-cover opacity-40" /> : null}<div className="absolute inset-0 bg-[linear-gradient(110deg,rgba(7,11,22,.45),rgba(15,18,40,.7))]" />
      <div className="absolute -right-4 -top-8 h-28 w-28 rounded-full border border-cyan-300/10" /><div className="absolute right-7 top-4 grid h-14 w-14 place-items-center rounded-2xl border border-white/10 bg-[#0b1222]/75 text-cyan-200 shadow-lg"><Gamepad2 size={27} /></div>
      <div className="relative flex items-center gap-2"><Badge className={`border px-2 py-1 text-[10px] font-extrabold tracking-[.12em] ${statusTone[tournament.status]}`}>{tournament.status.toUpperCase()}</Badge><span className="rounded-md bg-black/20 px-2 py-1 text-[10px] font-bold uppercase tracking-widest text-slate-200">{tournament.game || "FREE FIRE"}</span></div>
    </div>
    <div className="p-4 pt-3">
      <Link href={`/tournaments/${tournament.slug}`} className="block outline-none focus-visible:ring-2 focus-visible:ring-cyan-300 rounded-lg"><h3 className="truncate font-display text-xl font-bold tracking-wide text-white transition group-hover:text-cyan-200">{tournament.name}</h3></Link>
      <div className="mt-2 flex items-center gap-3 text-xs font-semibold text-slate-400"><span className="inline-flex items-center gap-1.5"><UsersRound size={14} className="text-violet-300" />{titleCase(tournament.mode)}</span><span className="inline-flex items-center gap-1.5"><MapPinned size={14} className="text-orange-300" />{tournament.map}</span></div>
      <div className="mt-4 grid grid-cols-2 overflow-hidden rounded-xl border border-white/[.07] bg-black/15"><div className="border-r border-white/[.07] p-3"><p className="text-[9px] font-bold uppercase tracking-[.14em] text-slate-500">Prize Pool</p><p className="mt-1 font-display text-lg font-bold text-orange-200">{formatCredits(tournament.prizePool)} <span className="text-[10px] tracking-normal text-orange-300/70">CR</span></p></div><div className="p-3"><p className="text-[9px] font-bold uppercase tracking-[.14em] text-slate-500">Entry Fee</p><p className="mt-1 font-display text-lg font-bold text-cyan-100">{formatCredits(tournament.entryFee)} <span className="text-[10px] tracking-normal text-cyan-300/70">CR</span></p></div></div>
      <div className="mt-4 space-y-2"><div className="flex items-center justify-between text-[11px] font-semibold"><span className="inline-flex items-center gap-1.5 text-slate-400"><CalendarClock size={13} className="text-cyan-300" />{formatDateShort(tournament.startsAt)}</span><span className="text-slate-400"><span className="text-cyan-200">{tournament.remainingSlots}</span> / {tournament.totalSlots} slots</span></div><div className="h-1.5 overflow-hidden rounded-full bg-white/[.06]"><div className="h-full rounded-full bg-gradient-to-r from-cyan-300 via-sky-400 to-violet-400" style={{ width: `${filled}%` }} /></div></div>
      <div className="mt-4 flex items-center gap-3"><div className="min-w-0 flex-1 rounded-lg border border-white/[.07] bg-white/[.025] px-2.5 py-2 text-center font-display text-xs font-bold tracking-wider text-slate-300"><Countdown startsAt={tournament.startsAt} status={tournament.status} /></div><JoinTournamentButton tournament={tournament} joined={tournament.hasJoined} className="min-w-32 rounded-lg bg-gradient-to-r from-cyan-300 to-sky-400 text-[10px] font-extrabold tracking-[.06em] text-[#051321] hover:brightness-110" /></div>
    </div>
  </article>;
}
