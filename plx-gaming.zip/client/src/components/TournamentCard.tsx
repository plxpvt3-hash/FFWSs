import { Badge } from "@/components/ui/badge";
import { formatCredits, formatDateShort, titleCase } from "@/lib/format";
import { ArrowRight, CalendarClock, Gamepad2, MapPinned, UsersRound } from "lucide-react";
import { useEffect, useState } from "react";
import { Link } from "wouter";
import { JoinTournamentButton } from "./JoinTournamentButton";

export type TournamentCardItem = {
  id: number; slug: string; name: string; bannerUrl?: string | null; game?: string; mode: "solo" | "duo" | "squad"; map: string; startsAt: Date | string; entryFee: number; prizePool: number; totalSlots: number; filledSlots: number; remainingSlots: number; status: "draft" | "upcoming" | "live" | "completed" | "closed" | "cancelled"; registrationOpen: boolean; hasJoined?: boolean;
};

function Countdown({ startsAt, status }: { startsAt: Date | string; status: string }) {
  const [now, setNow] = useState(Date.now());
  useEffect(() => { const timer = window.setInterval(() => setNow(Date.now()), 1000); return () => window.clearInterval(timer); }, []);
  if (status === "live") return <span className="text-emerald-300">LIVE NOW</span>;
  if (status !== "upcoming") return <span>{titleCase(status)}</span>;
  const distance = Math.max(0, new Date(startsAt).getTime() - now);
  const hours = Math.floor(distance / 3_600_000);
  const minutes = Math.floor((distance % 3_600_000) / 60_000);
  const seconds = Math.floor((distance % 60_000) / 1000);
  return <span>{distance ? `${String(hours).padStart(2, "0")}:${String(minutes).padStart(2, "0")}:${String(seconds).padStart(2, "0")}` : "STARTING"}</span>;
}

const statusTone: Record<string, string> = { upcoming: "border-violet-300/30 bg-violet-300/12 text-violet-100", live: "border-rose-300/35 bg-rose-400/12 text-rose-100", completed: "border-cyan-300/25 bg-cyan-300/10 text-cyan-100", full: "border-amber-300/30 bg-amber-300/10 text-amber-100", closed: "border-amber-300/30 bg-amber-300/10 text-amber-100", cancelled: "border-rose-300/25 bg-rose-300/10 text-rose-200", draft: "border-slate-300/20 bg-slate-300/10 text-slate-300" };

export function TournamentCard({ tournament, featured = false }: { tournament: TournamentCardItem; featured?: boolean }) {
  const filled = Math.min(100, Math.round((tournament.filledSlots / tournament.totalSlots) * 100));
  const displayStatus = tournament.remainingSlots <= 0 && tournament.status === "upcoming" ? "full" : tournament.status;
  return <article className={`group relative overflow-hidden rounded-[1.5rem] border border-violet-200/[.14] bg-[#100a1d]/96 transition duration-300 hover:-translate-y-1 hover:border-violet-200/[.32] hover:shadow-[0_22px_55px_rgba(45,17,93,.34)] ${featured ? "ring-1 ring-violet-300/20" : ""}`}>
    <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-fuchsia-300/70 to-transparent opacity-0 transition group-hover:opacity-100" />
    <div className="relative h-32 overflow-hidden bg-[linear-gradient(120deg,rgba(83,33,172,.68),rgba(30,13,56,.58)),radial-gradient(circle_at_85%_20%,rgba(236,72,153,.38),transparent_30%)] p-4">{tournament.bannerUrl ? <img src={tournament.bannerUrl} alt="" className="absolute inset-0 h-full w-full object-cover opacity-55" /> : null}<div className="absolute inset-0 bg-[linear-gradient(120deg,rgba(10,5,22,.36),rgba(16,7,31,.72))]" />
      <div className="absolute -right-4 -top-8 h-32 w-32 rounded-full border border-fuchsia-300/15" /><div className="absolute right-5 top-5 grid h-14 w-14 place-items-center rounded-2xl border border-violet-100/15 bg-[#130a27]/70 text-violet-100 shadow-[0_0_24px_rgba(189,163,255,.13)]"><Gamepad2 size={27} /></div>
      <div className="relative flex items-center gap-2"><Badge className={`border px-2 py-1 text-[9px] font-extrabold tracking-[.14em] ${statusTone[displayStatus]}`}>{displayStatus === "full" ? "FULL" : displayStatus.toUpperCase()}</Badge><span className="rounded-md bg-black/25 px-2 py-1 text-[9px] font-bold uppercase tracking-widest text-slate-100">{tournament.game || "FREE FIRE"}</span></div>
    </div>
    <div className="p-4 pt-3">
      <Link href={`/tournaments/${tournament.slug}`} className="block outline-none focus-visible:ring-2 focus-visible:ring-violet-300 rounded-lg"><h3 className="truncate font-display text-xl font-bold tracking-wide text-white transition group-hover:text-violet-100">{tournament.name}</h3></Link>
      <div className="mt-2 flex items-center gap-3 text-xs font-semibold text-slate-400"><span className="inline-flex items-center gap-1.5"><UsersRound size={14} className="text-violet-300" />{titleCase(tournament.mode)}</span><span className="inline-flex items-center gap-1.5"><MapPinned size={14} className="text-fuchsia-300" />{tournament.map}</span></div>
      <div className="mt-4 grid grid-cols-2 overflow-hidden rounded-xl border border-violet-200/[.09] bg-black/20"><div className="border-r border-violet-200/[.09] p-3"><p className="text-[9px] font-bold uppercase tracking-[.14em] text-slate-500">Prize pool</p><p className="mt-1 font-display text-lg font-bold text-fuchsia-100">{formatCredits(tournament.prizePool)} <span className="text-[10px] tracking-normal text-fuchsia-300/70">CR</span></p></div><div className="p-3"><p className="text-[9px] font-bold uppercase tracking-[.14em] text-slate-500">Entry fee</p><p className="mt-1 font-display text-lg font-bold text-violet-100">{formatCredits(tournament.entryFee)} <span className="text-[10px] tracking-normal text-violet-300/70">CR</span></p></div></div>
      <div className="mt-4 space-y-2"><div className="flex items-center justify-between text-[11px] font-semibold"><span className="inline-flex items-center gap-1.5 text-slate-400"><CalendarClock size={13} className="text-violet-300" />{formatDateShort(tournament.startsAt)}</span><span className="text-slate-400"><span className="text-violet-100">{tournament.filledSlots}</span> / {tournament.totalSlots} slots · {tournament.remainingSlots} left</span></div><div className="h-1.5 overflow-hidden rounded-full bg-white/[.06]"><div className="h-full rounded-full bg-gradient-to-r from-violet-400 via-fuchsia-400 to-pink-400" style={{ width: `${filled}%` }} /></div></div>
      <div className="mt-4 grid grid-cols-[1fr_auto] gap-2"><Link href={`/tournaments/${tournament.slug}`} className="inline-flex min-h-11 items-center justify-center gap-1.5 rounded-xl border border-violet-200/[.16] bg-violet-300/[.06] px-3 text-[10px] font-extrabold tracking-[.08em] text-violet-100 transition hover:bg-violet-300/[.13] active:scale-[.98]">VIEW TOURNAMENT <ArrowRight size={14} /></Link><JoinTournamentButton tournament={tournament} joined={tournament.hasJoined} className="min-w-36 rounded-xl bg-gradient-to-r from-violet-500 to-fuchsia-500 text-[10px] font-extrabold tracking-[.06em] text-white shadow-[0_8px_22px_rgba(168,85,247,.22)] hover:brightness-110" /></div>
    </div>
  </article>;
}
