import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { formatCredits } from "@/lib/format";
import { tournamentJoinUiState } from "@/lib/tournamentEligibility";
import { trpc } from "@/lib/trpc";
import { CheckCircle2, CircleDollarSign, Gamepad2, MapPinned, ShieldCheck, UserRound, UsersRound } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import { useLocation } from "wouter";

type JoinableTournament = {
  id: number;
  name: string;
  mode: "solo" | "duo" | "squad";
  map: string;
  status: "draft" | "upcoming" | "live" | "completed" | "closed" | "cancelled";
  registrationOpen: boolean;
  remainingSlots: number;
  totalSlots: number;
  entryFee: number;
};

const nicknameIsValid = (value: string) => /^[A-Za-z0-9][A-Za-z0-9 _.'-]*$/.test(value.trim()) && value.trim().length >= 3 && value.trim().length <= 32;
const uidIsValid = (value: string) => /^\d{6,20}$/.test(value);

export function JoinTournamentButton({ tournament, joined = false, className }: { tournament: JoinableTournament; joined?: boolean; className?: string }) {
  const { user } = useAuth();
  const [, setLocation] = useLocation();
  const [teamName, setTeamName] = useState("");
  const [playerNickname, setPlayerNickname] = useState("");
  const [playerUid, setPlayerUid] = useState("");
  const [step, setStep] = useState<"details" | "confirm">("details");
  const [dialogOpen, setDialogOpen] = useState(false);
  const [completedBalance, setCompletedBalance] = useState<number | null>(null);
  const utils = trpc.useUtils();
  const { data: dashboard, isLoading: isBalanceLoading } = trpc.player.dashboard.useQuery(undefined, { enabled: Boolean(user) });
  const balance = dashboard?.balance ?? 0;
  const balanceAfterJoin = Math.max(0, balance - tournament.entryFee);
  const eligibility = tournamentJoinUiState({ isAuthenticated: Boolean(user), hasJoined: joined, remainingSlots: tournament.remainingSlots, status: tournament.status, registrationOpen: tournament.registrationOpen, walletBalance: user && !isBalanceLoading ? dashboard?.balance : undefined, entryFee: tournament.entryFee });
  const detailsValid = nicknameIsValid(playerNickname) && uidIsValid(playerUid) && (tournament.mode === "solo" || Boolean(teamName.trim()));
  const join = trpc.player.joinTournament.useMutation({
    onSuccess: (result) => {
      setCompletedBalance(result.balance);
      toast.success("TOURNAMENT JOINED", { description: "Your entry is confirmed and your Credits ledger has been updated." });
      void utils.public.home.invalidate();
      void utils.public.tournaments.invalidate();
      void utils.public.tournamentBySlug.invalidate();
      void utils.player.dashboard.invalidate();
      void utils.player.myTournaments.invalidate();
      void utils.player.transactions.invalidate();
    },
    onError: (error) => toast.error(error.message),
  });

  const openDetails = () => {
    setCompletedBalance(null);
    setStep("details");
    setPlayerNickname(dashboard?.account.playerName || dashboard?.account.name || "");
    setPlayerUid(dashboard?.account.gameUid || "");
    setDialogOpen(true);
  };
  const closeDialog = (open: boolean) => { setDialogOpen(open); if (!open) { setCompletedBalance(null); setStep("details"); } };
  const completeJoin = () => join.mutate({ tournamentId: tournament.id, playerNickname: playerNickname.trim(), playerUid, teamName: tournament.mode === "solo" ? undefined : teamName.trim() || undefined });

  if (eligibility === "already_joined") return <Button className={className} disabled variant="outline">ALREADY JOINED</Button>;
  if (eligibility === "slots_full") return <Button className={className} disabled variant="outline">SLOTS FULL</Button>;
  if (eligibility === "registration_closed") return <Button className={className} disabled variant="outline">REGISTRATION CLOSED</Button>;
  if (eligibility === "sign_in") return <Button onClick={() => setLocation("/auth")} className={className}>JOIN TOURNAMENT</Button>;
  if (eligibility === "checking_wallet") return <Button className={className} disabled variant="outline">CHECKING…</Button>;
  if (eligibility === "insufficient_credits") return <div className="min-w-32 space-y-1.5 text-center"><p className="text-[9px] font-black tracking-[.08em] text-orange-200">INSUFFICIENT CREDITS</p><Button onClick={() => setLocation("/wallet")} className="h-9 w-full rounded-lg border border-orange-300/30 bg-orange-300/[.12] px-2 text-[10px] font-extrabold tracking-[.06em] text-orange-100 hover:bg-orange-300/[.18]">TOP UP CREDITS</Button></div>;

  return <><Button onClick={openDetails} className={className}>JOIN TOURNAMENT</Button><Dialog open={dialogOpen} onOpenChange={closeDialog}><DialogContent className="max-h-[90vh] overflow-y-auto border-cyan-300/20 bg-[#0c1325] p-0 text-slate-100 sm:max-w-lg">{completedBalance !== null ? <JoinSuccess tournament={tournament} balance={completedBalance} nickname={playerNickname.trim()} playerUid={playerUid} onViewTournaments={() => setLocation("/my-tournaments")} /> : step === "details" ? <PlayerDetails tournament={tournament} nickname={playerNickname} uid={playerUid} teamName={teamName} valid={detailsValid} onNickname={setPlayerNickname} onUid={setPlayerUid} onTeamName={setTeamName} onClose={() => closeDialog(false)} onContinue={() => setStep("confirm")} /> : <JoinConfirmation tournament={tournament} nickname={playerNickname.trim()} uid={playerUid} teamName={teamName.trim()} balance={balance} remainingBalance={balanceAfterJoin} pending={join.isPending} onBack={() => setStep("details")} onConfirm={completeJoin} />}</DialogContent></Dialog></>;
}

function PlayerDetails({ tournament, nickname, uid, teamName, valid, onNickname, onUid, onTeamName, onClose, onContinue }: { tournament: JoinableTournament; nickname: string; uid: string; teamName: string; valid: boolean; onNickname: (value: string) => void; onUid: (value: string) => void; onTeamName: (value: string) => void; onClose: () => void; onContinue: () => void }) {
  return <><DialogHeader className="border-b border-white/[.08] bg-[radial-gradient(circle_at_85%_0%,rgba(103,232,249,.16),transparent_40%)] px-5 pb-5 pt-6 sm:px-6"><p className="text-[10px] font-black tracking-[.15em] text-cyan-300">STEP 1 OF 2 · PLAYER DETAILS</p><DialogTitle className="font-display text-2xl font-bold text-white">Identify your player</DialogTitle><DialogDescription className="text-sm leading-6 text-slate-400">Your in-game details are saved to your profile and recorded with this tournament entry.</DialogDescription></DialogHeader><div className="space-y-4 px-5 py-5 sm:px-6"><div className="rounded-2xl border border-white/[.09] bg-white/[.025] p-4"><p className="font-display text-lg font-bold text-white">{tournament.name}</p><p className="mt-1 text-xs text-slate-400">{tournament.mode.toUpperCase()} · {tournament.map}</p></div><div><label className="text-xs font-bold uppercase tracking-wider text-slate-400">Player Nickname <span className="text-cyan-300">*</span></label><div className="relative mt-2"><UserRound className="absolute left-3 top-3 h-4 w-4 text-cyan-300" /><Input value={nickname} onChange={(event) => onNickname(event.target.value.slice(0, 32))} placeholder="Your in-game nickname" maxLength={32} className="border-white/10 bg-white/[.04] pl-10 text-white placeholder:text-slate-600" /></div><p className={`mt-1.5 text-[11px] ${nickname && !nicknameIsValid(nickname) ? "text-orange-200" : "text-slate-500"}`}>3–32 characters. Letters, numbers, spaces, hyphens, apostrophes, periods, and underscores only.</p></div><div><label className="text-xs font-bold uppercase tracking-wider text-slate-400">Free Fire Player UID <span className="text-cyan-300">*</span></label><div className="relative mt-2"><Gamepad2 className="absolute left-3 top-3 h-4 w-4 text-cyan-300" /><Input value={uid} onChange={(event) => onUid(event.target.value.replace(/\D/g, "").slice(0, 20))} inputMode="numeric" autoComplete="off" placeholder="Numbers only" maxLength={20} className="border-white/10 bg-white/[.04] pl-10 text-white placeholder:text-slate-600" /></div><p className={`mt-1.5 text-[11px] ${uid && !uidIsValid(uid) ? "text-orange-200" : "text-slate-500"}`}>Enter the 6–20 digit UID shown in your Free Fire profile.</p></div>{tournament.mode !== "solo" ? <div><label className="text-xs font-bold uppercase tracking-wider text-slate-400">Team name <span className="text-cyan-300">*</span></label><div className="relative mt-2"><UsersRound className="absolute left-3 top-3 h-4 w-4 text-cyan-300" /><Input value={teamName} onChange={(event) => onTeamName(event.target.value.slice(0, 64))} placeholder="e.g. PLX Strikers" maxLength={64} className="border-white/10 bg-white/[.04] pl-10 text-white placeholder:text-slate-600" /></div></div> : null}</div><DialogFooter className="border-t border-white/[.08] px-5 py-4 sm:px-6"><Button variant="outline" onClick={onClose} className="border-white/10 bg-transparent text-slate-300">CANCEL</Button><Button onClick={onContinue} disabled={!valid} className="bg-gradient-to-r from-cyan-300 to-sky-400 font-black tracking-[.07em] text-[#051321]">CONTINUE</Button></DialogFooter></>;
}

function JoinConfirmation({ tournament, nickname, uid, teamName, balance, remainingBalance, pending, onBack, onConfirm }: { tournament: JoinableTournament; nickname: string; uid: string; teamName: string; balance: number; remainingBalance: number; pending: boolean; onBack: () => void; onConfirm: () => void }) {
  return <><DialogHeader className="border-b border-white/[.08] bg-[radial-gradient(circle_at_85%_0%,rgba(103,232,249,.16),transparent_40%)] px-5 pb-5 pt-6 sm:px-6"><p className="text-[10px] font-black tracking-[.15em] text-cyan-300">STEP 2 OF 2 · CONFIRM ENTRY</p><DialogTitle className="font-display text-2xl font-bold text-white">JOIN TOURNAMENT</DialogTitle><DialogDescription className="text-sm leading-6 text-slate-400">Review your player identity, event details, and Wallet impact before confirming.</DialogDescription></DialogHeader><div className="space-y-4 px-5 py-5 sm:px-6"><div className="rounded-2xl border border-cyan-300/15 bg-cyan-300/[.05] p-4"><p className="text-[10px] font-black tracking-[.12em] text-cyan-300">PLAYER DETAILS</p><div className="mt-3 grid grid-cols-2 gap-3 text-sm"><Detail label="NICKNAME" value={nickname} icon={<UserRound size={14} />} /><Detail label="PLAYER UID" value={uid} icon={<Gamepad2 size={14} />} /></div></div><div className="rounded-2xl border border-white/[.09] bg-white/[.025] p-4"><p className="font-display text-xl font-bold text-white">{tournament.name}</p><div className="mt-3 grid grid-cols-2 gap-3 text-sm"><Detail label="MODE" value={tournament.mode.toUpperCase()} icon={<UsersRound size={14} />} /><Detail label="MAP" value={tournament.map} icon={<MapPinned size={14} />} /><Detail label="ENTRY FEE" value={`${formatCredits(tournament.entryFee)} CR`} icon={<CircleDollarSign size={14} />} /><Detail label="AVAILABLE SLOTS" value={`${tournament.remainingSlots} / ${tournament.totalSlots}`} icon={<ShieldCheck size={14} />} />{teamName ? <Detail label="TEAM" value={teamName} icon={<UsersRound size={14} />} /> : null}</div></div><div className="rounded-2xl border border-cyan-300/15 bg-cyan-300/[.05] p-4"><div className="flex items-center justify-between gap-4"><div><p className="text-[10px] font-black tracking-[.12em] text-slate-500">WALLET BALANCE</p><p className="mt-1 font-display text-xl font-bold text-cyan-100">{formatCredits(balance)} CR</p></div><div className="text-right"><p className="text-[10px] font-black tracking-[.12em] text-slate-500">REMAINING CREDITS</p><p className="mt-1 font-display text-xl font-bold text-white">{formatCredits(remainingBalance)} CR</p></div></div></div><p className="text-center text-[11px] leading-5 text-slate-500">Your UID is checked against existing entries. Credits are deducted only after the server confirms an available slot and unique registration.</p></div><DialogFooter className="border-t border-white/[.08] px-5 py-4 sm:px-6"><Button variant="outline" onClick={onBack} disabled={pending} className="border-white/10 bg-transparent text-slate-300">BACK</Button><Button onClick={onConfirm} disabled={pending} className="bg-gradient-to-r from-cyan-300 to-sky-400 font-black tracking-[.07em] text-[#051321]">{pending ? "CONFIRMING…" : "CONFIRM JOIN"}</Button></DialogFooter></>;
}

function Detail({ label, value, icon }: { label: string; value: string; icon: React.ReactNode }) { return <div><p className="flex items-center gap-1.5 text-[9px] font-black tracking-[.1em] text-slate-500">{icon}{label}</p><p className="mt-1 truncate text-sm font-bold text-slate-100">{value}</p></div>; }

function JoinSuccess({ tournament, balance, nickname, playerUid, onViewTournaments }: { tournament: JoinableTournament; balance: number; nickname: string; playerUid: string; onViewTournaments: () => void }) { return <div className="p-6 sm:p-7"><span className="grid h-12 w-12 place-items-center rounded-2xl border border-emerald-300/20 bg-emerald-300/[.1] text-emerald-200"><CheckCircle2 size={25} /></span><p className="mt-5 text-[10px] font-black tracking-[.15em] text-emerald-300">TOURNAMENT JOINED</p><h2 className="mt-2 font-display text-2xl font-bold text-white">Your entry is confirmed.</h2><p className="mt-2 text-sm leading-6 text-slate-400">{tournament.name} is now available in My Tournaments. Your registered identity is <span className="font-bold text-slate-200">{nickname}</span> · <span className="font-bold text-slate-200">{playerUid}</span>.</p><div className="mt-5 rounded-xl border border-white/[.09] bg-white/[.025] p-4"><p className="text-[10px] font-black tracking-[.12em] text-slate-500">UPDATED WALLET BALANCE</p><p className="mt-1 font-display text-xl font-bold text-cyan-100">{formatCredits(balance)} CR</p></div><Button onClick={onViewTournaments} className="mt-5 w-full bg-gradient-to-r from-cyan-300 to-sky-400 font-black tracking-[.07em] text-[#051321]">VIEW MY TOURNAMENTS</Button></div>; }
