import { useAuth } from "@/_core/hooks/useAuth";
import { cn } from "@/lib/utils";
import { AtSign, Bell, CircleHelp, Crown, Facebook, Instagram, LayoutGrid, LogOut, Menu, MessageCircle, MessagesSquare, Radio, ReceiptText, Send, ShieldCheck, Trophy, UserRound, WalletCards, X, Youtube } from "lucide-react";
import React, { useState } from "react";
import { Link, useLocation } from "wouter";
import { PlxBrand } from "./PlxBrand";
import { trpc } from "@/lib/trpc";

const primaryNav = [
  { href: "/", label: "Home", icon: LayoutGrid },
  { href: "/tournaments/upcoming", label: "Tournaments", icon: Trophy },
  { href: "/tournaments/live", label: "Live", icon: Radio },
  { href: "/leaderboard", label: "Leaderboard", icon: Crown },
];

const socialIcon = { instagram: Instagram, telegram: Send, youtube: Youtube, whatsapp: MessageCircle, facebook: Facebook, discord: MessagesSquare, twitter: AtSign };
const socialLabel = { instagram: "Instagram", telegram: "Telegram", youtube: "YouTube", whatsapp: "WhatsApp", facebook: "Facebook", discord: "Discord", twitter: "X / Twitter" };

export type FooterSocialProfile = { id: number; platform: keyof typeof socialIcon; profileUrl: string };

export function FooterSocialLinks({ profiles }: { profiles: FooterSocialProfile[] }) {
  if (!profiles.length) return null;
  return <div className="flex items-center gap-1 border-l border-white/[.1] pl-3" aria-label="PLX official social media">{profiles.map((profile) => { const Icon = socialIcon[profile.platform]; return <a key={profile.id} href={profile.profileUrl} target="_blank" rel="noreferrer" aria-label={`Visit PLX on ${socialLabel[profile.platform]}`} title={socialLabel[profile.platform]} className="grid h-8 w-8 place-items-center rounded-lg border border-white/[.08] bg-white/[.02] text-slate-400 transition hover:-translate-y-0.5 hover:border-cyan-300/30 hover:bg-cyan-300/[.08] hover:text-cyan-100"><Icon size={15} /></a>; })}</div>;
}

function FooterDestination({ href, label }: { href: string; label: string }) {
  const className = "hover:text-cyan-200";
  return href.startsWith("http") ? <a href={href} target="_blank" rel="noreferrer" className={className}>{label}</a> : <Link href={href} className={className}>{label}</Link>;
}

export function PublicLayout({ children }: { children: React.ReactNode }) {
  const [location] = useLocation();
  const [menuOpen, setMenuOpen] = useState(false);
  const { user, loading, logout } = useAuth();
  const { data: homeData } = trpc.public.home.useQuery(undefined, { staleTime: 60_000 });
  const { data: socialProfiles } = trpc.public.socialProfiles.useQuery(undefined, { staleTime: 30_000 });
  const logoUrl = homeData?.platform.logoUrl;
  const footerLinks = homeData?.home.footerLinks ?? { tournaments: "/tournaments/upcoming", leaderboard: "/leaderboard", wallet: "/wallet", profile: "/profile", terms: "/terms", privacy: "/privacy", support: "/support" };

  const navActive = (href: string) => href === "/" ? location === "/" : location.startsWith(href);

  return (
    <div className="min-h-screen overflow-x-hidden bg-[#070b16] text-slate-100">
      <div className="fixed inset-0 -z-20 bg-[radial-gradient(ellipse_80%_55%_at_50%_-10%,rgba(96,54,227,.20),transparent_64%),radial-gradient(ellipse_50%_35%_at_100%_28%,rgba(10,181,218,.10),transparent_65%)]" />
      <div className="fixed inset-0 -z-10 noise-grid opacity-70" />
      <header className="sticky top-0 z-50 border-b border-white/[.06] bg-[#080d1b]/85 backdrop-blur-xl">
        <div className="container flex h-16 items-center justify-between gap-3">
          <PlxBrand logoUrl={logoUrl} />
          <nav className="hidden items-center gap-1 lg:flex" aria-label="Primary navigation">
            {primaryNav.map((item) => (
              <Link key={item.href} href={item.href} className={cn("rounded-xl px-3 py-2 text-sm font-semibold transition-colors", navActive(item.href) ? "bg-white/[.08] text-cyan-200" : "text-slate-400 hover:bg-white/[.05] hover:text-slate-100")}>
                {item.label}
              </Link>
            ))}
          </nav>
          <div className="hidden items-center gap-2 sm:flex">
            <Link href="/support" className="grid h-9 w-9 place-items-center rounded-xl text-slate-400 transition hover:bg-white/[.06] hover:text-cyan-200" aria-label="Support"><CircleHelp size={18} /></Link>
            {loading ? <span className="h-9 w-20 animate-pulse rounded-xl bg-white/[.05]" /> : user ? (
              <div className="flex items-center gap-2">
                {user.role === "admin" && <Link href="/admin" className="grid h-9 w-9 place-items-center rounded-xl bg-violet-500/15 text-violet-200 transition hover:bg-violet-500/25" aria-label="Admin console"><ShieldCheck size={18} /></Link>}
                <Link href="/profile" className="grid h-9 w-9 place-items-center rounded-xl text-slate-400 transition hover:bg-white/[.06] hover:text-cyan-200" aria-label="Profile"><UserRound size={18} /></Link>
                <Link href="/dashboard" className="flex items-center gap-2 rounded-xl border border-cyan-300/15 bg-cyan-300/[.06] px-3 py-2 text-xs font-bold text-cyan-100 transition hover:border-cyan-300/35">
                  <span className="grid h-5 w-5 place-items-center rounded-lg bg-cyan-300/15 text-[10px]">{(user.name || "P").slice(0, 1).toUpperCase()}</span>
                  <span className="max-w-24 truncate">{user.name || "Player"}</span>
                </Link>
                <button onClick={logout} className="grid h-9 w-9 place-items-center rounded-xl text-slate-500 transition hover:bg-rose-500/10 hover:text-rose-300" aria-label="Sign out"><LogOut size={17} /></button>
              </div>
            ) : <Link href="/auth" className="rounded-xl bg-gradient-to-r from-cyan-300 to-sky-400 px-4 py-2.5 text-xs font-extrabold tracking-[.08em] text-[#06111e] transition hover:brightness-110 active:scale-[.97]">SIGN IN</Link>}
          </div>
          <button onClick={() => setMenuOpen((open) => !open)} className="grid h-10 w-10 place-items-center rounded-xl border border-white/[.08] text-slate-200 sm:hidden" aria-expanded={menuOpen} aria-label="Toggle navigation">
            {menuOpen ? <X size={19} /> : <Menu size={19} />}
          </button>
        </div>
        {menuOpen && <div className="border-t border-white/[.06] bg-[#0a1020] px-4 py-4 sm:hidden">
          <div className="grid gap-1">
            {primaryNav.map((item) => <Link key={item.href} href={item.href} onClick={() => setMenuOpen(false)} className={cn("flex items-center gap-3 rounded-xl px-4 py-3 text-sm font-bold", navActive(item.href) ? "bg-cyan-300/[.09] text-cyan-200" : "text-slate-300")}><item.icon size={17} />{item.label}</Link>)}
            <Link href="/support" onClick={() => setMenuOpen(false)} className="flex items-center gap-3 rounded-xl px-4 py-3 text-sm font-bold text-slate-300"><CircleHelp size={17} />Support</Link>
            {user && <Link href="/profile" onClick={() => setMenuOpen(false)} className="flex items-center gap-3 rounded-xl px-4 py-3 text-sm font-bold text-slate-300"><UserRound size={17} />Profile</Link>}
            {user ? <Link href="/dashboard" onClick={() => setMenuOpen(false)} className="flex items-center gap-3 rounded-xl bg-white/[.05] px-4 py-3 text-sm font-bold text-cyan-100"><WalletCards size={17} />My Dashboard</Link> : <Link href="/auth" onClick={() => setMenuOpen(false)} className="mt-2 rounded-xl bg-cyan-300 px-4 py-3 text-center text-sm font-black text-[#06111e]">SIGN IN TO PLAY</Link>}
          </div>
        </div>}
      </header>
      <main className="pb-24 sm:pb-12">{children}</main>
      <footer className="border-t border-white/[.06] bg-[#070b16]/80">
        <div className="container flex flex-col gap-4 py-8 text-xs text-slate-500 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex flex-wrap items-center gap-3"><PlxBrand compact logoUrl={logoUrl} /><span>Play. Compete. Win.</span><FooterSocialLinks profiles={socialProfiles ?? []} /></div>
          <div className="flex flex-wrap gap-x-4 gap-y-2"><FooterDestination href={footerLinks.tournaments} label="Tournaments" /><FooterDestination href={footerLinks.leaderboard} label="Leaderboard" /><FooterDestination href={footerLinks.wallet} label="Wallet" /><FooterDestination href={footerLinks.profile} label="Profile" /><FooterDestination href={footerLinks.terms} label="Terms" /><FooterDestination href={footerLinks.privacy} label="Privacy" /><FooterDestination href={footerLinks.support} label="Support" /></div>
        </div>
      </footer>
      <nav className="fixed inset-x-0 bottom-0 z-50 flex border-t border-white/[.08] bg-[#090e1d]/95 px-2 pb-[max(.5rem,env(safe-area-inset-bottom))] pt-2 backdrop-blur-xl sm:hidden" aria-label="Mobile navigation">
        {primaryNav.map((item) => <Link key={item.href} href={item.href} className={cn("flex min-w-0 flex-1 flex-col items-center gap-1 rounded-lg py-1 text-[9px] font-bold", navActive(item.href) ? "text-cyan-200" : "text-slate-500")}><item.icon size={18} strokeWidth={navActive(item.href) ? 2.5 : 1.8} />{item.label}</Link>)}
        <Link href={user ? "/wallet" : "/auth"} className={cn("flex min-w-0 flex-1 flex-col items-center gap-1 rounded-lg py-1 text-[9px] font-bold", location.startsWith("/wallet") ? "text-cyan-200" : "text-slate-500")}><WalletCards size={18} />Wallet</Link>
        <Link href={user ? "/profile" : "/auth"} className={cn("flex min-w-0 flex-1 flex-col items-center gap-1 rounded-lg py-1 text-[9px] font-bold", location.startsWith("/profile") ? "text-cyan-200" : "text-slate-500")}><UserRound size={18} />Profile</Link>
      </nav>
    </div>
  );
}
