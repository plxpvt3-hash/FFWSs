import { useAuth } from "@/_core/hooks/useAuth";
import { cn } from "@/lib/utils";
import { AtSign, Bell, CircleHelp, Crown, Facebook, Instagram, LayoutGrid, LogOut, Menu, MessageCircle, MessagesSquare, Radio, ReceiptText, Send, ShieldCheck, Trophy, UserRound, WalletCards, X, Youtube } from "lucide-react";
import React, { useEffect, useState } from "react";
import { Link, useLocation } from "wouter";
import { PlxBrand } from "./PlxBrand";
import { trpc } from "@/lib/trpc";

const primaryNav = [
  { href: "/", label: "Home", icon: LayoutGrid },
  { href: "/tournaments/upcoming", label: "Tournaments", icon: Trophy },
  { href: "/live", label: "Live", icon: Radio },
  { href: "/leaderboard", label: "Leaderboard", icon: Crown },
];

const socialIcon = { instagram: Instagram, telegram: Send, youtube: Youtube, whatsapp: MessageCircle, facebook: Facebook, discord: MessagesSquare, twitter: AtSign };
const socialLabel = { instagram: "Instagram", telegram: "Telegram", youtube: "YouTube", whatsapp: "WhatsApp", facebook: "Facebook", discord: "Discord", twitter: "X / Twitter" };

export type FooterSocialProfile = { id: number; platform: keyof typeof socialIcon; profileUrl: string };

export function FooterSocialLinks({ profiles }: { profiles: FooterSocialProfile[] }) {
  if (!profiles.length) return null;
  return <div className="flex items-center gap-1 border-l border-white/[.1] pl-3" aria-label="PLX official social media">{profiles.map((profile) => { const Icon = socialIcon[profile.platform]; return <a key={profile.id} href={profile.profileUrl} target="_blank" rel="noreferrer" aria-label={`Visit PLX on ${socialLabel[profile.platform]}`} title={socialLabel[profile.platform]} className="grid h-8 w-8 place-items-center rounded-lg border border-white/[.08] bg-white/[.02] text-slate-400 transition hover:-translate-y-0.5 hover:border-cyan-300/30 hover:bg-cyan-300/[.08] hover:text-cyan-100"><Icon size={15} /></a>; })}</div>;
}

function FooterDestination({ href, label }: { href: string; label: string }) {
  const className = "hover:text-cyan-200";
  return href.startsWith("http") ? <a href={href} target="_blank" rel="noreferrer" className={className}>{label}</a> : <Link href={href} className={className}>{label}</Link>;
}

export function PublicLayout({ children }: { children: React.ReactNode }) {
  const [location] = useLocation();
  const [menuOpen, setMenuOpen] = useState(false);
  const { user, loading, logout } = useAuth();
  const { data: homeData } = trpc.public.home.useQuery(undefined, { staleTime: 60_000 });
  const { data: socialProfiles } = trpc.public.socialProfiles.useQuery(undefined, { staleTime: 30_000 });
  const logoUrl = homeData?.platform.logoUrl;
  const footerLinks = homeData?.home.footerLinks ?? { tournaments: "/tournaments/upcoming", leaderboard: "/leaderboard", wallet: "/wallet", profile: "/profile", terms: "/terms", privacy: "/privacy", support: "/support" };

  const navActive = (href: string) => href === "/" ? location === "/" : location.startsWith(href);
  const isHome = location === "/";
  const isWallet = location.startsWith("/wallet");
  const isTournamentRoute = location.startsWith("/tournaments");
  const isLeaderboard = location.startsWith("/leaderboard");
  const isLive = location.startsWith("/live");
  const isProfile = location.startsWith("/profile");
  const usesAppFrame = isHome || isWallet || isTournamentRoute || isLeaderboard || isLive || isProfile;

  useEffect(() => {
    if (!usesAppFrame) return;
    document.documentElement.classList.add("plx-app-route");
    document.body.classList.add("plx-app-route");
    return () => {
      document.documentElement.classList.remove("plx-app-route");
      document.body.classList.remove("plx-app-route");
    };
  }, [usesAppFrame]);

  return (
    <div className={cn("bg-[#070b16] text-slate-100", usesAppFrame ? "relative flex h-[100dvh] min-h-[100dvh] flex-col overflow-hidden overscroll-none" : "min-h-screen overflow-x-hidden", isHome && "plx-home-screen", isWallet && "plx-wallet-screen", isProfile && "plx-profile-screen")}>
      <div className="fixed inset-0 -z-20 bg-[radial-gradient(ellipse_80%_55%_at_50%_-10%,rgba(116,55,239,.24),transparent_64%),radial-gradient(ellipse_50%_35%_at_100%_28%,rgba(139,71,255,.10),transparent_65%)]" />
      <div className="fixed inset-0 -z-10 noise-grid opacity-70" />
      <header className={cn("top-0 z-50 border-b border-violet-200/[.1] bg-[#080810]/88 backdrop-blur-xl", isHome ? "relative shrink-0" : "sticky")}>
        <div className={cn("flex items-center justify-between gap-3", isHome ? "mx-auto h-[clamp(4.25rem,10dvh,5rem)] w-full max-w-md px-4 sm:px-5" : "container h-20")}>
          <PlxBrand logoUrl={logoUrl} />
          {!isHome && <nav className="hidden items-center gap-1 lg:flex" aria-label="Primary navigation">
            {primaryNav.map((item) => (
              <Link key={item.href} href={item.href} className={cn("rounded-xl px-3 py-2 text-sm font-semibold transition-colors", navActive(item.href) ? "bg-violet-300/[.12] text-violet-100 shadow-[0_0_24px_rgba(167,119,255,.12)]" : "text-slate-400 hover:bg-violet-300/[.07] hover:text-violet-100")}>
                {item.label}
              </Link>
            ))}
          </nav>}
          {!isHome && <div className="hidden items-center gap-2 sm:flex">
            <Link href="/support" className="grid h-9 w-9 place-items-center rounded-xl text-slate-400 transition hover:bg-violet-300/[.08] hover:text-violet-100" aria-label="Support"><CircleHelp size={18} /></Link>
            {loading ? <span className="h-9 w-20 animate-pulse rounded-xl bg-white/[.05]" /> : user ? (
              <div className="flex items-center gap-2">
                {user.role === "admin" && <Link href="/admin" className="grid h-9 w-9 place-items-center rounded-xl bg-violet-500/15 text-violet-200 transition hover:bg-violet-500/25" aria-label="Admin console"><ShieldCheck size={18} /></Link>}
                <Link href="/profile" className="grid h-9 w-9 place-items-center rounded-xl text-slate-400 transition hover:bg-violet-300/[.08] hover:text-violet-100" aria-label="Profile"><UserRound size={18} /></Link>
                <Link href="/dashboard" className="flex items-center gap-2 rounded-xl border border-violet-300/20 bg-violet-300/[.08] px-3 py-2 text-xs font-bold text-violet-100 transition hover:border-violet-200/45">
                  <span className="grid h-5 w-5 place-items-center rounded-lg bg-violet-300/15 text-[10px]">{(user.name || "P").slice(0, 1).toUpperCase()}</span>
                  <span className="max-w-24 truncate">{user.name || "Player"}</span>
                </Link>
                <button onClick={logout} className="grid h-9 w-9 place-items-center rounded-xl text-slate-500 transition hover:bg-rose-500/10 hover:text-rose-300" aria-label="Sign out"><LogOut size={17} /></button>
              </div>
            ) : <Link href="/auth" className="rounded-xl bg-gradient-to-r from-violet-500 to-fuchsia-500 px-4 py-2.5 text-xs font-extrabold tracking-[.08em] text-white transition hover:brightness-110 active:scale-[.97]">SIGN IN</Link>}
          </div>}
          <button onClick={() => setMenuOpen((open) => !open)} className={cn("grid h-10 w-10 place-items-center rounded-xl border border-violet-200/[.18] bg-violet-400/[.06] text-violet-100 transition hover:bg-violet-400/[.13] active:scale-[.95]", isHome ? "" : "sm:hidden")} aria-expanded={menuOpen} aria-label="Toggle navigation">
            {menuOpen ? <X size={19} /> : <Menu size={19} />}
          </button>
        </div>
        {menuOpen && <div className={cn("border-t border-violet-200/[.1] bg-[#0d0a17] px-4 py-4", isHome ? "absolute inset-x-0 top-full mx-auto w-full max-w-md border-x border-violet-200/[.1] shadow-[0_18px_46px_rgba(0,0,0,.42)]" : "sm:hidden")}>
          <div className="grid gap-1">
            {primaryNav.map((item) => <Link key={item.href} href={item.href} onClick={() => setMenuOpen(false)} className={cn("flex items-center gap-3 rounded-xl px-4 py-3 text-sm font-bold", navActive(item.href) ? "bg-violet-300/[.11] text-violet-100" : "text-slate-300")}><item.icon size={17} />{item.label}</Link>)}
            <Link href="/support" onClick={() => setMenuOpen(false)} className="flex items-center gap-3 rounded-xl px-4 py-3 text-sm font-bold text-slate-300"><CircleHelp size={17} />Support</Link>
            {user && <Link href="/profile" onClick={() => setMenuOpen(false)} className="flex items-center gap-3 rounded-xl px-4 py-3 text-sm font-bold text-slate-300"><UserRound size={17} />Profile</Link>}
            {user ? <Link href="/dashboard" onClick={() => setMenuOpen(false)} className="flex items-center gap-3 rounded-xl bg-violet-300/[.10] px-4 py-3 text-sm font-bold text-violet-100"><WalletCards size={17} />My Dashboard</Link> : <Link href="/auth" onClick={() => setMenuOpen(false)} className="mt-2 rounded-xl bg-gradient-to-r from-violet-500 to-fuchsia-500 px-4 py-3 text-center text-sm font-black text-white">SIGN IN TO PLAY</Link>}
          </div>
        </div>}
      </header>
      <main className={cn(isHome ? "relative flex min-h-0 flex-1 overflow-hidden pb-[calc(4.5rem+env(safe-area-inset-bottom))] sm:pb-0" : usesAppFrame ? "relative min-h-0 flex-1 overflow-y-auto overscroll-contain pb-[calc(5.25rem+env(safe-area-inset-bottom))] sm:pb-8" : "pb-24 sm:pb-12")}>{children}</main>
      {!usesAppFrame && <footer className="border-t border-white/[.06] bg-[#070b16]/80">
        <div className="container flex flex-col gap-4 py-8 text-xs text-slate-500 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex flex-wrap items-center gap-3"><PlxBrand compact logoUrl={logoUrl} /><span>Play. Compete. Win.</span><FooterSocialLinks profiles={socialProfiles ?? []} /></div>
          <div className="flex flex-wrap gap-x-4 gap-y-2"><FooterDestination href={footerLinks.tournaments} label="Tournaments" /><FooterDestination href={footerLinks.leaderboard} label="Leaderboard" /><FooterDestination href={footerLinks.wallet} label="Wallet" /><FooterDestination href={footerLinks.profile} label="Profile" /><FooterDestination href={footerLinks.terms} label="Terms" /><FooterDestination href={footerLinks.privacy} label="Privacy" /><FooterDestination href={footerLinks.support} label="Support" /></div>
        </div>
      </footer>}
      <nav className={cn("fixed inset-x-0 bottom-0 z-50 flex border-t border-violet-200/[.13] bg-[#0c0719]/95 px-2 pb-[max(.5rem,env(safe-area-inset-bottom))] pt-2 shadow-[0_-14px_36px_rgba(5,2,12,.34)] backdrop-blur-xl", isHome ? "mx-auto w-full max-w-md border-x border-violet-200/[.13]" : "sm:hidden")} aria-label="Mobile navigation">
        {primaryNav.map((item) => <Link key={item.href} href={item.href} className={cn("plx-mobile-tab flex min-w-0 flex-1 flex-col items-center gap-1 rounded-xl py-1.5 text-[9px] font-bold", navActive(item.href) ? "bg-gradient-to-b from-violet-300/[.16] to-transparent text-violet-100 shadow-[0_0_22px_rgba(193,132,255,.17)]" : "text-slate-500")}><item.icon size={18} strokeWidth={navActive(item.href) ? 2.5 : 1.8} />{item.label}</Link>)}
        <Link href={user ? "/wallet" : "/auth"} className={cn("plx-mobile-tab flex min-w-0 flex-1 flex-col items-center gap-1 rounded-xl py-1.5 text-[9px] font-bold", location.startsWith("/wallet") ? "bg-gradient-to-b from-violet-300/[.16] to-transparent text-violet-100 shadow-[0_0_22px_rgba(193,132,255,.17)]" : "text-slate-500")}><WalletCards size={18} />Wallet</Link>
        <Link href={user ? "/profile" : "/auth"} className={cn("plx-mobile-tab flex min-w-0 flex-1 flex-col items-center gap-1 rounded-xl py-1.5 text-[9px] font-bold", location.startsWith("/profile") ? "bg-gradient-to-b from-violet-300/[.16] to-transparent text-violet-100 shadow-[0_0_22px_rgba(193,132,255,.17)]" : "text-slate-500")}><UserRound size={18} />Profile</Link>
      </nav>
    </div>
  );
}
