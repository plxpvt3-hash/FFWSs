import { render, screen } from "@testing-library/react";
import React from "react";
import { describe, expect, it } from "vitest";
import { FooterSocialLinks } from "./PublicLayout";

describe("FooterSocialLinks", () => {
  it("renders official enabled social links with safe outbound-link metadata", () => {
    render(<FooterSocialLinks profiles={[
      { id: 1, platform: "instagram", profileUrl: "https://instagram.com/plxgaming" },
      { id: 2, platform: "discord", profileUrl: "https://discord.gg/plxgaming" },
    ]} />);

    const instagram = screen.getByRole("link", { name: "Visit PLX on Instagram" });
    expect(instagram.getAttribute("href")).toBe("https://instagram.com/plxgaming");
    expect(instagram.getAttribute("target")).toBe("_blank");
    expect(instagram.getAttribute("rel")).toBe("noreferrer");
    expect(screen.getByRole("link", { name: "Visit PLX on Discord" })).toBeTruthy();
  });

  it("does not render a social group before an administrator enables a configured account", () => {
    const { container } = render(<FooterSocialLinks profiles={[]} />);
    expect(container.innerHTML).toBe("");
  });
});
