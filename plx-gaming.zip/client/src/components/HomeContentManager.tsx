import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { formatDateShort, titleCase } from "@/lib/format";
import { trpc } from "@/lib/trpc";
import { ImageUp, Loader2, Radio, Save, Sparkles, Trophy } from "lucide-react";
import { ChangeEvent, useEffect, useState } from "react";
import { toast } from "sonner";

type HomeForm = {
  heroTitle: string;
  heroDescription: string;
  heroDataUrl: string;
  featuredIds: number[];
  liveTournamentId: string;
  statsEnabled: boolean;
  footerTournamentsUrl: string;
  footerLeaderboardUrl: string;
  footerWalletUrl: string;
  footerProfileUrl: string;
  footerTermsUrl: string;
  footerPrivacyUrl: string;
  footerSupportUrl: string;
};

const defaults: HomeForm = {
  heroTitle: "PLAY. COMPETE. WIN.", heroDescription: "Join competitive Free Fire tournaments, secure your slot with Tournament Credits and compete for prizes.", heroDataUrl: "", featuredIds: [], liveTournamentId: "none", statsEnabled: true,
  footerTournamentsUrl: "/tournaments/upcoming", footerLeaderboardUrl: "/leaderboard", footerWalletUrl: "/wallet", footerProfileUrl: "/profile", footerTermsUrl: "/terms", footerPrivacyUrl: "/privacy", footerSupportUrl: "/support",
};

function parseIds(value?: string) { try { const parsed = JSON.parse(value ?? "[]"); return Array.isArray(parsed) ? parsed.filter((id): id is number => Number.isInteger(id)).slice(0, 3) : []; } catch { return []; } }

export function HomeContentManager() {
  const utils = trpc.useUtils();
  const { data: settings, isLoading: settingsLoading } = trpc.admin.settings.useQuery();
  const { data: tournaments } = trpc.admin.tournaments.useQuery();
  const [form, setForm] = useState<HomeForm>(defaults);
  useEffect(() => { if (!settings) return; setForm({
    heroTitle: settings.homeHeroTitle ?? defaults.heroTitle, heroDescription: settings.homeHeroDescription ?? defaults.heroDescription, heroDataUrl: "", featuredIds: parseIds(settings.homeFeaturedTournamentIds), liveTournamentId: settings.homeLiveTournamentId || "none", statsEnabled: settings.homeStatsEnabled !== "false",
    footerTournamentsUrl: settings.footerTournamentsUrl ?? defaults.footerTournamentsUrl, footerLeaderboardUrl: settings.footerLeaderboardUrl ?? defaults.footerLeaderboardUrl, footerWalletUrl: settings.footerWalletUrl ?? defaults.footerWalletUrl, footerProfileUrl: settings.footerProfileUrl ?? defaults.footerProfileUrl, footerTermsUrl: settings.footerTermsUrl ?? defaults.footerTermsUrl, footerPrivacyUrl: settings.footerPrivacyUrl ?? defaults.footerPrivacyUrl, footerSupportUrl: settings.footerSupportUrl ?? defaults.footerSupportUrl,
  }); }, [settings]);
  const save = trpc.admin.saveSettings.useMutation({ onSuccess: () => { toast.success("Home content published."); utils.admin.settings.invalidate(); utils.public.home.invalidate(); }, onError: (error) => toast.error(error.message) });
  const change = (key: keyof HomeForm, value: HomeForm[keyof HomeForm]) => setForm((current) => ({ ...current, [key]: value }));
  const selectFeatured = (id: number, checked: boolean) => { const next = checked ? [...form.featuredIds, id].slice(0, 3) : form.featuredIds.filter((item) => item !== id); change("featuredIds", next); };
  const chooseImage = (event: ChangeEvent<HTMLInputElement>) => { const file = event.target.files?.[0]; if (!file) return; if (!["image/png", "image/jpeg", "image/webp"].includes(file.type) || file.size > 4 * 1024 * 1024) return toast.error("Use a PNG, JPEG, or WebP under 4 MB."); const reader = new FileReader(); reader.onload = () => change("heroDataUrl", String(reader.result)); reader.readAsDataURL(file); };
  const publish = () => { if (!settings) return; save.mutate({ upiId: settings.upiId ?? "", paymentInstructions: settings.paymentInstructions ?? "", supportEmail: settings.supportEmail ?? "", supportMessage: settings.supportMessage ?? "", rules: settings.rules ?? "", homeHeroTitle: form.heroTitle, homeHeroDescription: form.heroDescription, homeHeroDataUrl: form.heroDataUrl || undefined, homeFeaturedTournamentIds: form.featuredIds, homeLiveTournamentId: form.liveTournamentId === "none" ? null : Number(form.liveTournamentId), homeStatsEnabled: form.statsEnabled, footerTournamentsUrl: form.footerTournamentsUrl, footerLeaderboardUrl: form.footerLeaderboardUrl, footerWalletUrl: form.footerWalletUrl, footerProfileUrl: form.footerProfileUrl, footerTermsUrl: form.footerTermsUrl, footerPrivacyUrl: form.footerPrivacyUrl, footerSupportUrl: form.footerSupportUrl }); };
  const candidates = tournaments?.filter((tournament) => ["upcoming", "live"].includes(tournament.status)) ?? [];
  const liveCandidates = tournaments?.filter((tournament) => tournament.status === "live") ?? [];

  if (settingsLoading) return <div className="h-96 animate-pulse rounded-2xl bg-white/[.04]" />;
  return <div><div className="mb-7"><p className="text-[10px] font-black tracking-[.16em] text-cyan-300">PUBLIC EXPERIENCE</p><h1 className="mt-2 font-display text-3xl font-bold text-white sm:text-4xl">Home Content</h1><p className="mt-2 max-w-2xl text-sm leading-6 text-slate-400">Configure the database-backed PLX landing page. Tournament lists, live availability, player standings, and platform totals remain calculated from real records.</p></div><div className="space-y-5">
    <section className="rounded-2xl border border-white/[.09] bg-[#0c1325] p-5 sm:p-6"><div className="flex items-start gap-3"><span className="grid h-10 w-10 place-items-center rounded-xl bg-cyan-300/[.08] text-cyan-200"><Sparkles size={19} /></span><div><h2 className="font-display text-xl font-bold text-white">Hero Section</h2><p className="mt-1 text-sm text-slate-400">Set the Home headline, supporting copy, and optional background visual.</p></div></div><div className="mt-5 grid gap-4 sm:grid-cols-2"><div className="sm:col-span-2"><Label className="text-xs font-bold text-slate-300">Hero title</Label><Input value={form.heroTitle} onChange={(event) => change("heroTitle", event.target.value)} className="admin-input mt-2" /></div><div className="sm:col-span-2"><Label className="text-xs font-bold text-slate-300">Hero description</Label><Textarea value={form.heroDescription} onChange={(event) => change("heroDescription", event.target.value)} className="admin-input mt-2 min-h-24" /></div><div className="sm:col-span-2"><Label className="text-xs font-bold text-slate-300">Hero background</Label><label className="mt-2 flex min-h-24 cursor-pointer items-center justify-center rounded-xl border border-dashed border-white/[.16] bg-white/[.02] px-3 text-center transition hover:border-cyan-300/40"><input type="file" accept="image/png,image/jpeg,image/webp" className="sr-only" onChange={chooseImage} />{form.heroDataUrl || settings?.homeHeroBannerUrl ? <><ImageUp className="mr-2 h-5 w-5 text-cyan-200" /><span className="text-xs font-bold text-cyan-100">Hero visual ready to publish</span></> : <><ImageUp className="mr-2 h-5 w-5 text-slate-400" /><span className="text-xs font-bold text-slate-400">Upload PNG, JPG, or WebP · max 4 MB</span></>}</label></div></div></section>
    <section className="rounded-2xl border border-white/[.09] bg-[#0c1325] p-5 sm:p-6"><div className="flex items-start gap-3"><span className="grid h-10 w-10 place-items-center rounded-xl bg-violet-300/[.08] text-violet-200"><Trophy size={19} /></span><div><h2 className="font-display text-xl font-bold text-white">Featured & Live Events</h2><p className="mt-1 text-sm text-slate-400">Select up to three upcoming or live tournaments for the Home hero list. Data still comes directly from each tournament record.</p></div></div><div className="mt-5 grid gap-3 lg:grid-cols-3">{candidates.length ? candidates.map((tournament) => <label key={tournament.id} className="flex cursor-pointer gap-3 rounded-xl border border-white/[.08] bg-white/[.02] p-3 transition hover:border-cyan-300/25"><Checkbox checked={form.featuredIds.includes(tournament.id)} disabled={!form.featuredIds.includes(tournament.id) && form.featuredIds.length >= 3} onCheckedChange={(value) => selectFeatured(tournament.id, Boolean(value))} /><span className="min-w-0"><span className="block truncate font-bold text-slate-100">{tournament.name}</span><span className="mt-1 block text-xs text-slate-500">{titleCase(tournament.status)} · {formatDateShort(tournament.startsAt)}</span></span></label>) : <p className="text-sm text-slate-500 lg:col-span-3">No upcoming or live tournaments exist yet. Newly published tournaments will become available here.</p>}</div><div className="mt-5 max-w-md"><Label className="text-xs font-bold text-slate-300">Live-match callout</Label><Select value={form.liveTournamentId} onValueChange={(value) => change("liveTournamentId", value)}><SelectTrigger className="admin-input mt-2"><SelectValue /></SelectTrigger><SelectContent className="admin-select"><SelectItem value="none">Automatic first live tournament</SelectItem>{liveCandidates.map((tournament) => <SelectItem value={String(tournament.id)} key={tournament.id}>{tournament.name}</SelectItem>)}</SelectContent></Select><p className="mt-2 text-xs leading-5 text-slate-500">This callout stays hidden for players whenever no tournament has Live status.</p></div></section>
    <section className="rounded-2xl border border-white/[.09] bg-[#0c1325] p-5 sm:p-6"><div className="flex items-start gap-3"><span className="grid h-10 w-10 place-items-center rounded-xl bg-emerald-300/[.08] text-emerald-200"><Radio size={19} /></span><div><h2 className="font-display text-xl font-bold text-white">Stats & Footer Destinations</h2><p className="mt-1 text-sm text-slate-400">Platform totals are calculated live. Choose whether they display, then manage every footer destination without code edits.</p></div></div><label className="mt-5 flex items-center gap-3 rounded-xl border border-white/[.08] bg-white/[.02] p-3 text-sm text-slate-300"><Checkbox checked={form.statsEnabled} onCheckedChange={(value) => change("statsEnabled", Boolean(value))} /><span><span className="block font-bold text-slate-100">Show platform statistics</span><span className="mt-1 block text-xs text-slate-500">Shows calculated player, tournament, live event, and Prize Credit totals.</span></span></label><div className="mt-5 grid gap-4 sm:grid-cols-2">{([['footerTournamentsUrl','Tournaments'],['footerLeaderboardUrl','Leaderboard'],['footerWalletUrl','Wallet'],['footerProfileUrl','Profile'],['footerTermsUrl','Terms'],['footerPrivacyUrl','Privacy'],['footerSupportUrl','Support']] as const).map(([key, label]) => <div key={key}><Label className="text-xs font-bold text-slate-300">{label} destination</Label><Input value={form[key]} onChange={(event) => change(key, event.target.value)} className="admin-input mt-2" /></div>)}</div><p className="mt-4 text-xs leading-5 text-slate-500">Use a local PLX route beginning with / or a full https:// official URL. Invalid or empty destinations are rejected server-side.</p></section>
    <div className="flex justify-end"><Button onClick={publish} disabled={save.isPending || form.heroTitle.trim().length < 3 || form.heroDescription.trim().length < 20} className="min-h-11 bg-cyan-300 text-xs font-black tracking-[.08em] text-[#051321]">{save.isPending ? <Loader2 className="animate-spin" size={16} /> : <Save size={16} />}PUBLISH HOME CONTENT</Button></div>
  </div></div>;
}
