import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import { CreditCard, LayoutDashboard, ReceiptText, Trophy, UserRound } from "lucide-react";

const items = [
  { href: "/dashboard", label: "Overview", icon: LayoutDashboard },
  { href: "/my-tournaments", label: "My Tournaments", icon: Trophy },
  { href: "/wallet", label: "Credits Wallet", icon: CreditCard },
  { href: "/transactions", label: "Transactions", icon: ReceiptText },
  { href: "/profile", label: "Profile", icon: UserRound },
];

export function PlayerHeader({ title, eyebrow }: { title: string; eyebrow: string }) {
  const [location] = useLocation();
  return <><div className="mb-6 sm:mb-8"><p className="text-[10px] font-black tracking-[.17em] text-violet-200">{eyebrow}</p><h1 className="mt-2 font-display text-3xl font-bold text-white sm:text-4xl">{title}</h1></div><div className="-mx-1 mb-7 overflow-x-auto px-1 pb-2"><nav className="flex min-w-max gap-1 rounded-xl border border-violet-200/[.13] bg-violet-300/[.045] p-1.5 shadow-[0_12px_36px_rgba(26,10,58,.15)]">{items.map((item) => { const active = location === item.href; return <Link key={item.href} href={item.href} className={cn("inline-flex items-center gap-2 rounded-lg px-3 py-2 text-xs font-bold transition", active ? "bg-violet-300/15 text-violet-100 shadow-[0_0_22px_rgba(167,119,255,.12)]" : "text-slate-500 hover:bg-violet-300/[.07] hover:text-violet-100")}><item.icon size={14} />{item.label}</Link>; })}</nav></div></>;
}
