export function formatCredits(value: number) {
  return new Intl.NumberFormat("en-IN").format(value);
}

export function formatDateTime(value: Date | string) {
  return new Intl.DateTimeFormat("en-IN", {
    day: "2-digit",
    month: "short",
    year: "numeric",
    hour: "numeric",
    minute: "2-digit",
  }).format(new Date(value));
}

export function formatDateShort(value: Date | string) {
  return new Intl.DateTimeFormat("en-IN", { day: "2-digit", month: "short", hour: "numeric", minute: "2-digit" }).format(new Date(value));
}

export function titleCase(value: string) {
  return value.charAt(0).toUpperCase() + value.slice(1);
}
