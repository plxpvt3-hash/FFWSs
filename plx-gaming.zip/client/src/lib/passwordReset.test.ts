import { describe, expect, it } from "vitest";
import { getPasswordResetToken } from "./passwordReset";

describe("PLX password-reset link parsing", () => {
  it("reads a reset token from the browser query string", () => {
    expect(getPasswordResetToken("?token=one-time-secure-token")).toBe("one-time-secure-token");
  });

  it("does not treat a pathname-only router location as a reset token", () => {
    expect(getPasswordResetToken("")).toBe("");
  });
});
