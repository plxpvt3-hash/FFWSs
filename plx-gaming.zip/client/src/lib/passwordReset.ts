export function getPasswordResetToken(search: string) {
  return new URLSearchParams(search).get("token") ?? "";
}
