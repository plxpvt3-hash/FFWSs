export function canStartUpiPayment(upiId: string | null | undefined) {
  return Boolean(upiId?.trim());
}

export function canSubmitPaymentProof(utr: string, screenshotDataUrl: string | null | undefined, isSubmitting = false) {
  return !isSubmitting && utr.trim().length >= 6 && Boolean(screenshotDataUrl?.trim());
}

export function buildUpiPaymentUrl(upiId: string, amount: number, credits: number) {
  const query = new URLSearchParams({
    pa: upiId.trim(),
    pn: "PLX Gaming",
    am: String(amount),
    cu: "INR",
    tn: `PLX ${credits} Tournament Credits`,
  });
  return `upi://pay?${query.toString()}`;
}

export function paymentSubmissionUiState(isSubmitting: boolean, hasSubmitted: boolean) {
  return {
    isLocked: isSubmitting || hasSubmitted,
    buttonLabel: isSubmitting ? "SUBMITTING PAYMENT PROOF" : "SUBMIT PAYMENT FOR VERIFICATION",
    showPendingConfirmation: hasSubmitted,
  };
}
