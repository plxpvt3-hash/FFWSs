export type TournamentJoinUiState = "joinable" | "sign_in" | "checking_wallet" | "insufficient_credits" | "slots_full" | "registration_closed" | "already_joined";

type TournamentJoinStateInput = {
  isAuthenticated: boolean;
  hasJoined: boolean;
  remainingSlots: number;
  status: "draft" | "upcoming" | "live" | "completed" | "closed" | "cancelled";
  registrationOpen: boolean;
  walletBalance?: number;
  entryFee: number;
};

export function tournamentJoinUiState(input: TournamentJoinStateInput): TournamentJoinUiState {
  if (input.hasJoined) return "already_joined";
  if (input.remainingSlots <= 0) return "slots_full";
  if (input.status !== "upcoming" || !input.registrationOpen) return "registration_closed";
  if (!input.isAuthenticated) return "sign_in";
  if (input.walletBalance === undefined) return "checking_wallet";
  if (input.walletBalance < input.entryFee) return "insufficient_credits";
  return "joinable";
}
