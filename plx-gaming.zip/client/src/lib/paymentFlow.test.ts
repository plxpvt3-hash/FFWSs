import { describe, expect, it } from "vitest";
import { buildUpiPaymentUrl, canStartUpiPayment, canSubmitPaymentProof, paymentSubmissionUiState } from "./paymentFlow";

describe("PLX UPI payment screen readiness", () => {
  it("requires an administrator-configured UPI ID before a player can begin payment", () => {
    expect(canStartUpiPayment("plx@upi")).toBe(true);
    expect(canStartUpiPayment("")).toBe(false);
  });

  it("requires both a transaction reference and screenshot before proof can be submitted", () => {
    expect(canSubmitPaymentProof("UPI-REF-001", "data:image/png;base64,abc")).toBe(true);
    expect(canSubmitPaymentProof("", "data:image/png;base64,abc")).toBe(false);
    expect(canSubmitPaymentProof("12345", "data:image/png;base64,abc")).toBe(false);
    expect(canSubmitPaymentProof("UPI-REF-001", "")).toBe(false);
  });

  it("locks a valid proof submission while another payment request is being sent", () => {
    expect(canSubmitPaymentProof("UPI-REF-001", "data:image/png;base64,abc", true)).toBe(false);
  });

  it("locks the submit action while sending and exposes the pending-review confirmation after success", () => {
    expect(paymentSubmissionUiState(true, false)).toMatchObject({ isLocked: true, buttonLabel: "SUBMITTING PAYMENT PROOF", showPendingConfirmation: false });
    expect(paymentSubmissionUiState(false, true)).toMatchObject({ isLocked: true, buttonLabel: "SUBMIT PAYMENT FOR VERIFICATION", showPendingConfirmation: true });
  });

  it("creates a mobile UPI intent containing the configured payee and selected package value", () => {
    const result = buildUpiPaymentUrl("plx@upi", 70, 70);
    expect(result).toContain("upi://pay?");
    expect(result).toContain("pa=plx%40upi");
    expect(result).toContain("am=70");
    expect(result).toContain("cu=INR");
  });
});
