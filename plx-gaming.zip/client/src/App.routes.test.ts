import { readFileSync } from "node:fs";
import { describe, expect, it } from "vitest";

describe("PLX public route map", () => {
  it("keeps the header's /tournaments destination mapped to the upcoming tournament list", () => {
    const source = readFileSync(new URL("./App.tsx", import.meta.url), "utf8");

    expect(source).toContain('<Route path="/tournaments"><Tournaments status="upcoming" /></Route>');
  });
});
