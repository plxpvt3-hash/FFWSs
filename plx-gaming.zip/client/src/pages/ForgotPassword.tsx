import { PublicLayout } from "@/components/PublicLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { trpc } from "@/lib/trpc";
import { ArrowLeft, Mail, Send } from "lucide-react";
import { FormEvent, useState } from "react";
import { toast } from "sonner";
import { Link, useLocation } from "wouter";

export default function ForgotPassword() {
  const [, setLocation] = useLocation();
  const [email, setEmail] = useState("");
  const [submitted, setSubmitted] = useState(false);
  const requestReset = trpc.auth.requestPasswordReset.useMutation();

  const submit = async (event: FormEvent) => {
    event.preventDefault();
    try {
      await requestReset.mutateAsync({ email });
      setSubmitted(true);
    } catch (error: any) {
      toast.error(error?.message ?? "We could not start a password reset. Please try again shortly.");
    }
  };

  return <PublicLayout><section className="relative isolate overflow-hidden py-10 sm:py-16"><div className="absolute inset-0 -z-10 hero-grid opacity-60" /><div className="absolute left-1/2 top-0 -z-10 h-[28rem] w-[32rem] -translate-x-1/2 rounded-full bg-cyan-400/10 blur-3xl" /><div className="container mx-auto max-w-lg px-4"><Link href="/auth" className="inline-flex items-center gap-2 text-xs font-bold text-slate-400 transition hover:text-cyan-200"><ArrowLeft size={14} />BACK TO SIGN IN</Link><div className="mt-5 rounded-[1.8rem] border border-white/[.12] bg-[#0b1325]/95 p-6 shadow-[0_24px_70px_rgba(0,0,0,.35)] sm:p-8"><p className="text-[10px] font-black tracking-[.2em] text-cyan-200">ACCOUNT RECOVERY</p><h1 className="mt-3 font-display text-3xl font-black text-white">RESET YOUR <span className="text-gradient-cyan">PASSWORD.</span></h1>{submitted ? <div className="mt-6 rounded-2xl border border-cyan-300/20 bg-cyan-300/5 p-5 text-sm leading-6 text-slate-300"><Send className="mb-3 text-cyan-200" size={22} /><strong className="block text-white">Check your inbox.</strong>If a PLX account exists for this address, we sent a secure password-reset link. It expires in 60 minutes.</div> : <form onSubmit={submit} className="mt-6 grid gap-5"><p className="text-sm leading-6 text-slate-400">Enter your registered email address. We will send a secure, one-time reset link if the account is eligible.</p><div className="grid gap-2"><Label htmlFor="email" className="text-xs font-bold text-slate-300">Registered email</Label><div className="relative"><Mail className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-500" /><Input id="email" type="email" value={email} onChange={(event) => setEmail(event.target.value)} autoComplete="email" required maxLength={320} placeholder="you@example.com" className="h-12 border-white/10 bg-white/[.03] pl-10 text-white placeholder:text-slate-600" /></div></div><Button type="submit" disabled={requestReset.isPending} className="h-12 rounded-xl bg-gradient-to-r from-cyan-300 to-sky-400 text-xs font-black tracking-[.1em] text-[#051321]">{requestReset.isPending ? "SENDING RESET LINK" : "SEND RESET LINK"}</Button></form>}<button type="button" onClick={() => setLocation("/auth")} className="mt-6 w-full text-center text-xs font-bold text-slate-500 transition hover:text-white">Return to PLX sign in</button></div></div></section></PublicLayout>;
}
