import { PublicLayout } from "@/components/PublicLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { trpc } from "@/lib/trpc";
import { KeyRound, ShieldCheck } from "lucide-react";
import { FormEvent, useState } from "react";
import { toast } from "sonner";
import { Link } from "wouter";
import { getPasswordResetToken } from "@/lib/passwordReset";

export default function ResetPassword() {
  const token = getPasswordResetToken(typeof window === "undefined" ? "" : window.location.search);
  const [password, setPassword] = useState("");
  const [confirmation, setConfirmation] = useState("");
  const [complete, setComplete] = useState(false);
  const reset = trpc.auth.resetPassword.useMutation();
  const submit = async (event: FormEvent) => {
    event.preventDefault();
    if (password !== confirmation) return toast.error("Password confirmation does not match.");
    try { await reset.mutateAsync({ token, password }); setComplete(true); } catch (error: any) { toast.error(error?.message ?? "This reset link could not be used."); }
  };
  const invalidLink = token.length < 40;
  return <PublicLayout><section className="relative isolate overflow-hidden py-10 sm:py-16"><div className="absolute inset-0 -z-10 hero-grid opacity-60" /><div className="absolute right-1/3 top-0 -z-10 h-[28rem] w-[32rem] rounded-full bg-violet-500/15 blur-3xl" /><div className="container mx-auto max-w-lg px-4"><div className="rounded-[1.8rem] border border-white/[.12] bg-[#0b1325]/95 p-6 shadow-[0_24px_70px_rgba(0,0,0,.35)] sm:p-8"><p className="text-[10px] font-black tracking-[.2em] text-cyan-200">ACCOUNT RECOVERY</p><h1 className="mt-3 font-display text-3xl font-black text-white">SET A NEW <span className="text-gradient-cyan">PASSWORD.</span></h1>{complete ? <div className="mt-6 rounded-2xl border border-cyan-300/20 bg-cyan-300/5 p-5 text-sm leading-6 text-slate-300"><ShieldCheck className="mb-3 text-cyan-200" size={22} /><strong className="block text-white">Password updated.</strong>For your protection, other account sessions were signed out. Sign in with your new password.</div> : invalidLink ? <div className="mt-6 rounded-2xl border border-rose-300/20 bg-rose-300/5 p-5 text-sm leading-6 text-slate-300">This password-reset link is incomplete or invalid. Request a new secure link to continue.</div> : <form onSubmit={submit} className="mt-6 grid gap-5"><p className="text-sm leading-6 text-slate-400">Choose a new password with at least 10 characters. Your password is securely hashed before storage.</p><div className="grid gap-2"><Label htmlFor="new-password" className="text-xs font-bold text-slate-300">New password</Label><div className="relative"><KeyRound className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-500" /><Input id="new-password" type="password" value={password} onChange={(event) => setPassword(event.target.value)} autoComplete="new-password" required minLength={10} maxLength={128} placeholder="At least 10 characters" className="h-12 border-white/10 bg-white/[.03] pl-10 text-white placeholder:text-slate-600" /></div></div><div className="grid gap-2"><Label htmlFor="confirm-password" className="text-xs font-bold text-slate-300">Confirm new password</Label><Input id="confirm-password" type="password" value={confirmation} onChange={(event) => setConfirmation(event.target.value)} autoComplete="new-password" required minLength={10} maxLength={128} placeholder="Repeat your new password" className="h-12 border-white/10 bg-white/[.03] text-white placeholder:text-slate-600" /></div><Button type="submit" disabled={reset.isPending} className="h-12 rounded-xl bg-gradient-to-r from-cyan-300 to-sky-400 text-xs font-black tracking-[.1em] text-[#051321]">{reset.isPending ? "UPDATING PASSWORD" : "UPDATE PASSWORD"}</Button></form>}<Link href="/auth" className="mt-6 block text-center text-xs font-bold text-cyan-200 transition hover:text-cyan-100">{complete ? "SIGN IN TO PLX" : "RETURN TO PLX SIGN IN"}</Link></div></div></section></PublicLayout>;
}
