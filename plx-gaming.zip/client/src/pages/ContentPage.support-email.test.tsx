// @vitest-environment jsdom
import { cleanup, fireEvent, render, screen, waitFor } from "@testing-library/react";
import { createElement } from "react";
import * as React from "react";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

const mocks = vi.hoisted(() => ({ writeText: vi.fn(), toastSuccess: vi.fn() }));
const { writeText, toastSuccess } = mocks;

vi.mock("@/components/PublicLayout", () => ({ PublicLayout: ({ children }: { children: React.ReactNode }) => createElement("div", null, children) }));
vi.mock("@/lib/trpc", () => ({ trpc: { public: { content: { useQuery: () => ({ data: { supportMessage: "Tournament and wallet help is available." } }) } } } }));
vi.mock("sonner", () => ({ toast: { success: mocks.toastSuccess, error: vi.fn() } }));

import ContentPage from "./ContentPage";

beforeEach(() => {
  vi.stubGlobal("React", React);
  writeText.mockResolvedValue(undefined);
  Object.defineProperty(navigator, "clipboard", { configurable: true, value: { writeText } });
});

afterEach(() => {
  cleanup();
  vi.clearAllMocks();
});

describe("PLX Support Desk email actions", () => {
  it("renders the official email with a pre-addressed compose action and confirms copied addresses", async () => {
    render(createElement(ContentPage, { kind: "support" }));

    const email = "plxpvt3@gmail.com";
    const expectedMailto = "mailto:plxpvt3@gmail.com?subject=PLX%20Gaming%20Support%20Request";
    expect(screen.getByText(email).getAttribute("href")).toBe(expectedMailto);
    expect(screen.getByRole("link", { name: /email support/i }).getAttribute("href")).toBe(expectedMailto);

    fireEvent.click(screen.getByRole("button", { name: /copy email/i }));
    await waitFor(() => expect(writeText).toHaveBeenCalledWith(email));
    expect(toastSuccess).toHaveBeenCalledWith("Support email copied");
  });
});
