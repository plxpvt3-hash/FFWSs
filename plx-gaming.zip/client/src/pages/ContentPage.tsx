import { PublicLayout } from "@/components/PublicLayout";
import { trpc } from "@/lib/trpc";
import { CircleHelp, Copy, CreditCard, LockKeyhole, Mail, ScrollText, ShieldCheck, Trophy } from "lucide-react";
import { toast } from "sonner";

export default function ContentPage({ kind }: { kind: "rules" | "support" | "how-it-works" | "terms" | "privacy" }) {
  const { data } = trpc.public.content.useQuery();
  const supportEmail = "plxpvt3@gmail.com";
  const supportMailto = `mailto:${supportEmail}?subject=${encodeURIComponent("PLX Gaming Support Request")}`;
  const copySupportEmail = async () => {
    try {
      if (navigator.clipboard?.writeText) {
        await navigator.clipboard.writeText(supportEmail);
      } else {
        const selection = document.createElement("textarea");
        selection.value = supportEmail;
        selection.setAttribute("readonly", "");
        selection.style.position = "fixed";
        selection.style.opacity = "0";
        document.body.appendChild(selection);
        selection.select();
        const copied = document.execCommand("copy");
        document.body.removeChild(selection);
        if (!copied) throw new Error("Copy unavailable");
      }
      toast.success("Support email copied");
    } catch {
      toast.error("Unable to copy the support email. Please select the address manually.");
    }
  };
  const isRules = kind === "rules";
  const isHowItWorks = kind === "how-it-works";
  const isLegal = kind === "terms" || kind === "privacy";
  const Icon = isRules ? ScrollText : isHowItWorks ? Trophy : isLegal ? LockKeyhole : CircleHelp;
  const title = isRules ? "Platform rules" : isHowItWorks ? "How PLX works" : kind === "terms" ? "Terms of use" : kind === "privacy" ? "Privacy overview" : "Support desk";
  const description = isRules ? "Keep every PLX tournament competitive, fair, and enjoyable for every player." : isHowItWorks ? "A secure, credit-backed path from tournament discovery to verified results and prize Credits." : kind === "terms" ? "The operating principles for use of PLX Gaming tournament services." : kind === "privacy" ? "How PLX limits player information to the account and tournament operations that need it." : "Get help with tournament entries, payments, account access, and result questions.";
  return <PublicLayout><section className="container max-w-4xl py-10 sm:py-14"><p className="inline-flex items-center gap-2 text-xs font-black tracking-[.16em] text-cyan-300"><Icon size={15} />PLX GAMING</p><h1 className="mt-3 font-display text-4xl font-bold text-white sm:text-5xl">{title}</h1><p className="mt-3 max-w-2xl text-sm leading-6 text-slate-400 sm:text-base">{description}</p>{isRules ? <div className="mt-8 rounded-2xl border border-white/[.09] bg-[#0c1325] p-6 sm:p-8"><div className="flex items-center gap-3 border-b border-white/[.07] pb-5"><span className="grid h-10 w-10 place-items-center rounded-xl bg-cyan-300/10 text-cyan-200"><ShieldCheck size={20} /></span><div><p className="font-display text-xl font-bold text-white">Play fair. Play ready.</p><p className="text-xs text-slate-500">These rules apply alongside tournament-specific requirements.</p></div></div><div className="mt-6 whitespace-pre-wrap text-sm leading-7 text-slate-300">{data?.rules}</div></div> : isHowItWorks ? <div className="mt-8 grid gap-4 sm:grid-cols-3"><HowStep number="01" title="Choose an event" detail="Browse upcoming Solo, Duo, or Squad events and review entry fee, prize pool, time, slots, and tournament rules." icon={<Trophy size={19} />} /><HowStep number="02" title="Confirm your entry" detail="Add your nickname and Free Fire UID, then confirm an entry only after the server checks your account, Credits, and available slot." icon={<ShieldCheck size={19} />} /><HowStep number="03" title="Track the result" detail="Follow your joined tournament, published room details, scores, leaderboard position, prize Credits, and player history." icon={<CreditCard size={19} />} /></div> : isLegal ? <div className="mt-8 grid gap-4 sm:grid-cols-2"><HowStep number="01" title={kind === "terms" ? "Fair participation" : "Private player data"} detail={kind === "terms" ? "Use accurate player details, follow event-specific rules, and do not attempt to bypass tournament, wallet, or result controls." : "Your nickname, Free Fire UID, wallet activity, and tournament history are scoped to your authenticated PLX account and tournament operations."} icon={<ShieldCheck size={19} />} /><HowStep number="02" title={kind === "terms" ? "Credit integrity" : "Controlled visibility"} detail={kind === "terms" ? "Tournament Credits are adjusted only through server-validated entry, verified payment approval, prize, refund, or administrator workflows." : "Unpublished room credentials remain restricted, and public surfaces do not expose private account contact details."} icon={<LockKeyhole size={19} />} /></div> : <div className="mt-8 grid gap-4 sm:grid-cols-2"><div className="rounded-2xl border border-cyan-300/15 bg-cyan-300/[.04] p-6"><Mail className="text-cyan-200" /><h2 className="mt-5 font-display text-xl font-bold text-white">Contact support</h2><p className="mt-2 text-sm leading-6 text-slate-400">{data?.supportMessage}</p><p className="mt-5 text-[10px] font-black tracking-[.14em] text-cyan-100/70">OFFICIAL PLX SUPPORT EMAIL</p><a href={supportMailto} className="mt-2 inline-flex break-all font-display text-base font-bold text-cyan-100 underline decoration-cyan-300/40 underline-offset-4 transition hover:text-white focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-cyan-200" aria-label={`Email ${supportEmail}`}>{supportEmail}</a><div className="mt-5 flex flex-col gap-2 sm:flex-row"><a href={supportMailto} className="inline-flex min-h-11 flex-1 items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-violet-500 to-fuchsia-500 px-4 py-3 text-xs font-black tracking-[.08em] text-white shadow-[0_8px_22px_rgba(192,132,252,.25)] transition active:scale-[.98] hover:from-violet-400 hover:to-fuchsia-400 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-fuchsia-200"><Mail size={15} />EMAIL SUPPORT</a><button type="button" onClick={copySupportEmail} className="inline-flex min-h-11 items-center justify-center gap-2 rounded-xl border border-cyan-200/20 bg-[#081627]/70 px-4 py-3 text-xs font-black tracking-[.08em] text-cyan-100 transition active:scale-[.98] hover:border-cyan-200/45 hover:bg-cyan-300/[.08] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-cyan-200"><Copy size={15} />COPY EMAIL</button></div></div><div className="rounded-2xl border border-white/[.09] bg-[#0c1325] p-6"><p className="text-[10px] font-black tracking-[.16em] text-violet-200">FASTER RESOLUTION</p><h2 className="mt-4 font-display text-xl font-bold text-white">Include the essentials</h2><p className="mt-3 text-sm leading-6 text-slate-400">When writing in, include your player name, tournament name, UTR number where relevant, and a concise description of what happened.</p></div></div>}</section></PublicLayout>;
}

function HowStep({ number, title, detail, icon }: { number: string; title: string; detail: string; icon: React.ReactNode }) { return <article className="rounded-2xl border border-white/[.09] bg-[#0c1325] p-5"><div className="flex items-center justify-between"><span className="grid h-10 w-10 place-items-center rounded-xl bg-cyan-300/[.08] text-cyan-200">{icon}</span><span className="font-display text-xs font-black tracking-[.16em] text-violet-200">{number}</span></div><h2 className="mt-6 font-display text-xl font-bold text-white">{title}</h2><p className="mt-2 text-sm leading-6 text-slate-400">{detail}</p></article>; }
