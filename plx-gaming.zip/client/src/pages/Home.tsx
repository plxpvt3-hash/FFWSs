import { useAuth } from "@/_core/hooks/useAuth";
import { PublicLayout } from "@/components/PublicLayout";
import { trpc } from "@/lib/trpc";
import { ArrowRight, Crown, Flame, Radio, Swords, Trophy, UsersRound } from "lucide-react";
import { useEffect } from "react";
import { Link } from "wouter";

const formatNumber = (value: number) => new Intl.NumberFormat("en-IN").format(value);

export default function Home() {
  const { user } = useAuth();
  const { data, isLoading } = trpc.public.home.useQuery(undefined, { staleTime: 30_000 });

  useEffect(() => {
    document.documentElement.classList.add("plx-home-scroll-lock");
    document.body.classList.add("plx-home-scroll-lock");

    return () => {
      document.documentElement.classList.remove("plx-home-scroll-lock");
      document.body.classList.remove("plx-home-scroll-lock");
    };
  }, []);

  const stats = [
    { label: "PLAYERS", value: formatNumber(data?.stats?.totalPlayers ?? 0), icon: UsersRound },
    { label: "EVENTS", value: formatNumber(data?.stats?.totalTournaments ?? 0), icon: Trophy },
    { label: "PRIZE CR", value: formatNumber(data?.stats?.totalPrizeCredits ?? 0), icon: Crown },
  ];
  const liveName = data?.live?.name;

  return (
    <PublicLayout>
      <section className="home-dashboard" data-testid="plx-home-screen" aria-label="PLX Tournament home dashboard">
        <div className="home-app-frame">
          <div className="pointer-events-none absolute inset-0 -z-10 overflow-hidden" aria-hidden="true">
            {data?.home?.heroBannerUrl ? <img src={data.home.heroBannerUrl} alt="" className="absolute inset-0 h-full w-full object-cover opacity-[.07]" /> : null}
            <div className="absolute inset-0 bg-[radial-gradient(ellipse_88%_56%_at_72%_5%,rgba(167,75,255,.30),transparent_62%),radial-gradient(ellipse_65%_47%_at_6%_92%,rgba(90,41,220,.24),transparent_64%),linear-gradient(150deg,#090513_0%,#11091d_56%,#0b0615_100%)]" />
            <div className="absolute -right-24 top-[9%] h-72 w-72 rounded-full border border-fuchsia-300/[.16] bg-fuchsia-400/[.07] blur-3xl" />
            <div className="absolute -bottom-28 -left-20 h-72 w-72 rounded-full border border-violet-300/[.15] bg-violet-500/[.11] blur-3xl" />
            <div className="hero-grid absolute inset-x-0 bottom-0 h-[55%] opacity-45" />
          </div>

          <div className="relative flex min-h-0 flex-1 flex-col justify-center px-5 py-[clamp(1rem,3.5dvh,2rem)] sm:px-7">
            <div className="home-status-row">
              <span className="inline-flex items-center gap-1.5 text-[9px] font-black tracking-[.16em] text-violet-100"><span className="home-pulse-dot" />PLX SEASON 01</span>
              <span className="inline-flex items-center gap-1.5 rounded-full border border-fuchsia-300/25 bg-fuchsia-400/[.08] px-2.5 py-1 text-[8px] font-black tracking-[.14em] text-fuchsia-100"><Flame size={11} aria-hidden="true" />FREE FIRE</span>
            </div>

            <h1 className="home-hero-title mt-[clamp(1rem,3.2dvh,1.75rem)] font-display font-black tracking-[-.065em] text-white">
              <span className="block">Play. Compete.</span>
              <span className="block bg-gradient-to-r from-violet-200 via-fuchsia-200 to-purple-400 bg-clip-text text-transparent">Become Champion.</span>
            </h1>
            <p className="home-hero-copy mt-[clamp(.7rem,2dvh,1rem)] max-w-[31rem] text-slate-300">
              Join professional Free Fire tournaments, compete with squads and climb the FFWS leaderboard.
            </p>

            <div className="mt-[clamp(1rem,3dvh,1.5rem)] grid grid-cols-1 gap-2.5 sm:grid-cols-2">
              <Link href="/tournaments/upcoming" className="home-primary-action plx-press">
                JOIN TOURNAMENT <ArrowRight size={17} aria-hidden="true" />
              </Link>
              <Link href={user ? "/dashboard" : "/auth"} className="home-secondary-action plx-press">
                PLAYER DASHBOARD <Swords size={16} aria-hidden="true" />
              </Link>
            </div>

            <section className="home-spotlight-card mt-[clamp(1rem,3.1dvh,1.75rem)]" aria-label="Tournament update">
              <div className="flex min-w-0 items-center gap-3">
                <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl border border-violet-200/25 bg-violet-300/[.11] text-violet-100 shadow-[0_0_22px_rgba(167,119,255,.14)]"><Radio size={18} /></span>
                <div className="min-w-0">
                  <p className="text-[8px] font-black tracking-[.16em] text-fuchsia-200">{liveName ? "LIVE ARENA" : "TOURNAMENT COMMAND"}</p>
                  {isLoading ? <span className="plx-skeleton mt-1.5 block h-3.5 w-44 rounded" aria-label="Loading tournament update" /> : <p className="mt-1 truncate text-xs font-extrabold text-white">{liveName || data?.announcements?.[0]?.message || "Official brackets are opening soon."}</p>}
                </div>
              </div>
              <Link href={liveName ? "/tournaments/live" : "/tournaments/upcoming"} className="home-card-link plx-press" aria-label={liveName ? "View live tournaments" : "View upcoming tournaments"}><ArrowRight size={17} /></Link>
            </section>

            <dl className="home-stat-grid mt-[clamp(.8rem,2.7dvh,1.4rem)]" aria-label="PLX platform statistics">
              {stats.map(({ label, value, icon: Icon }) => (
                <div key={label} className="home-stat-item">
                  <Icon size={13} className="text-violet-200" aria-hidden="true" />
                  <div className="min-w-0">
                    <dt>{label}</dt>
                    {isLoading ? <dd className="plx-skeleton mt-1 h-4 w-10 rounded" aria-label={`Loading ${label}`} /> : <dd>{value}</dd>}
                  </div>
                </div>
              ))}
            </dl>
          </div>
        </div>
      </section>
    </PublicLayout>
  );
}
