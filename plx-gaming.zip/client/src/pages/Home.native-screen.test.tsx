// @vitest-environment jsdom
import { cleanup, render, screen } from "@testing-library/react";
import { createElement } from "react";
import * as React from "react";
import { afterEach, describe, expect, it, vi } from "vitest";

vi.mock("@/_core/hooks/useAuth", () => ({ useAuth: () => ({ user: null }) }));
vi.mock("@/components/PublicLayout", () => ({ PublicLayout: ({ children }: { children: React.ReactNode }) => createElement("div", null, children) }));
vi.mock("@/lib/trpc", () => ({
  trpc: {
    public: {
      home: { useQuery: () => ({ isLoading: false, data: { stats: { totalPlayers: 42, totalTournaments: 7, totalPrizeCredits: 3000 }, announcements: [] } }) },
    },
  },
}));

import Home from "./Home";

afterEach(() => {
  cleanup();
  document.documentElement.classList.remove("plx-home-scroll-lock");
  document.body.classList.remove("plx-home-scroll-lock");
});

describe("PLX native Home screen", () => {
  it("renders the compact tournament dashboard and locks document scrolling only while mounted", () => {
    vi.stubGlobal("React", React);
    const view = render(createElement(Home));

    expect(screen.getByTestId("plx-home-screen").className).toContain("home-dashboard");
    const heroHeading = screen.getByRole("heading", { level: 1 });
    expect(heroHeading.textContent).toContain("Play. Compete.");
    expect(heroHeading.textContent).toContain("Become Champion.");
    expect(screen.getByRole("link", { name: /join tournament/i }).getAttribute("href")).toBe("/tournaments/upcoming");
    expect(screen.getByRole("link", { name: /player dashboard/i }).getAttribute("href")).toBe("/auth");
    expect(document.documentElement.classList.contains("plx-home-scroll-lock")).toBe(true);
    expect(document.body.classList.contains("plx-home-scroll-lock")).toBe(true);

    view.unmount();
    expect(document.documentElement.classList.contains("plx-home-scroll-lock")).toBe(false);
    expect(document.body.classList.contains("plx-home-scroll-lock")).toBe(false);
  });
});
