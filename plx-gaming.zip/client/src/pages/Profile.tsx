import { PlayerGate } from "@/components/PlayerGate";
import { PublicLayout } from "@/components/PublicLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useAuth } from "@/_core/hooks/useAuth";
import { formatCredits, formatDateShort, titleCase } from "@/lib/format";
import { trpc } from "@/lib/trpc";
import { cn } from "@/lib/utils";
import { Award, BadgeCheck, Camera, ChevronRight, CircleDollarSign, Crosshair, Gamepad2, KeyRound, Link2, LockKeyhole, LogOut, Medal, Pencil, ShieldCheck, Sparkles, Target, Trophy, Unlink, UserRound, WalletCards } from "lucide-react";
import { ChangeEvent, useEffect, useRef, useState } from "react";
import { toast } from "sonner";
import { Link } from "wouter";

type ProfileTab = "overview" | "tournaments" | "credits";
const tabs: { id: ProfileTab; label: string; icon: typeof UserRound }[] = [
  { id: "overview", label: "Overview", icon: UserRound },
  { id: "tournaments", label: "My Tournaments", icon: Trophy },
  { id: "credits", label: "Credits", icon: WalletCards },
];

export default function Profile() {
  return <PublicLayout><section className="plx-profile-content mx-auto w-full max-w-md px-4 py-4 sm:max-w-5xl sm:px-6 sm:py-6"><PlayerGate><ProfileContent /></PlayerGate></section></PublicLayout>;
}

function ProfileContent() {
  const { data, isLoading, isError } = trpc.player.profileOverview.useQuery();
  const googleStatus = trpc.auth.googleStatus.useQuery();
  const { logout } = useAuth();
  const utils = trpc.useUtils();
  const [activeTab, setActiveTab] = useState<ProfileTab>("overview");
  const [isEditing, setIsEditing] = useState(false);
  const [displayName, setDisplayName] = useState("");
  const [playerName, setPlayerName] = useState("");
  const [gameUid, setGameUid] = useState("");
  const [preferredGameMode, setPreferredGameMode] = useState<"solo" | "duo" | "squad">("solo");
  const [avatarDataUrl, setAvatarDataUrl] = useState<string | undefined>();
  const [avatarPreview, setAvatarPreview] = useState<string | null>(null);
  const editorRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!data) return;
    setDisplayName(data.profile.displayName || data.profile.playerName);
    setPlayerName(data.profile.playerName);
    setGameUid(data.profile.gameUid);
    if (data.profile.preferredGameMode === "duo" || data.profile.preferredGameMode === "squad" || data.profile.preferredGameMode === "solo") setPreferredGameMode(data.profile.preferredGameMode);
  }, [data]);

  useEffect(() => {
    if (new URLSearchParams(window.location.search).get("google") !== "linked") return;
    toast.success("Google account linked securely to your PLX profile.");
    window.history.replaceState({}, "", window.location.pathname);
    utils.auth.googleStatus.invalidate();
  }, [utils.auth.googleStatus]);

  const nameValid = /^[A-Za-z0-9][A-Za-z0-9 _.'-]*$/.test(playerName.trim()) && playerName.trim().length >= 3 && playerName.trim().length <= 32;
  const displayNameValid = /^[A-Za-z0-9][A-Za-z0-9 _.'-]*$/.test(displayName.trim()) && displayName.trim().length >= 3 && displayName.trim().length <= 32;
  const uidValid = /^\d{6,20}$/.test(gameUid);
  const save = trpc.player.profile.useMutation({
    onSuccess: () => {
      toast.success("Your private player profile has been saved.");
      setAvatarDataUrl(undefined); setIsEditing(false);
      utils.player.profileOverview.invalidate(); utils.player.dashboard.invalidate(); utils.player.myTournaments.invalidate();
    },
    onError: (error) => toast.error(error.message),
  });
  const unlinkGoogle = trpc.auth.unlinkGoogle.useMutation({
    onSuccess: () => { toast.success("Google account unlinked. Your PLX password remains available for sign-in."); utils.auth.googleStatus.invalidate(); },
    onError: (error) => toast.error(error.message),
  });
  const logoutAll = trpc.auth.logoutAllLocalSessions.useMutation({
    onSuccess: () => { toast.success("All PLX password sessions were revoked."); window.location.assign("/auth"); },
    onError: (error) => toast.error(error.message),
  });
  const handleAvatar = (event: ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]; if (!file) return;
    if (!["image/png", "image/jpeg", "image/webp"].includes(file.type)) return toast.error("Choose a PNG, JPEG, or WebP avatar.");
    if (file.size > 4 * 1024 * 1024) return toast.error("Avatar images must be smaller than 4 MB.");
    const reader = new FileReader();
    reader.onload = () => { const result = typeof reader.result === "string" ? reader.result : undefined; setAvatarDataUrl(result); setAvatarPreview(result ?? null); };
    reader.readAsDataURL(file);
  };
  const openEditor = () => { setActiveTab("overview"); setIsEditing(true); window.setTimeout(() => editorRef.current?.scrollIntoView({ behavior: "smooth", block: "start" }), 30); };

  if (isLoading) return <ProfileSkeleton />;
  if (isError || !data) return <div className="plx-profile-empty"><ShieldCheck size={22} /><p className="font-display text-lg font-bold">PROFILE UNAVAILABLE</p><p>We could not load your private player profile. Please refresh and try again.</p></div>;

  const avatar = avatarPreview || data.profile.avatarUrl;
  const verifiedResults = data.entries.filter((entry: any) => entry.tournament.status === "completed" || entry.rank !== null);
  const identityName = data.profile.displayName || data.profile.playerName;
  return <div className="pb-2">
    <header className="mb-4 flex items-center justify-between gap-3 sm:mb-6">
      <div><p className="plx-eyebrow">PRIVATE PLAYER PROFILE</p><h1 className="mt-1 font-display text-[clamp(1.35rem,6vw,2rem)] font-black tracking-[-.03em] text-white">Your PLX esports identity</h1></div>
      <span className={cn("flex shrink-0 items-center gap-1 rounded-full border px-2.5 py-1.5 text-[9px] font-black tracking-[.11em]", googleStatus.data?.linked ? "border-violet-300/30 bg-violet-300/[.1] text-violet-100" : "border-white/[.11] bg-white/[.04] text-slate-300")}><BadgeCheck size={13} />{googleStatus.data?.linked ? "SECURED" : "PRIVATE"}</span>
    </header>

    <section className="plx-profile-identity overflow-hidden rounded-[1.65rem] border border-violet-300/[.19] p-4 sm:p-6">
      <div className="flex items-start gap-4">
        <div className="relative shrink-0"><div className="grid h-[84px] w-[84px] place-items-center overflow-hidden rounded-[1.45rem] border-2 border-fuchsia-300/35 bg-gradient-to-br from-violet-500/30 to-[#161025] shadow-[0_0_35px_rgba(181,133,255,.22)] sm:h-28 sm:w-28">{avatar ? <img src={avatar} alt="Player avatar" className="h-full w-full object-cover" /> : <span className="font-display text-3xl font-black text-violet-100 sm:text-4xl">{identityName.slice(0, 1).toUpperCase()}</span>}</div><label className="absolute -bottom-1.5 -right-1.5 grid h-9 w-9 cursor-pointer place-items-center rounded-xl border border-fuchsia-200/35 bg-fuchsia-400 text-[#1a0625] shadow-[0_0_20px_rgba(244,114,182,.28)] transition hover:brightness-110 active:scale-95" title="Change avatar"><Camera size={15} /><input type="file" accept="image/png,image/jpeg,image/webp" onChange={handleAvatar} className="sr-only" /></label></div>
        <div className="min-w-0 flex-1"><p className="truncate font-display text-xl font-black text-white sm:text-3xl">{identityName}</p><p className="mt-1 text-xs font-bold text-violet-100">@{data.profile.playerName}</p><div className="mt-3 flex flex-wrap gap-1.5"><IdentityPill label="UID" value={data.profile.gameUid || "Not set"} /><IdentityPill label="PLX ID" value={data.profile.playerId} /></div><p className="mt-3 text-[11px] text-slate-400">Member since <span className="font-bold text-slate-200">{formatDateShort(data.profile.joinedAt)}</span> · Visible only to you</p></div>
      </div>
      <div className="mt-4 grid grid-cols-3 gap-2 border-t border-white/[.08] pt-4"><Metric value={String(data.stats.matchesPlayed)} label="Matches" /><Metric value={String(data.stats.tournamentsWon)} label="Wins" highlight /><Metric value={`${data.stats.winRate}%`} label="Win rate" /></div>
    </section>

    <section className="mt-3 grid grid-cols-2 gap-2 sm:grid-cols-4"><ActionButton icon={<Pencil size={15} />} label="Edit Profile" onClick={openEditor} /><ActionLink icon={<WalletCards size={15} />} label="Wallet" href="/wallet" /><ActionButton icon={<Trophy size={15} />} label="My Tournaments" onClick={() => setActiveTab("tournaments")} /><ActionButton icon={<LogOut size={15} />} label="Log out" tone="rose" onClick={() => { if (window.confirm("Sign out of this PLX session?")) void logout(); }} /></section>

    <div className="mt-4 flex gap-1.5 overflow-x-auto rounded-2xl border border-white/[.09] bg-[#0e0a19]/90 p-1.5" role="tablist" aria-label="Private profile sections">{tabs.map((tab) => { const Icon = tab.icon; return <button key={tab.id} type="button" onClick={() => setActiveTab(tab.id)} className={cn("flex min-w-fit flex-1 items-center justify-center gap-1.5 rounded-xl px-3 py-2.5 text-[11px] font-black transition active:scale-[.97]", activeTab === tab.id ? "bg-gradient-to-r from-violet-400 to-fuchsia-400 text-[#170921] shadow-[0_0_22px_rgba(206,132,255,.24)]" : "text-slate-400 hover:bg-white/[.05] hover:text-white")} role="tab" aria-selected={activeTab === tab.id}><Icon size={14} />{tab.label}</button>; })}</div>

    {activeTab === "overview" && <Overview data={data} googleStatus={googleStatus.data} isEditing={isEditing} editorRef={editorRef} displayName={displayName} playerName={playerName} gameUid={gameUid} preferredGameMode={preferredGameMode} setDisplayName={setDisplayName} setPlayerName={setPlayerName} setGameUid={setGameUid} setPreferredGameMode={setPreferredGameMode} onSave={() => save.mutate({ displayName: displayName.trim(), playerName: playerName.trim(), gameUid, preferredGameMode, avatarDataUrl })} saving={save.isPending} valid={displayNameValid && nameValid && uidValid} onClose={() => setIsEditing(false)} onUnlink={() => { if (window.confirm("Unlink Google? You will continue with your PLX password.")) unlinkGoogle.mutate(); }} unlinking={unlinkGoogle.isPending} onLogoutAll={() => { if (window.confirm("Log out every PLX password session? You will need to sign in again.")) logoutAll.mutate(); }} loggingOutAll={logoutAll.isPending} />}
    {activeTab === "tournaments" && <TournamentTab entries={data.entries} />}
    {activeTab === "credits" && <CreditsTab balance={data.balance} winnings={data.winningBalance} bonus={data.bonusBalance} transactions={data.transactions} />}
  </div>;
}

function Overview({ data, googleStatus, isEditing, editorRef, displayName, playerName, gameUid, preferredGameMode, setDisplayName, setPlayerName, setGameUid, setPreferredGameMode, onSave, saving, valid, onClose, onUnlink, unlinking, onLogoutAll, loggingOutAll }: any) {
  const stats = data.stats;
  const achievements = [
    { icon: <Trophy size={16} />, label: "First Drop", detail: "Complete your first PLX match", unlocked: stats.matchesPlayed >= 1 },
    { icon: <Award size={16} />, label: "Champion", detail: "Earn a verified #1 finish", unlocked: stats.tournamentsWon >= 1 },
    { icon: <Crosshair size={16} />, label: "Frag Hunter", detail: `${stats.totalKills}/50 verified kills`, unlocked: stats.totalKills >= 50 },
  ];
  return <div className="mt-4 space-y-3">
    <section className="grid grid-cols-2 gap-2 sm:grid-cols-4"><StatTile icon={<Trophy />} label="Tournaments" value={String(stats.totalTournaments)} /><StatTile icon={<Medal />} label="Best rank" value={stats.bestRank ? `#${stats.bestRank}` : "—"} /><StatTile icon={<Crosshair />} label="Total kills" value={String(stats.totalKills)} /><StatTile icon={<CircleDollarSign />} label="Prize credits" value={`${formatCredits(stats.totalPrizeCredits)} CR`} /></section>
    <section className="plx-profile-panel"><div className="flex items-center justify-between gap-3"><div><p className="plx-eyebrow">ACHIEVEMENTS</p><h2 className="mt-1 font-display text-lg font-bold text-white">Verified player milestones</h2></div><Sparkles size={19} className="text-fuchsia-200" /></div><div className="mt-3 grid gap-2 sm:grid-cols-3">{achievements.map((achievement) => <div key={achievement.label} className={cn("rounded-2xl border p-3", achievement.unlocked ? "border-fuchsia-300/25 bg-fuchsia-300/[.08] text-fuchsia-100" : "border-white/[.07] bg-white/[.025] text-slate-500")}><div className="flex items-center gap-2 text-xs font-black">{achievement.icon}{achievement.label}</div><p className="mt-2 text-[11px] leading-4 text-slate-400">{achievement.unlocked ? "Verified achievement unlocked" : achievement.detail}</p></div>)}</div></section>
    <section className="plx-profile-wallet"><div className="flex items-center justify-between gap-3"><div><p className="plx-eyebrow">WALLET SNAPSHOT</p><p className="mt-1 font-display text-2xl font-black text-white">{formatCredits(data.balance)} <span className="text-sm text-violet-100">CR</span></p><p className="mt-1 text-[11px] text-slate-400">Tournament Credits available for your next entry.</p></div><Link href="/wallet"><Button className="h-10 rounded-xl bg-violet-300 px-3 text-[10px] font-black tracking-[.08em] text-[#150923] hover:bg-violet-200">OPEN WALLET <ChevronRight size={14} /></Button></Link></div></section>
    <section className="plx-profile-panel"><div className="flex items-center justify-between"><div><p className="plx-eyebrow">ACCOUNT & SECURITY</p><h2 className="mt-1 font-display text-lg font-bold text-white">Your private account controls</h2></div><LockKeyhole size={18} className="text-violet-200" /></div><div className="mt-3 divide-y divide-white/[.07] rounded-2xl border border-white/[.07] bg-black/10"><SecurityRow icon={<ShieldCheck />} title={googleStatus?.linked ? "Google sign-in connected" : "PLX sign-in protected"} detail={googleStatus?.linked ? `Verified Google account: ${googleStatus.email}` : "Use a password or link Google for an additional sign-in method."} action={googleStatus?.linked ? <Button variant="ghost" onClick={onUnlink} disabled={!googleStatus.canUnlink || unlinking} className="h-8 px-2 text-[10px] font-black text-violet-100 hover:bg-violet-300/10">{unlinking ? "UNLINKING…" : <><Unlink size={13} /> UNLINK</>}</Button> : <Button variant="ghost" onClick={() => window.location.assign("/api/auth/google/start?intent=link&next=%2Fprofile")} className="h-8 px-2 text-[10px] font-black text-violet-100 hover:bg-violet-300/10"><Link2 size={13} /> LINK</Button>} /><SecurityRow icon={<KeyRound />} title="Change password" detail="Password reset uses a secure, single-use email link." action={<Link href="/forgot-password"><Button variant="ghost" className="h-8 px-2 text-[10px] font-black text-violet-100 hover:bg-violet-300/10">CHANGE</Button></Link>} /><SecurityRow icon={<LogOut />} title="Log out all PLX password sessions" detail="Revokes active password sessions across your devices and signs this device out." action={<Button variant="ghost" onClick={onLogoutAll} disabled={loggingOutAll} className="h-8 px-2 text-[10px] font-black text-rose-200 hover:bg-rose-300/10">{loggingOutAll ? "SIGNING OUT…" : "LOG OUT ALL"}</Button>} /><SecurityRow icon={<UserRound />} title="Account deletion" detail="A verified support request is required before permanent account removal." action={<Button variant="ghost" onClick={() => { if (window.confirm("Open Support to request verified account deletion?")) window.location.assign("/support"); }} className="h-8 px-2 text-[10px] font-black text-slate-300 hover:bg-white/[.06]">REQUEST</Button>} /></div></section>
    {isEditing && <section ref={editorRef} className="plx-profile-panel scroll-mt-4"><div className="flex items-center justify-between"><div><p className="plx-eyebrow">EDIT PROFILE</p><h2 className="mt-1 font-display text-lg font-bold text-white">Your game identity</h2></div><Button variant="ghost" onClick={onClose} className="h-8 text-xs text-slate-400">Close</Button></div><div className="mt-4 grid gap-3 sm:grid-cols-2"><Field label="Display name"><Input value={displayName} onChange={(event) => setDisplayName(event.target.value.slice(0, 32))} maxLength={32} className="plx-profile-input" placeholder="Your PLX display name" /></Field><Field label="Player nickname"><Input value={playerName} onChange={(event) => setPlayerName(event.target.value.slice(0, 32))} maxLength={32} className="plx-profile-input" placeholder="Your Free Fire nickname" /></Field><Field label="Free Fire UID"><div className="relative"><Gamepad2 className="absolute left-3 top-3 h-4 w-4 text-violet-200" /><Input value={gameUid} onChange={(event) => setGameUid(event.target.value.replace(/\D/g, "").slice(0, 20))} inputMode="numeric" maxLength={20} className="plx-profile-input pl-10" placeholder="6–20 digit UID" /></div></Field><Field label="Preferred game mode"><select value={preferredGameMode} onChange={(event) => setPreferredGameMode(event.target.value as "solo" | "duo" | "squad")} className="plx-profile-input h-10 w-full appearance-none"><option value="solo">Solo</option><option value="duo">Duo</option><option value="squad">Squad</option></select></Field></div><p className="mt-3 rounded-xl border border-violet-300/15 bg-violet-300/[.05] p-3 text-[11px] leading-5 text-slate-400"><ShieldCheck className="mr-1 inline h-4 w-4 text-violet-200" />PLX ID, balances, tournament results, ranks, and verified statistics are managed securely by the platform and cannot be edited here.</p><Button onClick={onSave} disabled={!valid || saving} className="mt-3 h-11 w-full rounded-xl bg-gradient-to-r from-violet-400 to-fuchsia-400 text-xs font-black tracking-[.1em] text-[#170821] hover:brightness-110">{saving ? "SAVING…" : "SAVE PLAYER PROFILE"}</Button></section>}
  </div>;
}

function TournamentTab({ entries }: { entries: any[] }) { if (!entries.length) return <EmptyState icon={<Trophy />} title="NO TOURNAMENTS YET" detail="Join an upcoming PLX match to start building your private player history." action="EXPLORE TOURNAMENTS" href="/tournaments/upcoming" />; return <div className="mt-4 space-y-2.5">{entries.map((entry) => <article key={entry.id} className="plx-profile-panel"><div className="flex items-start justify-between gap-3"><div className="min-w-0"><p className="truncate font-display text-base font-bold text-white">{entry.tournament.name}</p><p className="mt-1 text-[11px] text-slate-400">{titleCase(entry.tournament.mode)} · {entry.tournament.map} · Joined {formatDateShort(entry.joinedAt)}</p></div><StatusPill text={titleCase(entry.tournament.status)} /></div><div className="mt-3 grid grid-cols-3 gap-2 border-t border-white/[.07] pt-3"><DataPair label="Rank" value={entry.rank ? `#${entry.rank}` : "—"} /><DataPair label="Kills" value={String(entry.kills)} /><DataPair label="Prize" value={`${formatCredits(entry.prizeAwarded)} CR`} /></div><Link href={`/tournaments/${entry.tournament.slug}`} className="mt-3 flex items-center justify-between rounded-xl bg-white/[.035] px-3 py-2 text-[10px] font-black tracking-[.07em] text-violet-100 hover:bg-violet-300/[.09]">VIEW TOURNAMENT <ChevronRight size={14} /></Link></article>)}</div>; }

function CreditsTab({ balance, winnings, bonus, transactions }: { balance: number; winnings: number; bonus: number; transactions: any[] }) { return <div className="mt-4 space-y-3"><section className="grid grid-cols-3 gap-2"><BalanceTile label="Credits" value={balance} tone="violet" /><BalanceTile label="Winnings" value={winnings} tone="fuchsia" /><BalanceTile label="Bonus" value={bonus} tone="slate" /></section><Link href="/wallet" className="flex items-center justify-between rounded-2xl border border-violet-300/20 bg-violet-300/[.08] p-4 text-violet-100 transition hover:bg-violet-300/[.13]"><span className="flex items-center gap-3"><WalletCards size={18} /><span><span className="block text-xs font-black tracking-[.08em]">OPEN PLX WALLET</span><span className="mt-1 block text-[11px] font-medium text-slate-400">Top up Credits, withdraw winnings, and see full history.</span></span></span><ChevronRight size={18} /></Link><section className="plx-profile-panel"><div className="flex items-center justify-between"><div><p className="plx-eyebrow">RECENT CREDIT ACTIVITY</p><h2 className="mt-1 font-display text-lg font-bold text-white">Private ledger</h2></div><Link href="/transactions" className="text-[10px] font-black tracking-[.07em] text-violet-100">FULL HISTORY</Link></div>{transactions.length ? <div className="mt-3 divide-y divide-white/[.07]">{transactions.slice(0, 5).map((transaction) => <div key={transaction.id} className="flex items-center justify-between gap-3 py-3"><div className="min-w-0"><p className="truncate text-xs font-bold text-slate-100">{transaction.note || titleCase(transaction.type.replace(/_/g, " "))}</p><p className="mt-1 text-[10px] text-slate-500">{formatDateShort(transaction.createdAt)}</p></div><span className={cn("shrink-0 text-xs font-black", transaction.direction === "credit" ? "text-emerald-300" : "text-fuchsia-200")}>{transaction.direction === "credit" ? "+" : "−"}{formatCredits(transaction.amount)} CR</span></div>)}</div> : <p className="mt-4 text-sm text-slate-500">No wallet activity has been recorded yet.</p>}</section></div>; }

function ProfileSkeleton() { return <div className="space-y-3 animate-pulse"><div className="h-12 w-3/4 rounded-xl bg-white/[.05]" /><div className="h-48 rounded-[1.65rem] bg-white/[.05]" /><div className="h-12 rounded-2xl bg-white/[.04]" /><div className="h-48 rounded-3xl bg-white/[.04]" /></div>; }
function IdentityPill({ label, value }: { label: string; value: string }) { return <span className="rounded-lg border border-white/[.1] bg-black/20 px-2 py-1 text-[9px] font-bold text-slate-300"><span className="mr-1 text-slate-500">{label}</span>{value}</span>; }
function Metric({ value, label, highlight = false }: { value: string; label: string; highlight?: boolean }) { return <div className="text-center"><p className={cn("font-display text-lg font-black", highlight ? "text-fuchsia-100" : "text-white")}>{value}</p><p className="mt-0.5 text-[9px] font-bold uppercase tracking-[.1em] text-slate-500">{label}</p></div>; }
function ActionButton({ icon, label, onClick, tone = "violet" }: { icon: React.ReactNode; label: string; onClick: () => void; tone?: "violet" | "rose" }) { return <button type="button" onClick={onClick} className={cn("flex min-h-12 items-center justify-center gap-1.5 rounded-xl border px-2 text-[10px] font-black tracking-[.04em] transition active:scale-[.97]", tone === "rose" ? "border-rose-300/[.13] bg-rose-300/[.04] text-rose-200 hover:bg-rose-300/[.1]" : "border-violet-300/[.16] bg-violet-300/[.06] text-violet-100 hover:bg-violet-300/[.12]")}>{icon}{label}</button>; }
function ActionLink({ icon, label, href }: { icon: React.ReactNode; label: string; href: string }) { return <Link href={href} className="flex min-h-12 items-center justify-center gap-1.5 rounded-xl border border-violet-300/[.16] bg-violet-300/[.06] px-2 text-[10px] font-black tracking-[.04em] text-violet-100 transition hover:bg-violet-300/[.12] active:scale-[.97]">{icon}{label}</Link>; }
function StatTile({ icon, label, value }: { icon: React.ReactNode; label: string; value: string }) { return <div className="rounded-2xl border border-white/[.08] bg-white/[.025] p-3"><span className="text-violet-200">{icon}</span><p className="mt-3 font-display text-xl font-black text-white">{value}</p><p className="mt-0.5 text-[9px] font-bold uppercase tracking-[.08em] text-slate-500">{label}</p></div>; }
function SecurityRow({ icon, title, detail, action }: { icon: React.ReactNode; title: string; detail: string; action: React.ReactNode }) { return <div className="flex items-center gap-3 p-3"><span className="grid h-8 w-8 shrink-0 place-items-center rounded-lg bg-violet-300/[.09] text-violet-200">{icon}</span><div className="min-w-0 flex-1"><p className="text-xs font-bold text-slate-100">{title}</p><p className="mt-0.5 text-[10px] leading-4 text-slate-500">{detail}</p></div>{action}</div>; }
function Field({ label, children }: { label: string; children: React.ReactNode }) { return <label className="block text-[11px] font-bold text-slate-300">{label}<div className="mt-1.5">{children}</div></label>; }
function BalanceTile({ label, value, tone }: { label: string; value: number; tone: "violet" | "fuchsia" | "slate" }) { const toneClass = tone === "fuchsia" ? "border-fuchsia-300/20 bg-fuchsia-300/[.07]" : tone === "violet" ? "border-violet-300/20 bg-violet-300/[.08]" : "border-white/[.08] bg-white/[.025]"; return <div className={cn("rounded-2xl border p-3", toneClass)}><p className="font-display text-lg font-black text-white">{formatCredits(value)}</p><p className="mt-0.5 text-[9px] font-bold uppercase tracking-[.08em] text-slate-400">{label}</p></div>; }
function StatusPill({ text }: { text: string }) { return <span className="rounded-full border border-violet-300/20 bg-violet-300/[.08] px-2 py-1 text-[9px] font-black uppercase tracking-[.08em] text-violet-100">{text}</span>; }
function DataPair({ label, value }: { label: string; value: string }) { return <div><p className="text-[9px] font-bold uppercase tracking-[.08em] text-slate-500">{label}</p><p className="mt-1 text-xs font-bold text-slate-100">{value}</p></div>; }
function EmptyState({ icon, title, detail, action, href }: { icon: React.ReactNode; title: string; detail: string; action?: string; href?: string }) { return <section className="plx-profile-empty mt-4"><span className="text-violet-200">{icon}</span><p className="mt-2 font-display text-lg font-bold text-white">{title}</p><p>{detail}</p>{action && href && <Link href={href} className="mt-4 inline-flex rounded-xl bg-violet-300 px-3 py-2 text-[10px] font-black tracking-[.08em] text-[#180a24]">{action}</Link>}</section>; }
