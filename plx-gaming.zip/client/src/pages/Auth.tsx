import { PublicLayout } from "@/components/PublicLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { trpc } from "@/lib/trpc";
import { KeyRound, Loader2, Mail, ShieldCheck, UserRound } from "lucide-react";
import { FormEvent, useEffect, useState } from "react";
import { toast } from "sonner";
import { useLocation } from "wouter";

export default function Auth() {
  const [location, setLocation] = useLocation();
  const utils = trpc.useUtils();
  const requestedDestination = new URLSearchParams(window.location.search).get("next");
  const destination = requestedDestination?.startsWith("/admin") ? requestedDestination : "/dashboard";
  const { data: user, isLoading } = trpc.auth.me.useQuery();
  const [mode, setMode] = useState<"login" | "register">("login");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [googleStarting, setGoogleStarting] = useState(false);
  const login = trpc.auth.login.useMutation();
  const register = trpc.auth.register.useMutation();
  const isWorking = login.isPending || register.isPending;

  useEffect(() => {
    if (user) setLocation(destination);
  }, [destination, user, setLocation]);

  useEffect(() => {
    const callbackStatus = new URLSearchParams(window.location.search).get("oauth");
    if (!callbackStatus) return;
    const messages: Record<string, string> = {
      google_cancelled: "Google sign-in was cancelled. You can try again whenever you are ready.",
      google_state_invalid: "This Google sign-in request has expired. Please start again.",
      google_failed: "Google sign-in could not be completed. Please try again.",
      google_unavailable: "Google sign-in is temporarily unavailable. Please use email and password or try again later.",
      link_requires_login: "Sign in to your PLX account before linking Google.",
    };
    toast.error(messages[callbackStatus] ?? "Google sign-in could not be completed.");
    window.history.replaceState({}, "", window.location.pathname);
  }, []);

  const submit = async (event: FormEvent) => {
    event.preventDefault();
    try {
      if (mode === "register") {
        await register.mutateAsync({ name, email, password });
        toast.success("PLX account created. Welcome to the arena.");
      } else {
        await login.mutateAsync({ email, password });
        toast.success("Welcome back to PLX Gaming.");
      }
      await utils.auth.me.invalidate();
      setLocation(destination);
    } catch (error: any) {
      toast.error(error?.message ?? "Could not authenticate your account.");
    }
  };

  const startGoogle = () => {
    setGoogleStarting(true);
    window.location.assign(`/api/auth/google/start?next=${encodeURIComponent(destination)}`);
  };

  return <PublicLayout>
    <section className="relative isolate overflow-hidden py-10 sm:py-16">
      <div className="absolute inset-0 -z-10 hero-grid opacity-60" />
      <div className="absolute left-1/2 top-0 -z-10 h-[28rem] w-[32rem] -translate-x-1/2 rounded-full bg-violet-500/15 blur-3xl" />
      <div className="container grid max-w-5xl gap-8 lg:grid-cols-[.9fr_1.1fr] lg:items-center">
        <div className="px-2 sm:px-5">
          <p className="inline-flex items-center gap-2 text-[10px] font-black tracking-[.2em] text-violet-200"><ShieldCheck size={14} />SECURE PLAYER ACCESS</p>
          <h1 className="mt-4 font-display text-4xl font-black leading-[.95] text-white sm:text-5xl">ENTER THE <span className="text-gradient-cyan">ARENA.</span></h1>
          <p className="mt-5 max-w-md text-sm leading-7 text-slate-400">Use Google or your PLX email and password to manage Credits, secure tournament slots, and follow your results on any device.</p>
          <div className="mt-8 grid gap-3 text-sm text-slate-300"><p className="flex items-center gap-3"><span className="grid h-8 w-8 place-items-center rounded-xl bg-violet-300/10 text-violet-200"><KeyRound size={16} /></span>Passwords are stored as secure hashes.</p><p className="flex items-center gap-3"><span className="grid h-8 w-8 place-items-center rounded-xl bg-fuchsia-300/10 text-fuchsia-200"><ShieldCheck size={16} /></span>Your Credits controls remain server-protected.</p></div>
        </div>
        <div className="rounded-[1.8rem] border border-violet-200/[.18] bg-[#0b1325]/95 p-5 shadow-[0_24px_70px_rgba(63,24,122,.30)] sm:p-8">
          <div className="flex rounded-xl border border-violet-200/[.12] bg-violet-300/[.045] p-1"><button type="button" onClick={() => setMode("login")} className={`flex-1 rounded-lg px-3 py-2.5 text-xs font-extrabold transition ${mode === "login" ? "bg-gradient-to-r from-violet-400 to-fuchsia-400 text-white shadow-[0_0_22px_rgba(167,119,255,.28)]" : "text-slate-400 hover:text-violet-100"}`}>SIGN IN</button><button type="button" onClick={() => setMode("register")} className={`flex-1 rounded-lg px-3 py-2.5 text-xs font-extrabold transition ${mode === "register" ? "bg-gradient-to-r from-violet-400 to-fuchsia-400 text-white shadow-[0_0_22px_rgba(167,119,255,.28)]" : "text-slate-400 hover:text-violet-100"}`}>CREATE ACCOUNT</button></div>
          <Button type="button" onClick={startGoogle} disabled={googleStarting || isLoading} variant="outline" className="mt-5 h-12 w-full rounded-xl border-violet-200/30 bg-gradient-to-r from-white/[.10] to-violet-300/[.12] text-xs font-black tracking-[.08em] text-white hover:border-violet-200/60 hover:bg-violet-300/[.16]"><span className="mr-2 grid h-5 w-5 place-items-center rounded-full bg-white font-sans text-[11px] font-black text-[#4285F4]">G</span>{googleStarting ? <><Loader2 className="mr-2 h-4 w-4 animate-spin" />CONNECTING TO GOOGLE</> : "CONTINUE WITH GOOGLE"}</Button>
          <div className="my-5 flex items-center gap-3"><span className="h-px flex-1 bg-white/[.08]" /><span className="text-[10px] font-bold tracking-[.12em] text-slate-500">OR USE PLX EMAIL</span><span className="h-px flex-1 bg-white/[.08]" /></div>
          <form onSubmit={submit} className="mt-6 grid gap-5">
            {mode === "register" && <div className="grid gap-2"><Label htmlFor="name" className="text-xs font-bold text-slate-300">Player name</Label><div className="relative"><UserRound className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-500" /><Input id="name" value={name} onChange={(event) => setName(event.target.value)} required minLength={2} maxLength={80} placeholder="Your player name" className="h-12 border-white/10 bg-white/[.03] pl-10 text-white placeholder:text-slate-600" /></div></div>}
            <div className="grid gap-2"><Label htmlFor="email" className="text-xs font-bold text-slate-300">Email address</Label><div className="relative"><Mail className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-500" /><Input id="email" type="email" value={email} onChange={(event) => setEmail(event.target.value)} required maxLength={320} autoComplete="email" placeholder="you@example.com" className="h-12 border-white/10 bg-white/[.03] pl-10 text-white placeholder:text-slate-600" /></div></div>
            <div className="grid gap-2"><Label htmlFor="password" className="text-xs font-bold text-slate-300">Password</Label><div className="relative"><KeyRound className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-500" /><Input id="password" type="password" value={password} onChange={(event) => setPassword(event.target.value)} required minLength={10} maxLength={128} autoComplete={mode === "login" ? "current-password" : "new-password"} placeholder={mode === "register" ? "At least 10 characters" : "Your password"} className="h-12 border-white/10 bg-white/[.03] pl-10 text-white placeholder:text-slate-600" /></div></div>
            <Button type="submit" disabled={isWorking || isLoading} className="mt-1 h-12 rounded-xl bg-gradient-to-r from-violet-500 to-fuchsia-500 text-xs font-black tracking-[.1em] text-white shadow-[0_0_30px_rgba(167,119,255,.20)]">{isWorking ? <><Loader2 className="mr-2 h-4 w-4 animate-spin" />AUTHENTICATING</> : mode === "login" ? "SIGN IN TO PLX" : "CREATE PLX ACCOUNT"}</Button>
            {mode === "login" && <button type="button" onClick={() => setLocation("/forgot-password")} className="-mt-1 justify-self-center text-xs font-bold text-violet-200 transition hover:text-violet-100">Forgot Password?</button>}
          </form>
          <p className="mt-5 text-center text-xs leading-5 text-slate-500">Administrator access remains protected through the secure Admin Access code flow.</p>
        </div>
      </div>
    </section>
  </PublicLayout>;
}
