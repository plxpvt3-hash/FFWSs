import { PlayerGate } from "@/components/PlayerGate";
import { PlayerHeader } from "@/components/PlayerHeader";
import { PublicLayout } from "@/components/PublicLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { formatCredits, formatDateShort, formatDateTime, titleCase } from "@/lib/format";
import { buildUpiPaymentUrl, canStartUpiPayment, canSubmitPaymentProof, paymentSubmissionUiState } from "@/lib/paymentFlow";
import { trpc } from "@/lib/trpc";
import { ArrowLeft, ArrowRight, CheckCircle2, Clipboard, CreditCard, ImageUp, Loader2, QrCode, ShieldCheck, UploadCloud } from "lucide-react";
import QRCode from "qrcode";
import { ChangeEvent, useEffect, useState } from "react";
import { toast } from "sonner";

export default function Wallet() {
  return <PublicLayout><section className="container max-w-6xl py-9 sm:py-12"><PlayerGate><WalletContent /></PlayerGate></section></PublicLayout>;
}

function WalletContent() {
  const { data, isLoading } = trpc.player.addCredits.useQuery();
  const wallet = trpc.player.dashboard.useQuery();
  const utils = trpc.useUtils();
  const [selected, setSelected] = useState<number | null>(null);
  const [paymentStep, setPaymentStep] = useState<"package" | "pay" | "proof">("package");
  const [submittedReview, setSubmittedReview] = useState<{ credits: number; amount: number } | null>(null);
  const [utr, setUtr] = useState("");
  const [screenshot, setScreenshot] = useState("");
  const [fileName, setFileName] = useState("");
  const [generatedQrUrl, setGeneratedQrUrl] = useState("");
  const chosen = data?.packages.find((x) => x.id === selected);
  const paymentDetailsReady = canStartUpiPayment(data?.upiId);
  const upiPaymentUrl = chosen && data?.upiId ? buildUpiPaymentUrl(data.upiId, chosen.priceInr, chosen.credits) : "";
  const displayedQrUrl = data?.qrCodeUrl || generatedQrUrl;
  useEffect(() => {
    const interval = window.setInterval(() => { void wallet.refetch(); }, 15_000);
    return () => window.clearInterval(interval);
  }, [wallet.refetch]);
  useEffect(() => {
    let cancelled = false;
    if (!chosen || !data?.upiId || data.qrCodeUrl) { setGeneratedQrUrl(""); return; }
    QRCode.toDataURL(buildUpiPaymentUrl(data.upiId, chosen.priceInr, chosen.credits), {
      width: 640,
      margin: 1,
      color: { dark: "#07101f", light: "#ffffff" },
    }).then((url) => { if (!cancelled) setGeneratedQrUrl(url); }).catch(() => { if (!cancelled) setGeneratedQrUrl(""); });
    return () => { cancelled = true; };
  }, [chosen, data?.upiId, data?.qrCodeUrl]);
  const submit = trpc.player.submitPaymentRequest.useMutation({
    onSuccess: () => {
      toast.success("Payment request submitted and marked pending for review.");
      setSubmittedReview({ credits: chosen?.credits ?? 0, amount: chosen?.priceInr ?? 0 });
      setSelected(null); setPaymentStep("package"); setUtr(""); setScreenshot(""); setFileName("");
      utils.player.addCredits.invalidate(); utils.player.transactions.invalidate(); utils.player.dashboard.invalidate();
    },
    onError: (error) => toast.error(error.message),
  });
  const paymentProofReady = canSubmitPaymentProof(utr, screenshot, submit.isPending);
  const paymentSubmissionState = paymentSubmissionUiState(submit.isPending, Boolean(submittedReview));
  const copyUpi = () => {
    if (!data?.upiId) return;
    navigator.clipboard.writeText(data.upiId);
    toast.success("UPI ID copied");
  };
  const openUpiApp = () => {
    if (upiPaymentUrl) window.location.assign(upiPaymentUrl);
  };
  const fileChange = (event: ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;
    if (!['image/png', 'image/jpeg', 'image/webp'].includes(file.type)) return toast.error("Choose a PNG, JPEG, or WebP image.");
    if (file.size > 4 * 1024 * 1024) return toast.error("Image must be smaller than 4 MB.");
    const reader = new FileReader();
    reader.onload = () => { setScreenshot(String(reader.result)); setFileName(file.name); };
    reader.readAsDataURL(file);
  };

  if (isLoading || !data) return <div className="h-96 animate-pulse rounded-3xl bg-white/[.04]" />;
  const pendingCount = data.requests.filter((request) => request.status === "pending").length;

  return <>
    <PlayerHeader eyebrow="CREDITS CENTER" title="Wallet & top up" />
    <div className="grid gap-5 lg:grid-cols-[.82fr_1.18fr]">
      <aside className="rounded-2xl border border-cyan-300/15 bg-gradient-to-br from-cyan-300/[.11] via-[#0c1325] to-violet-400/[.1] p-6">
        <WalletCardsHeader />
        <p className="mt-4 text-sm leading-6 text-slate-400">Choose a tournament Credits package, complete the UPI payment, then submit proof. Credits are added only after an administrator approves the request.</p>
        <div className="mt-7 rounded-xl border border-white/[.08] bg-black/15 p-4">
          <p className="text-[10px] font-black tracking-[.14em] text-slate-500">PAYMENT STATUS</p>
          <p className="mt-2 text-sm font-bold text-slate-200">{pendingCount} pending review</p>
          <p className="mt-1 text-xs leading-5 text-slate-500">Your wallet is never credited until PLX completes manual verification.</p>
        </div>
      </aside>

      <div className="rounded-2xl border border-white/[.09] bg-[#0c1325] p-5 sm:p-6">
        <div className="flex flex-wrap items-end justify-between gap-3">
          <div><p className="text-[10px] font-black tracking-[.15em] text-cyan-300">1 · SELECT A PACKAGE</p><h2 className="mt-1 font-display text-xl font-bold text-white">Tournament Credits</h2></div>
          <span className="rounded-full border border-cyan-300/15 bg-cyan-300/[.06] px-3 py-1.5 text-[10px] font-black tracking-[.1em] text-cyan-100">MANUAL UPI APPROVAL</span>
        </div>
        {data.packages.length ? <div className="mt-5 grid gap-3 sm:grid-cols-2 xl:grid-cols-3">
          {data.packages.map((pkg) => {
            const isSelected = selected === pkg.id;
            return <button key={pkg.id} type="button" aria-pressed={isSelected} onClick={() => { setSelected(pkg.id); setPaymentStep("package"); setSubmittedReview(null); }} className={`group rounded-2xl border p-4 text-left transition duration-200 active:scale-[.98] ${isSelected ? "border-cyan-300/60 bg-gradient-to-br from-cyan-300/[.14] to-violet-400/[.08] shadow-[0_0_30px_rgba(35,220,255,.08)]" : "border-white/[.08] bg-white/[.02] hover:-translate-y-0.5 hover:border-cyan-300/30 hover:bg-cyan-300/[.04]"}`}>
              <div className="flex items-start justify-between gap-2"><span className="text-[10px] font-black tracking-[.12em] text-slate-500">TOP-UP</span>{isSelected && <CheckCircle2 size={18} className="text-cyan-200" />}</div>
              <p className="mt-4 font-display text-3xl font-bold text-white">₹{formatCredits(pkg.priceInr)}</p>
              <p className="mt-1 text-sm font-bold text-cyan-100">{formatCredits(pkg.credits)} Tournament Credits</p>
              <span className={`mt-5 flex items-center justify-center gap-2 rounded-xl px-3 py-2.5 text-[10px] font-black tracking-[.08em] transition ${isSelected ? "bg-cyan-300 text-[#051321]" : "border border-white/[.1] bg-black/10 text-slate-200 group-hover:border-cyan-300/35"}`}>{isSelected ? "PACKAGE SELECTED" : "SELECT PACKAGE"}<ArrowRight size={14} /></span>
            </button>;
          })}
        </div> : <div className="mt-5 rounded-xl border border-dashed border-white/[.12] bg-white/[.02] p-5 text-sm leading-6 text-slate-500">Credit packages are temporarily unavailable. Please contact PLX support.</div>}
        {wallet.data && <p className="mt-4 text-xs font-bold text-cyan-100">Current wallet balance: {formatCredits(wallet.data.balance)} Tournament Credits</p>}
        {chosen && paymentStep === "package" && <div className="mt-5 flex flex-col gap-4 rounded-2xl border border-cyan-300/20 bg-gradient-to-r from-cyan-300/[.09] via-[#0b1427] to-violet-400/[.08] p-4 sm:flex-row sm:items-center sm:justify-between">
          <div><p className="text-[10px] font-black tracking-[.14em] text-cyan-200">PACKAGE LOCKED IN</p><p className="mt-1 font-display text-lg font-bold text-white">₹{formatCredits(chosen.priceInr)} · {formatCredits(chosen.credits)} Tournament Credits</p><p className="mt-1 text-xs text-slate-400">Your Credits are issued only after payment verification.</p></div>
          <Button onClick={() => setPaymentStep("pay")} disabled={!paymentDetailsReady} className="h-11 shrink-0 rounded-xl bg-gradient-to-r from-cyan-300 to-sky-400 px-5 text-xs font-black tracking-[.08em] text-[#051321] disabled:opacity-50">PAY WITH UPI <ArrowRight size={15} /></Button>
        </div>}
      </div>
    </div>

    {chosen && paymentStep === "pay" && <section className="mt-5 overflow-hidden rounded-3xl border border-cyan-300/25 bg-[radial-gradient(circle_at_80%_10%,rgba(65,225,255,.13),transparent_30%),linear-gradient(135deg,#101c35,#0b1021_58%,#170d2b)] p-5 sm:p-7">
      <div className="flex flex-wrap items-start justify-between gap-4"><div><p className="text-[10px] font-black tracking-[.16em] text-cyan-200">2 · SECURE UPI PAYMENT</p><h2 className="mt-2 font-display text-2xl font-bold text-white sm:text-3xl">Scan QR &amp; Pay</h2><p className="mt-2 max-w-xl text-sm leading-6 text-slate-400">Use your preferred UPI app to pay the exact selected amount. The payment details below are configured by PLX Administration.</p></div><div className="rounded-2xl border border-cyan-300/20 bg-cyan-300/[.08] px-4 py-3 text-right"><p className="text-[10px] font-black tracking-[.12em] text-cyan-100">SELECTED PACKAGE</p><p className="mt-1 font-display text-lg font-bold text-white">₹{formatCredits(chosen.priceInr)}</p><p className="text-xs font-bold text-cyan-100">{formatCredits(chosen.credits)} Tournament Credits</p></div></div>
      <div className="mt-6 grid gap-6 lg:grid-cols-[1fr_.9fr]"><div className="rounded-2xl border border-white/[.1] bg-white p-5 shadow-[0_0_45px_rgba(34,211,238,.12)]"><div className="mx-auto flex max-w-sm flex-col items-center"><QrCode className="mb-3 text-[#0c1528]" size={24} />{displayedQrUrl ? <img src={displayedQrUrl} alt="PLX UPI payment QR code" className="h-64 w-64 max-w-full object-contain" /> : <div className="grid h-64 w-64 max-w-full place-items-center rounded-xl border border-dashed border-slate-300 p-6 text-center text-xs text-slate-500">UPI payment details are being prepared.</div>}<p className="mt-4 text-center text-xs font-bold text-slate-600">{data.qrCodeUrl ? "PLX administrator-configured QR code" : "Secure QR generated from the current PLX UPI ID"}</p></div></div>
        <div className="flex flex-col justify-between rounded-2xl border border-white/[.09] bg-black/20 p-5"><div><p className="text-[10px] font-black tracking-[.15em] text-orange-200">CONFIGURED PLX UPI ID</p><div className="mt-3 rounded-xl border border-white/[.1] bg-black/20 p-4"><p className="min-w-0 break-all font-display text-base font-bold text-orange-100">{data.upiId || "Not configured"}</p><Button onClick={copyUpi} disabled={!data.upiId} variant="outline" className="mt-3 h-10 w-full border-white/10 bg-white/[.04] text-[10px] font-black tracking-[.08em] text-slate-100"><Clipboard size={15} />COPY UPI ID</Button></div><p className="mt-5 text-sm leading-6 text-slate-400">{data.instructions}</p></div><div className="mt-6 space-y-3"><Button onClick={openUpiApp} disabled={!upiPaymentUrl} variant="outline" className="h-12 w-full border-cyan-300/35 bg-cyan-300/[.08] text-xs font-black tracking-[.08em] text-cyan-100 hover:bg-cyan-300/[.14]">PAY NOW IN UPI APP <ArrowRight size={17} /></Button><Button onClick={() => setPaymentStep("proof")} disabled={!paymentDetailsReady} className="h-12 w-full rounded-xl bg-gradient-to-r from-cyan-300 to-sky-400 text-xs font-black tracking-[.08em] text-[#051321]">I HAVE PAID <CheckCircle2 size={17} /></Button><button type="button" onClick={() => setPaymentStep("package")} className="flex w-full items-center justify-center gap-2 text-xs font-bold text-slate-400 transition hover:text-white"><ArrowLeft size={14} />Change package</button></div></div></div>
    </section>}

    {chosen && paymentStep === "proof" && <section className="mt-5 grid gap-5 lg:grid-cols-[.82fr_1.18fr]"><div className="rounded-2xl border border-orange-300/20 bg-orange-300/[.05] p-5 sm:p-6"><p className="text-[10px] font-black tracking-[.15em] text-orange-200">3 · PAYMENT CONFIRMATION</p><h2 className="mt-2 font-display text-2xl font-bold text-white">I have paid ₹{formatCredits(chosen.priceInr)}</h2><div className="mt-5 rounded-xl border border-white/[.08] bg-black/20 p-4"><p className="text-[10px] font-black tracking-[.12em] text-slate-500">YOU ARE REQUESTING</p><p className="mt-2 font-display text-xl font-bold text-cyan-100">{formatCredits(chosen.credits)} Tournament Credits</p><p className="mt-2 text-xs leading-5 text-slate-400">Submit your UTR and screenshot. Your request will show Payment Pending Review until an administrator verifies the payment.</p></div><button type="button" onClick={() => setPaymentStep("pay")} className="mt-5 flex items-center gap-2 text-xs font-bold text-slate-400 transition hover:text-white"><ArrowLeft size={14} />Back to QR payment details</button></div>
      <div className="rounded-2xl border border-cyan-300/20 bg-[#0c1325] p-5 sm:p-6"><p className="text-[10px] font-black tracking-[.15em] text-cyan-300">PAYMENT PROOF</p><h2 className="mt-1 font-display text-xl font-bold text-white">Submit Payment for Verification</h2><div className="mt-5 space-y-4"><div><label htmlFor="payment-utr" className="text-xs font-bold text-slate-300">UTR / Transaction ID</label><Input id="payment-utr" value={utr} onChange={(event) => setUtr(event.target.value)} placeholder="Enter UPI UTR or transaction ID" maxLength={100} className="mt-2 border-white/10 bg-white/[.04] text-white placeholder:text-slate-600" /></div><div><label className="text-xs font-bold text-slate-300">Payment screenshot</label><label className="mt-2 flex min-h-28 cursor-pointer items-center justify-center rounded-xl border border-dashed border-white/[.16] bg-white/[.02] px-4 text-center transition hover:border-cyan-300/40 hover:bg-cyan-300/[.03]"><input type="file" accept="image/png,image/jpeg,image/webp" onChange={fileChange} className="sr-only" /><span>{screenshot ? <><ImageUp className="mx-auto h-6 w-6 text-cyan-200" /><span className="mt-2 block text-xs font-bold text-cyan-100">{fileName}</span></> : <><UploadCloud className="mx-auto h-6 w-6 text-slate-400" /><span className="mt-2 block text-xs font-bold text-slate-300">Upload PNG, JPG, or WebP · max 4 MB</span></>}</span></label></div><Button aria-label={submit.isPending ? "Submitting payment proof" : "Submit payment for verification"} onClick={() => submit.mutate({ packageId: chosen.id, utr: utr.trim(), screenshotDataUrl: screenshot })} disabled={!paymentProofReady || paymentSubmissionState.isLocked} className="h-12 w-full rounded-xl bg-gradient-to-r from-cyan-300 to-sky-400 text-xs font-black tracking-[.08em] text-[#051321]">{submit.isPending ? <Loader2 className="animate-spin" size={16} /> : paymentSubmissionState.buttonLabel}</Button><p className="text-center text-[11px] leading-5 text-slate-500">No Credits are added automatically. PLX Administration must approve this payment.</p></div></div>
    </section>}

    {submittedReview && paymentSubmissionState.showPendingConfirmation && <section className="mt-5 rounded-2xl border border-orange-300/25 bg-gradient-to-r from-orange-300/[.11] via-[#121628] to-violet-400/[.09] p-5 sm:p-6"><div className="flex flex-wrap items-center gap-4"><span className="grid h-12 w-12 place-items-center rounded-2xl bg-orange-300/15 text-orange-100"><ShieldCheck size={23} /></span><div><p className="text-[10px] font-black tracking-[.15em] text-orange-200">PAYMENT PENDING REVIEW</p><h2 className="mt-1 font-display text-xl font-bold text-white">₹{formatCredits(submittedReview.amount)} for {formatCredits(submittedReview.credits)} Credits is awaiting verification</h2><p className="mt-1 text-sm text-slate-400">Your Tournament Credits will appear in your wallet only after a PLX administrator approves this payment.</p></div></div></section>}

    <div className="mt-7 rounded-2xl border border-white/[.09] bg-[#0c1325] p-5 sm:p-6"><p className="text-[10px] font-black tracking-[.15em] text-violet-200">PAYMENT REQUESTS</p><h2 className="mt-1 font-display text-xl font-bold text-white">Your verification history</h2>{data.requests.length ? <div className="mt-5 divide-y divide-white/[.06]">{data.requests.map((request) => <div key={request.id} className="flex flex-wrap items-center justify-between gap-3 py-4 first:pt-0"><div><p className="font-bold text-slate-200">{formatCredits(request.creditsRequested)} Credits · ₹{formatCredits(request.amountPaid)}</p><p className="mt-1 text-xs text-slate-500">UTR {request.utr} · {formatDateShort(request.createdAt)}</p></div><span className={`rounded-full px-3 py-1 text-[10px] font-black tracking-[.1em] ${request.status === "approved" ? "bg-emerald-300/10 text-emerald-200" : request.status === "rejected" ? "bg-rose-300/10 text-rose-200" : "bg-orange-300/10 text-orange-200"}`}>{request.status.toUpperCase()}</span></div>)}</div> : <p className="mt-5 rounded-xl border border-dashed border-white/[.1] p-4 text-sm text-slate-500">Your submitted payment requests will appear here.</p>}</div>
  </>;
}

function WalletCardsHeader() {
  return <><span className="grid h-12 w-12 place-items-center rounded-2xl bg-cyan-300/10 text-cyan-200"><CreditCard size={22} /></span><p className="mt-6 text-[10px] font-black tracking-[.15em] text-cyan-300">PLX CREDITS</p><h2 className="mt-2 font-display text-3xl font-bold text-white">Top up to play</h2></>;
}
