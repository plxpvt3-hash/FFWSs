import { PlayerGate } from "@/components/PlayerGate";
import { PublicLayout } from "@/components/PublicLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { formatCredits, formatDateShort, formatDateTime } from "@/lib/format";
import { buildUpiPaymentUrl, canStartUpiPayment, canSubmitPaymentProof, paymentSubmissionUiState } from "@/lib/paymentFlow";
import { trpc } from "@/lib/trpc";
import { ArrowLeft, ArrowRight, BadgeIndianRupee, CheckCircle2, ChevronRight, CircleDollarSign, Clipboard, CreditCard, ImageUp, Landmark, Loader2, QrCode, ReceiptText, ShieldCheck, Sparkles, Trophy, UploadCloud, WalletCards } from "lucide-react";
import QRCode from "qrcode";
import { ChangeEvent, useEffect, useState } from "react";
import { toast } from "sonner";
import { Link } from "wouter";

type WalletTab = "overview" | "tournaments" | "credits";

export default function Wallet() {
  return <PublicLayout><section className="mx-auto w-full max-w-6xl px-4 py-5 pb-6 sm:px-6 sm:py-7"><PlayerGate><WalletContent /></PlayerGate></section></PublicLayout>;
}

function WalletContent() {
  const { data, isLoading } = trpc.player.addCredits.useQuery();
  const wallet = trpc.player.dashboard.useQuery();
  const withdrawalWallet = trpc.player.walletSummary.useQuery();
  const utils = trpc.useUtils();
  const [activeTab, setActiveTab] = useState<WalletTab>("overview");
  const [selected, setSelected] = useState<number | null>(null);
  const [paymentStep, setPaymentStep] = useState<"package" | "pay" | "proof">("package");
  const [submittedReview, setSubmittedReview] = useState<{ credits: number; amount: number } | null>(null);
  const [utr, setUtr] = useState("");
  const [screenshot, setScreenshot] = useState("");
  const [fileName, setFileName] = useState("");
  const [generatedQrUrl, setGeneratedQrUrl] = useState("");
  const [withdrawOpen, setWithdrawOpen] = useState(false);
  const [withdrawAmount, setWithdrawAmount] = useState("");
  const [withdrawDestination, setWithdrawDestination] = useState("");
  const chosen = data?.packages.find((pkg) => pkg.id === selected);
  const paymentDetailsReady = canStartUpiPayment(data?.upiId);
  const upiPaymentUrl = chosen && data?.upiId ? buildUpiPaymentUrl(data.upiId, chosen.priceInr, chosen.credits) : "";
  const displayedQrUrl = data?.qrCodeUrl || generatedQrUrl;

  useEffect(() => {
    const interval = window.setInterval(() => { void wallet.refetch(); }, 15_000);
    return () => window.clearInterval(interval);
  }, [wallet.refetch]);

  useEffect(() => {
    let cancelled = false;
    if (!chosen || !data?.upiId || data.qrCodeUrl) { setGeneratedQrUrl(""); return; }
    QRCode.toDataURL(buildUpiPaymentUrl(data.upiId, chosen.priceInr, chosen.credits), { width: 640, margin: 1, color: { dark: "#11091d", light: "#ffffff" } })
      .then((url) => { if (!cancelled) setGeneratedQrUrl(url); })
      .catch(() => { if (!cancelled) setGeneratedQrUrl(""); });
    return () => { cancelled = true; };
  }, [chosen, data?.upiId, data?.qrCodeUrl]);

  const submit = trpc.player.submitPaymentRequest.useMutation({
    onSuccess: () => {
      toast.success("Payment request submitted and marked pending for review.");
      setSubmittedReview({ credits: chosen?.credits ?? 0, amount: chosen?.priceInr ?? 0 });
      setSelected(null); setPaymentStep("package"); setUtr(""); setScreenshot(""); setFileName(""); setActiveTab("overview");
      utils.player.addCredits.invalidate(); utils.player.transactions.invalidate(); utils.player.dashboard.invalidate();
    },
    onError: (error) => toast.error(error.message),
  });
  const requestWithdrawal = trpc.player.requestWithdrawal.useMutation({
    onSuccess: (result) => {
      toast.success(`Withdrawal ${result.withdrawalCode} is pending review.`);
      setWithdrawAmount(""); setWithdrawDestination(""); setWithdrawOpen(false);
      void utils.player.walletSummary.invalidate(); void utils.player.dashboard.invalidate(); void utils.player.transactions.invalidate();
    },
    onError: (error) => toast.error(error.message),
  });
  const copyUpi = () => {
    if (!data?.upiId) return;
    navigator.clipboard.writeText(data.upiId);
    toast.success("UPI ID copied");
  };
  const fileChange = (event: ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;
    if (!["image/png", "image/jpeg", "image/webp"].includes(file.type)) return toast.error("Choose a PNG, JPEG, or WebP image.");
    if (file.size > 4 * 1024 * 1024) return toast.error("Image must be smaller than 4 MB.");
    const reader = new FileReader();
    reader.onload = () => { setScreenshot(String(reader.result)); setFileName(file.name); };
    reader.readAsDataURL(file);
  };

  if (isLoading || !data || withdrawalWallet.isLoading || !withdrawalWallet.data) return <WalletSkeleton />;
  const withdrawalData = withdrawalWallet.data;
  const pendingCount = data.requests.filter((request) => request.status === "pending").length;
  const paymentProofReady = canSubmitPaymentProof(utr, screenshot, submit.isPending);
  const paymentSubmissionState = paymentSubmissionUiState(submit.isPending, Boolean(submittedReview));
  const numericWithdrawal = Number(withdrawAmount);
  const canRequestWithdrawal = Boolean(withdrawDestination.trim() && Number.isInteger(numericWithdrawal) && numericWithdrawal >= withdrawalData.minimumWithdrawal && numericWithdrawal <= withdrawalData.balances.winnings && !requestWithdrawal.isPending);
  const tabs: { id: WalletTab; label: string; icon: typeof WalletCards }[] = [
    { id: "overview", label: "Overview", icon: WalletCards },
    { id: "tournaments", label: "My Tournaments", icon: Trophy },
    { id: "credits", label: "Credits", icon: CreditCard },
  ];

  return <div className="animate-in fade-in-0 slide-in-from-bottom-1 duration-300">
    <header className="relative overflow-hidden rounded-[1.75rem] border border-violet-200/[.14] bg-[radial-gradient(circle_at_80%_0%,rgba(225,77,255,.18),transparent_32%),radial-gradient(circle_at_10%_105%,rgba(121,72,255,.2),transparent_42%),linear-gradient(135deg,rgba(23,12,43,.95),rgba(12,8,27,.95))] p-5 shadow-[0_16px_48px_rgba(17,5,40,.24)] sm:p-6">
      <div className="pointer-events-none absolute -right-8 -top-10 h-40 w-40 rounded-full bg-fuchsia-400/10 blur-3xl" />
      <div className="relative flex flex-wrap items-start justify-between gap-4">
        <div><p className="text-[10px] font-black tracking-[.19em] text-violet-200">PLX WALLET</p><h1 className="mt-2 font-display text-[clamp(1.75rem,7vw,2.55rem)] font-bold leading-none text-white">Credits, winnings <span className="text-transparent bg-clip-text bg-gradient-to-r from-violet-200 to-fuchsia-300">&amp; withdrawals</span></h1><p className="mt-3 max-w-xl text-sm leading-6 text-slate-400">Your tournament economy, securely separated and verified by PLX.</p></div>
        <span className="inline-flex items-center gap-2 rounded-full border border-violet-200/15 bg-violet-300/[.08] px-3 py-2 text-[10px] font-black tracking-[.11em] text-violet-100"><ShieldCheck size={14} />SECURE WALLET</span>
      </div>
      <div className="relative mt-5 grid grid-cols-3 gap-2 border-t border-white/[.08] pt-4 sm:max-w-2xl sm:gap-3">
        <CompactBalance label="CREDITS" value={formatCredits(withdrawalData.balances.credits)} tone="violet" />
        <CompactBalance label="WINNINGS" value={`₹${formatCredits(withdrawalData.balances.winnings)}`} tone="emerald" />
        <CompactBalance label="BONUS" value={formatCredits(withdrawalData.balances.bonus)} tone="fuchsia" />
      </div>
    </header>

    <div className="-mx-1 mt-5 overflow-x-auto px-1 pb-1 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
      <nav className="inline-flex min-w-max gap-1 rounded-2xl border border-violet-200/[.12] bg-black/20 p-1.5" aria-label="Wallet views" role="tablist">
        {tabs.map((tab) => { const Icon = tab.icon; const active = activeTab === tab.id; return <button key={tab.id} type="button" role="tab" aria-selected={active} onClick={() => setActiveTab(tab.id)} className={`flex min-h-10 items-center gap-2 rounded-xl px-4 text-xs font-bold transition duration-200 active:scale-[.97] ${active ? "border border-violet-200/25 bg-gradient-to-r from-violet-400/20 to-fuchsia-400/15 text-violet-50 shadow-[0_0_22px_rgba(189,124,255,.15)]" : "text-slate-500 hover:bg-violet-300/[.07] hover:text-violet-100"}`}><Icon size={15} />{tab.label}</button>; })}
      </nav>
    </div>

    {activeTab === "overview" && <div className="mt-5 space-y-5">
      <section className="grid gap-3 sm:grid-cols-3">
        <BalanceCard icon={<WalletCards size={19} />} label="TOURNAMENT CREDITS" value={formatCredits(withdrawalData.balances.credits)} hint="Used only for tournament entries" tone="violet" />
        <BalanceCard icon={<BadgeIndianRupee size={19} />} label="AVAILABLE WINNINGS" value={`₹${formatCredits(withdrawalData.balances.winnings)}`} hint="Eligible for UPI withdrawal" tone="emerald" />
        <BalanceCard icon={<Sparkles size={19} />} label="BONUS / PROMO" value={formatCredits(withdrawalData.balances.bonus)} hint="Kept separate from winnings" tone="fuchsia" />
      </section>

      <section className="overflow-hidden rounded-[1.75rem] border border-emerald-300/20 bg-[radial-gradient(circle_at_100%_0%,rgba(48,217,172,.16),transparent_34%),linear-gradient(135deg,rgba(11,38,37,.82),rgba(12,15,31,.98)_58%,rgba(31,14,50,.9))] p-5 shadow-[0_18px_42px_rgba(2,20,21,.2)] sm:p-6">
        <div className="flex flex-wrap items-start justify-between gap-4"><div><p className="text-[10px] font-black tracking-[.17em] text-emerald-200">WINNINGS PAYOUT</p><h2 className="mt-2 font-display text-2xl font-bold text-white">Withdraw to UPI</h2><p className="mt-2 max-w-2xl text-sm leading-6 text-slate-400">Only confirmed tournament winnings can be withdrawn. Tournament Credits and bonus value remain separate and cannot be used for payouts.</p></div><Button onClick={() => setWithdrawOpen((open) => !open)} className="h-12 rounded-2xl bg-gradient-to-r from-emerald-300 to-teal-300 px-5 text-[11px] font-black tracking-[.09em] text-[#051321] shadow-[0_10px_28px_rgba(52,211,153,.16)] active:scale-[.97]"><Landmark size={16} />{withdrawOpen ? "CLOSE WITHDRAW" : "WITHDRAW WINNINGS"}</Button></div>
        <div className="mt-5 flex flex-wrap gap-2"><StatusChip label={`AVAILABLE ₹${formatCredits(withdrawalData.balances.winnings)}`} tone="emerald" /><StatusChip label={`MINIMUM ₹${formatCredits(withdrawalData.minimumWithdrawal)}`} /><StatusChip label="ONE ACTIVE REQUEST AT A TIME" /></div>
        {withdrawOpen && <div className="mt-5 grid gap-3 rounded-2xl border border-emerald-200/15 bg-black/20 p-4 sm:grid-cols-[.75fr_1.2fr_auto] sm:items-end"><Field label="Withdrawal amount" id="withdraw-amount"><Input id="withdraw-amount" inputMode="numeric" value={withdrawAmount} onChange={(event) => setWithdrawAmount(event.target.value.replace(/\D/g, ""))} placeholder={`Minimum ₹${withdrawalData.minimumWithdrawal}`} className="plx-wallet-input" /></Field><Field label="UPI ID or UPI-linked mobile number" id="withdraw-upi"><Input id="withdraw-upi" value={withdrawDestination} onChange={(event) => setWithdrawDestination(event.target.value)} placeholder="player@upi or +91 98765 43210" maxLength={160} className="plx-wallet-input" /></Field><Button onClick={() => requestWithdrawal.mutate({ amount: numericWithdrawal, upiId: withdrawDestination })} disabled={!canRequestWithdrawal} className="h-11 rounded-xl bg-gradient-to-r from-emerald-300 to-teal-300 text-[10px] font-black tracking-[.09em] text-[#051321] disabled:opacity-45">{requestWithdrawal.isPending ? <Loader2 className="animate-spin" size={16} /> : "SUBMIT REQUEST"}</Button><p className="sm:col-span-3 text-[11px] leading-5 text-slate-500">The server validates your balance, minimum payout, and active-request status before reserving winnings. A rejected request returns eligible winnings to your wallet.</p></div>}
      </section>

      {submittedReview && paymentSubmissionState.showPendingConfirmation && <section className="flex flex-wrap items-center gap-4 rounded-2xl border border-orange-300/25 bg-gradient-to-r from-orange-300/[.12] via-[#13152a] to-fuchsia-400/[.08] p-4 sm:p-5"><span className="grid h-11 w-11 place-items-center rounded-2xl bg-orange-300/15 text-orange-100"><ShieldCheck size={21} /></span><div><p className="text-[10px] font-black tracking-[.15em] text-orange-200">PAYMENT PENDING REVIEW</p><p className="mt-1 font-display text-lg font-bold text-white">₹{formatCredits(submittedReview.amount)} for {formatCredits(submittedReview.credits)} Credits awaits verification</p><p className="mt-1 text-sm text-slate-400">Tournament Credits appear only after administrator approval.</p></div></section>}

      <section className="rounded-[1.6rem] border border-violet-200/[.13] bg-[linear-gradient(135deg,rgba(91,54,155,.14),rgba(13,9,29,.92)_56%,rgba(36,12,57,.7))] p-5 sm:p-6"><div className="flex flex-wrap items-center justify-between gap-4"><div className="flex gap-3"><span className="grid h-11 w-11 place-items-center rounded-2xl bg-violet-300/[.12] text-violet-100"><CreditCard size={20} /></span><div><p className="text-[10px] font-black tracking-[.16em] text-violet-200">PLX CREDITS</p><h2 className="mt-1 font-display text-xl font-bold text-white">Top up to play</h2><p className="mt-1 text-sm text-slate-400">Select a package, pay by UPI, then submit proof for manual review.</p></div></div><Button onClick={() => setActiveTab("credits")} variant="outline" className="h-11 rounded-xl border-violet-200/25 bg-violet-300/[.08] px-4 text-[10px] font-black tracking-[.09em] text-violet-100">VIEW CREDIT PACKAGES <ChevronRight size={15} /></Button></div></section>

      <HistoryPanels paymentRequests={data.requests} withdrawals={withdrawalData.withdrawals} />
    </div>}

    {activeTab === "tournaments" && <section className="mt-5 overflow-hidden rounded-[1.75rem] border border-violet-200/[.14] bg-[radial-gradient(circle_at_85%_0%,rgba(214,78,255,.14),transparent_28%),#100a1e] p-6 sm:p-8"><span className="grid h-12 w-12 place-items-center rounded-2xl bg-violet-300/[.12] text-violet-100"><Trophy size={22} /></span><p className="mt-6 text-[10px] font-black tracking-[.17em] text-violet-200">PLAYER AREA</p><h2 className="mt-2 font-display text-3xl font-bold text-white">My Tournaments</h2><p className="mt-3 max-w-xl text-sm leading-6 text-slate-400">Review your joined events, entry status, published room details, and results in the secure player area.</p><Link href="/my-tournaments" className="mt-6 inline-flex h-11 items-center gap-2 rounded-xl bg-gradient-to-r from-violet-500 to-fuchsia-500 px-5 text-[11px] font-black tracking-[.09em] text-white shadow-[0_12px_30px_rgba(174,68,255,.18)] transition active:scale-[.97]">OPEN MY TOURNAMENTS <ArrowRight size={16} /></Link></section>}

    {activeTab === "credits" && <div className="mt-5 space-y-5">
      <section className="overflow-hidden rounded-[1.75rem] border border-violet-200/[.15] bg-[radial-gradient(circle_at_100%_0%,rgba(229,76,255,.2),transparent_30%),linear-gradient(135deg,#17102a,#0d0a1a_58%,#241037)] p-5 shadow-[0_16px_46px_rgba(45,14,70,.22)] sm:p-6"><div className="flex flex-wrap items-start justify-between gap-4"><div><p className="text-[10px] font-black tracking-[.17em] text-violet-200">PLX CREDITS</p><h2 className="mt-2 font-display text-2xl font-bold text-white">Top up to play</h2><p className="mt-2 max-w-xl text-sm leading-6 text-slate-400">Choose a tournament Credits package, complete UPI payment, and submit proof. Credits are added only after an administrator approves your request.</p></div><div className="min-w-40 rounded-2xl border border-violet-200/[.13] bg-black/20 p-3"><p className="text-[10px] font-black tracking-[.13em] text-violet-200">PAYMENT STATUS</p><p className="mt-2 text-sm font-bold text-white">{pendingCount} pending review</p><p className="mt-1 text-xs leading-5 text-slate-500">No automatic credits.</p></div></div>
        <div className="mt-6 flex flex-wrap items-end justify-between gap-3"><div><p className="text-[10px] font-black tracking-[.15em] text-fuchsia-200">1 · SELECT A PACKAGE</p><h3 className="mt-1 font-display text-xl font-bold text-white">Tournament Credits</h3></div>{wallet.data && <span className="rounded-full border border-violet-200/15 bg-violet-300/[.08] px-3 py-2 text-xs font-bold text-violet-100">Wallet: {formatCredits(wallet.data.balance)} Credits</span>}</div>
        {data.packages.length ? <div className="mt-5 grid gap-3 sm:grid-cols-2 xl:grid-cols-3">{data.packages.map((pkg) => { const isSelected = selected === pkg.id; return <button key={pkg.id} type="button" aria-pressed={isSelected} onClick={() => { setSelected(pkg.id); setPaymentStep("package"); setSubmittedReview(null); }} className={`group rounded-2xl border p-4 text-left transition duration-200 active:scale-[.98] ${isSelected ? "border-violet-200/60 bg-gradient-to-br from-violet-400/[.2] to-fuchsia-400/[.13] shadow-[0_0_30px_rgba(189,124,255,.16)]" : "border-white/[.08] bg-black/15 hover:-translate-y-0.5 hover:border-violet-200/30 hover:bg-violet-300/[.05]"}`}><div className="flex items-start justify-between gap-2"><span className="text-[10px] font-black tracking-[.12em] text-slate-500">TOP-UP</span>{isSelected && <CheckCircle2 size={18} className="text-violet-100" />}</div><p className="mt-4 font-display text-3xl font-bold text-white">₹{formatCredits(pkg.priceInr)}</p><p className="mt-1 text-sm font-bold text-violet-100">{formatCredits(pkg.credits)} Tournament Credits</p><span className={`mt-5 flex items-center justify-center gap-2 rounded-xl px-3 py-2.5 text-[10px] font-black tracking-[.08em] ${isSelected ? "bg-gradient-to-r from-violet-300 to-fuchsia-300 text-[#18072b]" : "border border-white/[.1] bg-black/10 text-slate-200 group-hover:border-violet-200/35"}`}>{isSelected ? "PACKAGE SELECTED" : "SELECT PACKAGE"}<ArrowRight size={14} /></span></button>; })}</div> : <EmptyState>Credit packages are temporarily unavailable. Please contact PLX support.</EmptyState>}
        {chosen && paymentStep === "package" && <div className="mt-5 flex flex-col gap-4 rounded-2xl border border-violet-200/20 bg-gradient-to-r from-violet-300/[.11] via-black/20 to-fuchsia-400/[.1] p-4 sm:flex-row sm:items-center sm:justify-between"><div><p className="text-[10px] font-black tracking-[.14em] text-violet-100">PACKAGE LOCKED IN</p><p className="mt-1 font-display text-lg font-bold text-white">₹{formatCredits(chosen.priceInr)} · {formatCredits(chosen.credits)} Tournament Credits</p><p className="mt-1 text-xs text-slate-400">Credits are issued only after payment verification.</p></div><Button onClick={() => setPaymentStep("pay")} disabled={!paymentDetailsReady} className="h-11 shrink-0 rounded-xl bg-gradient-to-r from-violet-300 to-fuchsia-300 px-5 text-xs font-black tracking-[.08em] text-[#18072b] disabled:opacity-50">PAY WITH UPI <ArrowRight size={15} /></Button></div>}
      </section>

      {chosen && paymentStep === "pay" && <section className="overflow-hidden rounded-[1.75rem] border border-violet-200/20 bg-[radial-gradient(circle_at_85%_0%,rgba(193,129,255,.22),transparent_32%),linear-gradient(135deg,#15102a,#0c091b_58%,#271039)] p-5 sm:p-7"><div className="flex flex-wrap items-start justify-between gap-4"><div><p className="text-[10px] font-black tracking-[.16em] text-violet-100">2 · SECURE UPI PAYMENT</p><h2 className="mt-2 font-display text-2xl font-bold text-white sm:text-3xl">Scan QR &amp; Pay</h2><p className="mt-2 max-w-xl text-sm leading-6 text-slate-400">Use your preferred UPI app to pay the exact selected amount. These payment details are configured by PLX Administration.</p></div><div className="rounded-2xl border border-violet-200/20 bg-violet-300/[.09] px-4 py-3 text-right"><p className="text-[10px] font-black tracking-[.12em] text-violet-100">SELECTED PACKAGE</p><p className="mt-1 font-display text-lg font-bold text-white">₹{formatCredits(chosen.priceInr)}</p><p className="text-xs font-bold text-violet-100">{formatCredits(chosen.credits)} Credits</p></div></div><div className="mt-6 grid gap-5 lg:grid-cols-[.85fr_1.15fr]"><div className="rounded-2xl border border-white/[.1] bg-white p-5 shadow-[0_0_45px_rgba(184,120,255,.12)]"><div className="mx-auto flex max-w-sm flex-col items-center"><QrCode className="mb-3 text-[#12091e]" size={24} />{displayedQrUrl ? <img src={displayedQrUrl} alt="PLX UPI payment QR code" className="h-60 w-60 max-w-full object-contain" /> : <div className="grid h-60 w-60 max-w-full place-items-center rounded-xl border border-dashed border-slate-300 p-6 text-center text-xs text-slate-500">UPI payment details are being prepared.</div>}<p className="mt-4 text-center text-xs font-bold text-slate-600">{data.qrCodeUrl ? "PLX administrator-configured QR code" : "Secure QR generated from the current PLX UPI ID"}</p></div></div><div className="flex flex-col justify-between rounded-2xl border border-white/[.09] bg-black/20 p-5"><div><p className="text-[10px] font-black tracking-[.15em] text-fuchsia-200">CONFIGURED PLX UPI ID</p><div className="mt-3 rounded-xl border border-white/[.1] bg-black/20 p-4"><p className="min-w-0 break-all font-display text-base font-bold text-violet-100">{data.upiId || "Not configured"}</p><Button onClick={copyUpi} disabled={!data.upiId} variant="outline" className="mt-3 h-10 w-full border-white/10 bg-white/[.04] text-[10px] font-black tracking-[.08em] text-slate-100"><Clipboard size={15} />COPY UPI ID</Button></div><p className="mt-5 text-sm leading-6 text-slate-400">{data.instructions}</p></div><div className="mt-6 space-y-3"><Button onClick={() => { if (upiPaymentUrl) window.location.assign(upiPaymentUrl); }} disabled={!upiPaymentUrl} variant="outline" className="h-12 w-full border-violet-200/35 bg-violet-300/[.08] text-xs font-black tracking-[.08em] text-violet-100 hover:bg-violet-300/[.14]">PAY NOW IN UPI APP <ArrowRight size={17} /></Button><Button onClick={() => setPaymentStep("proof")} disabled={!paymentDetailsReady} className="h-12 w-full rounded-xl bg-gradient-to-r from-violet-300 to-fuchsia-300 text-xs font-black tracking-[.08em] text-[#18072b]">I HAVE PAID <CheckCircle2 size={17} /></Button><button type="button" onClick={() => setPaymentStep("package")} className="flex w-full items-center justify-center gap-2 text-xs font-bold text-slate-400 transition hover:text-white"><ArrowLeft size={14} />Change package</button></div></div></div></section>}

      {chosen && paymentStep === "proof" && <section className="grid gap-5 lg:grid-cols-[.82fr_1.18fr]"><div className="rounded-[1.5rem] border border-fuchsia-300/20 bg-fuchsia-300/[.05] p-5 sm:p-6"><p className="text-[10px] font-black tracking-[.15em] text-fuchsia-200">3 · PAYMENT CONFIRMATION</p><h2 className="mt-2 font-display text-2xl font-bold text-white">I have paid ₹{formatCredits(chosen.priceInr)}</h2><div className="mt-5 rounded-xl border border-white/[.08] bg-black/20 p-4"><p className="text-[10px] font-black tracking-[.12em] text-slate-500">YOU ARE REQUESTING</p><p className="mt-2 font-display text-xl font-bold text-violet-100">{formatCredits(chosen.credits)} Tournament Credits</p><p className="mt-2 text-xs leading-5 text-slate-400">Submit your UTR and payment screenshot. The request remains pending until an administrator verifies it.</p></div><button type="button" onClick={() => setPaymentStep("pay")} className="mt-5 flex items-center gap-2 text-xs font-bold text-slate-400 transition hover:text-white"><ArrowLeft size={14} />Back to QR payment details</button></div><div className="rounded-[1.5rem] border border-violet-200/20 bg-[#0e0a1b] p-5 sm:p-6"><p className="text-[10px] font-black tracking-[.15em] text-violet-200">PAYMENT PROOF</p><h2 className="mt-1 font-display text-xl font-bold text-white">Submit Payment for Verification</h2><div className="mt-5 space-y-4"><Field label="UTR / Transaction ID" id="payment-utr"><Input id="payment-utr" value={utr} onChange={(event) => setUtr(event.target.value)} placeholder="Enter UPI UTR or transaction ID" maxLength={100} className="plx-wallet-input" /></Field><div><label className="text-xs font-bold text-slate-300">Payment screenshot</label><label className="mt-2 flex min-h-28 cursor-pointer items-center justify-center rounded-xl border border-dashed border-violet-200/[.22] bg-violet-300/[.03] px-4 text-center transition hover:border-violet-200/45 hover:bg-violet-300/[.06]"><input type="file" accept="image/png,image/jpeg,image/webp" onChange={fileChange} className="sr-only" /><span>{screenshot ? <><ImageUp className="mx-auto h-6 w-6 text-violet-100" /><span className="mt-2 block text-xs font-bold text-violet-100">{fileName}</span></> : <><UploadCloud className="mx-auto h-6 w-6 text-slate-400" /><span className="mt-2 block text-xs font-bold text-slate-300">Upload PNG, JPG, or WebP · max 4 MB</span></>}</span></label></div><Button aria-label={submit.isPending ? "Submitting payment proof" : "Submit payment for verification"} onClick={() => submit.mutate({ packageId: chosen.id, utr: utr.trim(), screenshotDataUrl: screenshot })} disabled={!paymentProofReady || paymentSubmissionState.isLocked} className="h-12 w-full rounded-xl bg-gradient-to-r from-violet-300 to-fuchsia-300 text-xs font-black tracking-[.08em] text-[#18072b]">{submit.isPending ? <Loader2 className="animate-spin" size={16} /> : paymentSubmissionState.buttonLabel}</Button><p className="text-center text-[11px] leading-5 text-slate-500">No Credits are added automatically. PLX Administration must approve this payment.</p></div></div></section>}
    </div>}
  </div>;
}

function CompactBalance({ label, value, tone }: { label: string; value: string; tone: "violet" | "emerald" | "fuchsia" }) {
  const tones = { violet: "text-violet-100", emerald: "text-emerald-200", fuchsia: "text-fuchsia-200" };
  return <div className="min-w-0"><p className="truncate text-[9px] font-black tracking-[.14em] text-slate-500">{label}</p><p className={`mt-1 truncate font-display text-lg font-bold sm:text-xl ${tones[tone]}`}>{value}</p></div>;
}

function BalanceCard({ icon, label, value, hint, tone }: { icon: React.ReactNode; label: string; value: string; hint: string; tone: "violet" | "emerald" | "fuchsia" }) {
  const styles = { violet: "border-violet-200/[.15] bg-violet-300/[.07] text-violet-100", emerald: "border-emerald-300/[.16] bg-emerald-300/[.07] text-emerald-200", fuchsia: "border-fuchsia-300/[.15] bg-fuchsia-300/[.06] text-fuchsia-200" };
  return <article className={`rounded-[1.45rem] border p-4 shadow-[0_12px_28px_rgba(3,2,9,.12)] ${styles[tone]}`}><div className="flex items-center gap-2 text-[10px] font-black tracking-[.13em]"><span>{icon}</span>{label}</div><p className="mt-4 font-display text-3xl font-bold text-white">{value}</p><p className="mt-1 text-xs leading-5 text-slate-400">{hint}</p></article>;
}

function StatusChip({ label, tone = "neutral" }: { label: string; tone?: "emerald" | "neutral" }) {
  return <span className={`rounded-xl border px-3 py-2 text-[10px] font-black tracking-[.08em] ${tone === "emerald" ? "border-emerald-300/20 bg-emerald-300/[.08] text-emerald-100" : "border-white/[.1] bg-black/15 text-slate-400"}`}>{label}</span>;
}

function Field({ label, id, children }: { label: string; id: string; children: React.ReactNode }) {
  return <div><label htmlFor={id} className="text-xs font-bold text-slate-300">{label}</label><div className="mt-2">{children}</div></div>;
}

function EmptyState({ children }: { children: React.ReactNode }) {
  return <p className="mt-5 rounded-xl border border-dashed border-white/[.12] bg-black/15 p-5 text-sm leading-6 text-slate-500">{children}</p>;
}

function HistoryPanels({ paymentRequests, withdrawals }: { paymentRequests: Array<{ id: number; creditsRequested: number; amountPaid: number; utr: string; createdAt: Date; status: "pending" | "approved" | "rejected" }>; withdrawals: Array<{ id: number; amount: number; withdrawalCode: string; createdAt: Date; status: "pending" | "approved" | "processing" | "paid" | "rejected"; upiId: string; rejectionReason?: string | null }> }) {
  return <div className="grid gap-5 lg:grid-cols-2"><section className="rounded-[1.55rem] border border-violet-200/[.12] bg-[#0e0a1a]/85 p-5"><div className="flex items-center justify-between gap-3"><div><p className="text-[10px] font-black tracking-[.15em] text-violet-200">TRANSACTION HISTORY</p><h2 className="mt-1 font-display text-xl font-bold text-white">Payment verification</h2></div><ReceiptText size={20} className="text-violet-200" /></div>{paymentRequests.length ? <div className="mt-4 divide-y divide-white/[.06]">{paymentRequests.map((request) => <article key={request.id} className="flex flex-wrap items-center justify-between gap-3 py-3.5 first:pt-0"><div><p className="font-bold text-slate-200">{formatCredits(request.creditsRequested)} Credits <span className="text-slate-600">•</span> ₹{formatCredits(request.amountPaid)}</p><p className="mt-1 text-xs text-slate-500">UTR {request.utr} · {formatDateShort(request.createdAt)}</p></div><PaymentStatus status={request.status} /></article>)}</div> : <EmptyState>Your submitted payment requests will appear here.</EmptyState>}</section><section className="rounded-[1.55rem] border border-emerald-300/[.13] bg-[#0e0a1a]/85 p-5"><div className="flex flex-wrap items-end justify-between gap-3"><div><p className="text-[10px] font-black tracking-[.15em] text-emerald-200">WITHDRAWAL HISTORY</p><h2 className="mt-1 font-display text-xl font-bold text-white">Your payout requests</h2></div><span className="text-[10px] font-bold text-slate-500">Local timezone</span></div>{withdrawals.length ? <div className="mt-4 divide-y divide-white/[.06]">{withdrawals.map((request) => <article key={request.id} className="py-3.5 first:pt-0"><div className="flex flex-wrap items-center justify-between gap-3"><div><p className="font-display text-lg font-bold text-white">₹{formatCredits(request.amount)}</p><p className="mt-1 text-xs text-slate-500">{request.withdrawalCode} · {formatDateTime(request.createdAt)}</p></div><WithdrawalStatus status={request.status} /></div><p className="mt-2 text-xs text-slate-400">UPI: {maskUpi(request.upiId)}</p>{request.rejectionReason && <p className="mt-2 rounded-lg border border-rose-300/15 bg-rose-300/[.06] px-3 py-2 text-xs text-rose-100">Administrator note: {request.rejectionReason}</p>}</article>)}</div> : <EmptyState>Your UPI withdrawal requests will appear here after you submit one.</EmptyState>}</section></div>;
}

function PaymentStatus({ status }: { status: "pending" | "approved" | "rejected" }) {
  const tones = { pending: "bg-orange-300/10 text-orange-200", approved: "bg-emerald-300/10 text-emerald-200", rejected: "bg-rose-300/10 text-rose-200" };
  return <span className={`rounded-full px-3 py-1 text-[10px] font-black tracking-[.1em] ${tones[status]}`}>{status.toUpperCase()}</span>;
}

function WithdrawalStatus({ status }: { status: "pending" | "approved" | "processing" | "paid" | "rejected" }) {
  const tones = { pending: "bg-orange-300/10 text-orange-200", approved: "bg-cyan-300/10 text-cyan-100", processing: "bg-violet-300/10 text-violet-100", paid: "bg-emerald-300/10 text-emerald-200", rejected: "bg-rose-300/10 text-rose-200" };
  return <span className={`rounded-full px-3 py-1 text-[10px] font-black tracking-[.1em] ${tones[status]}`}>{status.toUpperCase()}</span>;
}

function maskUpi(value: string) {
  if (value.includes("@")) { const [name, provider] = value.split("@"); return `${name.slice(0, 2)}•••@${provider}`; }
  return value.length <= 4 ? "••••" : `•••• ${value.slice(-4)}`;
}

function WalletSkeleton() {
  return <div className="space-y-5"><div className="h-52 animate-pulse rounded-[1.75rem] border border-violet-200/[.08] bg-violet-300/[.04]" /><div className="grid gap-3 sm:grid-cols-3">{Array.from({ length: 3 }).map((_, index) => <div key={index} className="h-36 animate-pulse rounded-[1.45rem] border border-white/[.06] bg-white/[.03]" />)}</div><div className="h-72 animate-pulse rounded-[1.75rem] border border-white/[.06] bg-white/[.03]" /></div>;
}
