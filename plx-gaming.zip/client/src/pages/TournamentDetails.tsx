import { JoinTournamentButton } from "@/components/JoinTournamentButton";
import { PublicLayout } from "@/components/PublicLayout";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { formatCredits, formatDateTime, titleCase } from "@/lib/format";
import { trpc } from "@/lib/trpc";
import {
  CalendarClock,
  ChevronLeft,
  CircleAlert,
  ClipboardCheck,
  Coins,
  Crown,
  LockKeyhole,
  MapPinned,
  Radio,
  ScrollText,
  UsersRound,
} from "lucide-react";
import { Link, useRoute } from "wouter";

export default function TournamentDetails() {
  const [, params] = useRoute("/tournaments/:slug");
  const { data: tournament, isLoading } = trpc.public.tournamentBySlug.useQuery(
    { slug: params?.slug ?? "" },
    { enabled: Boolean(params?.slug) },
  );

  if (isLoading) {
    return <PublicLayout><div className="container py-6"><Skeleton className="h-[34rem] rounded-[1.75rem] bg-violet-300/[.06]" /></div></PublicLayout>;
  }

  if (!tournament) {
    return <PublicLayout><div className="container py-20 text-center"><CircleAlert className="mx-auto h-10 w-10 text-fuchsia-200" /><h1 className="mt-4 font-display text-3xl font-bold text-white">Tournament not found</h1><Link href="/tournaments/upcoming" className="mt-5 inline-flex items-center text-sm font-bold text-violet-100">Browse tournaments <ChevronLeft className="ml-1 rotate-180" size={16} /></Link></div></PublicLayout>;
  }

  const slots = Math.min(100, Math.round((tournament.filledSlots / tournament.totalSlots) * 100));
  const full = tournament.remainingSlots <= 0 && tournament.status === "upcoming";

  return (
    <PublicLayout>
      <section className="container py-5 sm:py-8">
        <Link href="/tournaments/upcoming" className="inline-flex items-center gap-1.5 text-[10px] font-extrabold tracking-[.1em] text-slate-400 transition hover:text-violet-100">
          <ChevronLeft size={15} /> ALL TOURNAMENTS
        </Link>

        <div className="mt-4 overflow-hidden rounded-[1.75rem] border border-violet-200/[.14] bg-[#0e0919]/92 shadow-[0_20px_54px_rgba(20,5,48,.28)]">
          <div className="relative min-h-56 overflow-hidden border-b border-violet-200/[.1] bg-[linear-gradient(125deg,rgba(75,30,156,.72),rgba(20,8,41,.72)),radial-gradient(circle_at_88%_30%,rgba(236,72,153,.36),transparent_26%)] px-5 py-6 sm:px-8 sm:py-9">
            {tournament.bannerUrl && <img src={tournament.bannerUrl} alt="" className="absolute inset-0 h-full w-full object-cover opacity-35" />}
            <div className="absolute inset-0 bg-[linear-gradient(125deg,rgba(13,5,29,.68),rgba(13,5,29,.84))]" />
            <div className="absolute -right-8 -top-9 h-52 w-52 rounded-full border border-fuchsia-200/15" />

            <div className="relative flex flex-wrap items-center gap-2">
              <Badge className="border border-violet-200/30 bg-violet-300/[.14] px-2 py-1 text-[9px] font-black tracking-[.13em] text-violet-50">{full ? "FULL" : tournament.status.toUpperCase()}</Badge>
              {tournament.status === "live" && <span className="inline-flex items-center gap-1.5 rounded-full border border-rose-200/30 bg-rose-400/10 px-2 py-1 text-[9px] font-black tracking-[.12em] text-rose-100"><span className="h-1.5 w-1.5 animate-pulse rounded-full bg-rose-200" />LIVE NOW</span>}
            </div>
            <h1 className="relative mt-4 max-w-2xl font-display text-3xl font-bold leading-tight text-white drop-shadow-[0_3px_12px_rgba(0,0,0,.7)] sm:text-5xl">{tournament.name}</h1>
            <div className="relative mt-4 flex flex-wrap gap-x-5 gap-y-2 text-xs font-semibold text-violet-100/95 drop-shadow-[0_2px_8px_rgba(0,0,0,.72)]">
              <span className="inline-flex items-center gap-2"><UsersRound size={15} className="text-violet-200" />{titleCase(tournament.mode)}</span>
              <span className="inline-flex items-center gap-2"><MapPinned size={15} className="text-fuchsia-200" />{tournament.map}</span>
              <span className="inline-flex items-center gap-2"><CalendarClock size={15} className="text-violet-200" />{formatDateTime(tournament.startsAt)}</span>
            </div>
          </div>

          <div className="grid gap-5 p-5 sm:p-7 lg:grid-cols-[minmax(0,1fr)_320px]">
            <div className="space-y-5">
              <InfoCard icon={<ScrollText size={17} />} label="TOURNAMENT RULES" title="Rules of engagement" content={tournament.rules || "Tournament-specific rules will be published by the organizer. Always use accurate Free Fire player details and follow PLX fair-play requirements."} />
              <InfoCard icon={<ClipboardCheck size={17} />} label="MATCH INSTRUCTIONS" title="Ready your squad" content={tournament.instructions || "Join on time, monitor the tournament status, and wait for official lobby information from the organizer."} />
              <LobbyCard tournament={tournament} />
            </div>

            <aside className="space-y-4">
              <div className="rounded-[1.4rem] border border-violet-200/[.16] bg-[linear-gradient(145deg,rgba(116,55,239,.15),rgba(236,72,153,.055))] p-4">
                <p className="text-[9px] font-black tracking-[.16em] text-violet-100">ENTRY STATUS</p>
                <div className="mt-4 grid grid-cols-2 gap-2">
                  <Stat label="Prize pool" value={`${formatCredits(tournament.prizePool)} CR`} icon={<Crown size={16} />} />
                  <Stat label="Entry fee" value={`${formatCredits(tournament.entryFee)} CR`} icon={<Coins size={16} />} />
                </div>
                <div className="mt-4">
                  <div className="flex justify-between text-xs font-semibold text-slate-400"><span>Lobby slots</span><span className="text-violet-100">{tournament.filledSlots} / {tournament.totalSlots}</span></div>
                  <div className="mt-2 h-2 overflow-hidden rounded-full bg-white/[.07]"><div className="h-full rounded-full bg-gradient-to-r from-violet-400 via-fuchsia-400 to-pink-400" style={{ width: `${slots}%` }} /></div>
                  <p className="mt-2 text-[10px] text-slate-500">{tournament.remainingSlots ? `${tournament.remainingSlots} slots remaining` : "Lobby full"}</p>
                </div>
                <JoinTournamentButton tournament={tournament} joined={tournament.hasJoined} className="mt-5 h-12 w-full rounded-xl bg-gradient-to-r from-violet-500 to-fuchsia-500 text-[10px] font-black tracking-[.1em] text-white shadow-[0_9px_24px_rgba(168,85,247,.25)]" />
              </div>

              <div className="rounded-[1.4rem] border border-violet-200/[.1] bg-white/[.025] p-4">
                <p className="text-[9px] font-black tracking-[.15em] text-slate-500">ENTRY CONFIRMATION</p>
                <p className="mt-2 text-sm font-bold text-white">{tournament.hasJoined ? "You are registered" : "Secure your place"}</p>
                <p className="mt-1 text-xs leading-5 text-slate-400">{tournament.hasJoined ? "Your player details and entry are confirmed. Watch this page for organizer updates." : "Tournament Credits are only deducted after a secure server-side confirmation."}</p>
              </div>
            </aside>
          </div>
        </div>
      </section>
    </PublicLayout>
  );
}

function InfoCard({ icon, label, title, content }: { icon: React.ReactNode; label: string; title: string; content: string }) {
  return <section className="rounded-[1.4rem] border border-violet-200/[.1] bg-white/[.025] p-5"><p className="inline-flex items-center gap-2 text-[9px] font-black tracking-[.16em] text-violet-100">{icon}{label}</p><h2 className="mt-2 font-display text-xl font-bold text-white">{title}</h2><p className="mt-3 whitespace-pre-wrap text-sm leading-7 text-slate-400">{content}</p></section>;
}

function LobbyCard({ tournament }: { tournament: { hasJoined: boolean; roomId: string | null; roomPassword: string | null; matchId: string | null; roomCredentialsPublished: boolean } }) {
  const ready = tournament.hasJoined && tournament.roomCredentialsPublished && Boolean(tournament.roomId);
  return <section className="rounded-[1.4rem] border border-violet-200/[.1] bg-white/[.025] p-5"><p className="inline-flex items-center gap-2 text-[9px] font-black tracking-[.16em] text-violet-100"><Radio size={16} />MATCH LOBBY</p><h2 className="mt-2 font-display text-xl font-bold text-white">Organizer-issued access</h2>{ready ? <div className="mt-4 grid gap-2 sm:grid-cols-2"><Code label="ROOM ID" value={tournament.roomId!} /><Code label="ROOM PASSWORD" value={tournament.roomPassword || "Not required"} /></div> : <div className="mt-4 flex gap-3 rounded-xl border border-violet-200/[.1] bg-black/15 p-3"><LockKeyhole size={17} className="mt-0.5 shrink-0 text-violet-200" /><p className="text-xs leading-5 text-slate-400">{tournament.hasJoined ? "Lobby credentials will appear here as soon as the organizer publishes them." : "Join this tournament to access lobby credentials after the organizer publishes them."}</p></div>}{ready && tournament.matchId && <p className="mt-3 text-xs text-violet-100/75">Match ID: <span className="font-bold text-white">{tournament.matchId}</span></p>}</section>;
}

function Code({ label, value }: { label: string; value: string }) {
  return <div className="rounded-xl border border-violet-200/[.1] bg-black/20 p-3"><p className="text-[9px] font-black tracking-[.14em] text-slate-500">{label}</p><p className="mt-1 break-all font-mono text-sm font-bold text-violet-100">{value}</p></div>;
}

function Stat({ label, value, icon }: { label: string; value: string; icon: React.ReactNode }) {
  return <div className="rounded-xl border border-violet-200/[.1] bg-black/15 p-3"><span className="text-fuchsia-100">{icon}</span><p className="mt-2 text-[9px] font-bold uppercase tracking-wider text-slate-500">{label}</p><p className="mt-1 font-display text-base font-bold text-white">{value}</p></div>;
}
