// @vitest-environment jsdom
import { cleanup, fireEvent, render, screen } from "@testing-library/react";
import { createElement } from "react";
import * as React from "react";
import { afterEach, describe, expect, it, vi } from "vitest";

const profileData = {
  profile: { id: 7, displayName: "PLX Raven", playerName: "Raven", gameUid: "123456789012", playerId: "PLX-000007", avatarUrl: null, joinedAt: new Date("2026-01-01"), preferredGameMode: "squad" },
  balance: 75,
  winningBalance: 220,
  bonusBalance: 15,
  stats: { matchesPlayed: 12, tournamentsWon: 2, totalTournaments: 12, bestRank: 1, totalKills: 54, totalPrizeCredits: 220, winRate: 16.7 },
  entries: [],
  transactions: [],
};

vi.mock("@/_core/hooks/useAuth", () => ({ useAuth: () => ({ logout: vi.fn() }) }));
vi.mock("@/components/PublicLayout", () => ({ PublicLayout: ({ children }: { children: React.ReactNode }) => createElement("div", null, children) }));
vi.mock("@/components/PlayerGate", () => ({ PlayerGate: ({ children }: { children: React.ReactNode }) => createElement("div", null, children) }));
vi.mock("@/lib/trpc", () => ({
  trpc: {
    player: {
      profileOverview: { useQuery: () => ({ data: profileData, isLoading: false, isError: false }) },
      profile: { useMutation: () => ({ mutate: vi.fn(), isPending: false }) },
      dashboard: { invalidate: vi.fn() },
      myTournaments: { invalidate: vi.fn() },
    },
    auth: {
      googleStatus: { useQuery: () => ({ data: { linked: true, email: "raven@example.test", canUnlink: true } }) },
      unlinkGoogle: { useMutation: () => ({ mutate: vi.fn(), isPending: false }) },
      logoutAllLocalSessions: { useMutation: () => ({ mutate: vi.fn(), isPending: false }) },
    },
    telegramLink: {
      createCode: { useMutation: () => ({ mutate: vi.fn(), isPending: false }) },
    },
    useUtils: () => ({ player: { profileOverview: { invalidate: vi.fn() }, dashboard: { invalidate: vi.fn() }, myTournaments: { invalidate: vi.fn() } }, auth: { googleStatus: { invalidate: vi.fn() } } }),
  },
}));

import Profile from "./Profile";

afterEach(() => { cleanup(); });

describe("PLX native private Profile", () => {
  it("renders authenticated player identity, verified metrics, wallet snapshot, and private tabs", () => {
    vi.stubGlobal("React", React);
    render(createElement(Profile));

    expect(screen.getByText("PRIVATE PLAYER PROFILE")).toBeTruthy();
    expect(screen.getByText("Your PLX esports identity")).toBeTruthy();
    expect(screen.getByText("PLX Raven")).toBeTruthy();
    expect(screen.getByText("PLX-000007")).toBeTruthy();
    expect(screen.getByText((_, element) => element?.textContent === "75 CR")).toBeTruthy();
    expect(screen.getByText("Verified player milestones")).toBeTruthy();
    expect(screen.getByText("Your private account controls")).toBeTruthy();

    fireEvent.click(screen.getByRole("tab", { name: /my tournaments/i }));
    expect(screen.getByText("NO TOURNAMENTS YET")).toBeTruthy();

    fireEvent.click(screen.getByRole("tab", { name: /credits/i }));
    expect(screen.getByText("OPEN PLX WALLET")).toBeTruthy();
    expect(screen.getByText("Private ledger")).toBeTruthy();
  });
});
