// @vitest-environment jsdom
import { cleanup, render, screen } from "@testing-library/react";
import { createElement } from "react";
import * as React from "react";
import { afterEach, describe, expect, it, vi } from "vitest";

vi.mock("@/components/PublicLayout", () => ({ PublicLayout: ({ children }: { children: React.ReactNode }) => createElement("div", null, children) }));
vi.mock("@/components/TournamentCard", () => ({ TournamentCard: ({ tournament }: { tournament: { name: string } }) => createElement("article", null, `Verified tournament: ${tournament.name}`) }));
vi.mock("@/lib/trpc", () => ({
  trpc: {
    public: {
      tournaments: { useQuery: () => ({ isLoading: false, isError: false, data: [{ id: 1, name: "PLX Open", mode: "solo", status: "upcoming", remainingSlots: 8 }] }) },
      liveFeed: { useQuery: () => ({ isLoading: false, isError: false, data: { live: [], startingSoon: [], recentResults: [] } }) },
      leaderboard: { useQuery: () => ({ isLoading: false, isError: false, data: { entries: [], tournaments: [], myRank: null } }) },
    },
  },
}));

import Tournaments from "./Tournaments";
import Live from "./Live";
import Leaderboard from "./Leaderboard";

afterEach(() => cleanup());

describe("PLX native arena screens", () => {
  it("keeps real tournament filters and server-backed event cards on the mobile tournament board", () => {
    vi.stubGlobal("React", React);
    render(createElement(Tournaments, { status: "upcoming" }));
    expect(screen.getByRole("heading", { name: "Upcoming tournaments" })).toBeTruthy();
    expect(screen.getByRole("button", { name: "Full" })).toBeTruthy();
    expect(screen.getByRole("button", { name: "Squad" })).toBeTruthy();
    expect(screen.getByText("Verified tournament: PLX Open")).toBeTruthy();
  });

  it("uses honest verified-data empty states for Live and Leaderboard instead of fabricated results", () => {
    vi.stubGlobal("React", React);
    const { unmount } = render(createElement(Live));
    expect(screen.getByRole("heading", { name: /no live matches/i })).toBeTruthy();
    unmount();
    render(createElement(Leaderboard));
    expect(screen.getByRole("heading", { name: "No verified results yet" })).toBeTruthy();
    expect(screen.getByRole("button", { name: "Tournament" })).toBeTruthy();
  });
});
