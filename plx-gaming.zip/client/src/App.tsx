import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import ContentPage from "@/pages/ContentPage";
import Admin from "@/pages/Admin";
import Auth from "@/pages/Auth";
import Dashboard from "@/pages/Dashboard";
import Home from "@/pages/Home";
import Leaderboard from "@/pages/Leaderboard";
import MyTournaments from "@/pages/MyTournaments";
import NotFound from "@/pages/NotFound";
import Profile from "@/pages/Profile";
import TournamentDetails from "@/pages/TournamentDetails";
import Tournaments from "@/pages/Tournaments";
import Transactions from "@/pages/Transactions";
import Wallet from "@/pages/Wallet";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";

function Router() {
  return <Switch>
    <Route path="/" component={Home} />
    <Route path="/auth" component={Auth} />
    <Route path="/tournaments/upcoming"><Tournaments status="upcoming" /></Route>
    <Route path="/tournaments/live"><Tournaments status="live" /></Route>
    <Route path="/tournaments/completed"><Tournaments status="completed" /></Route>
    <Route path="/tournaments/:slug" component={TournamentDetails} />
    <Route path="/leaderboard" component={Leaderboard} />
    <Route path="/rules"><ContentPage kind="rules" /></Route>
    <Route path="/how-it-works"><ContentPage kind="how-it-works" /></Route>
    <Route path="/terms"><ContentPage kind="terms" /></Route>
    <Route path="/privacy"><ContentPage kind="privacy" /></Route>
    <Route path="/support"><ContentPage kind="support" /></Route>
    <Route path="/dashboard" component={Dashboard} />
    <Route path="/my-tournaments" component={MyTournaments} />
    <Route path="/wallet" component={Wallet} />
    <Route path="/transactions" component={Transactions} />
    <Route path="/profile" component={Profile} />
    <Route path="/admin" component={() => <Admin page="overview" />} />
    <Route path="/admin/home" component={() => <Admin page="home" />} />
    <Route path="/admin/tournaments" component={() => <Admin page="tournaments" />} />
    <Route path="/admin/users" component={() => <Admin page="users" />} />
    <Route path="/admin/participants" component={() => <Admin page="participants" />} />
    <Route path="/admin/payments" component={() => <Admin page="payments" />} />
    <Route path="/admin/results" component={() => <Admin page="results" />} />
    <Route path="/admin/leaderboard" component={() => <Admin page="results" />} />
    <Route path="/admin/packages" component={() => <Admin page="packages" />} />
    <Route path="/admin/social" component={() => <Admin page="social" />} />
    <Route path="/admin/settings" component={() => <Admin page="settings" />} />
    <Route path="/404" component={NotFound} />
    <Route component={NotFound} />
  </Switch>;
}

export default function App() { return <ErrorBoundary><ThemeProvider defaultTheme="dark"><TooltipProvider><Toaster richColors theme="dark" /><Router /></TooltipProvider></ThemeProvider></ErrorBoundary>; }
