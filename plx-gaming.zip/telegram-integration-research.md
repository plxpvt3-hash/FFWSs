# Telegram Integration Research Notes

## Official webhook constraints

Telegram's Bot API specifies that `setWebhook` sends JSON-serialized updates through HTTPS POST requests and retries unsuccessful non-2xx requests for a reasonable number of attempts. PLX must therefore keep webhook processing idempotent and return a successful response only after accepting a bounded update for handling.

Telegram supports a `secret_token` from 1 to 256 characters, using only letters, digits, underscores, and hyphens. When configured, Telegram sends it in the `X-Telegram-Bot-Api-Secret-Token` header. The PLX webhook must compare this header with its server-side secret before parsing or acting on a callback.

PLX should request only `message` and `callback_query` update types, retain no bot token in source code, and use the existing server and database rather than polling or running uploaded Python code.

## Source

- [Telegram Bot API — setWebhook](https://core.telegram.org/bots/api#setwebhook), accessed 2026-08-21.
