# PLX Wallet Mobile-App Upgrade Brief

The Wallet must become a fixed native-style app route with a stable header, scrollable content region, fixed six-item bottom navigation, safe-area support, no body-level scrolling, no horizontal overflow, and clearance above the navigation. Preserve PLX’s dark navy/black visual identity, violet glass panels, purple-to-pink highlights, cyan/green winnings accent, large rounded cards, futuristic typography, touch feedback, and subtle motion.

The screen should show a real-data Wallet header, a compact balance summary for Tournament Credits, Available Winnings, and Bonus, plus horizontally scrollable Overview, My Tournaments, and Credits tabs. The active tab needs a violet glass glow without causing page-level horizontal overflow.

The overview should retain real balances and make Tournament Credits, Available Winnings, and Bonus visually distinct. It requires an authentic Winnings Payout card with server-validated withdrawal action, current availability, configured minimum withdrawal, active-request rule, UPI collection/confirmation, pending feedback, and no artificial success state.

The PLX Credits area must preserve the configured packages, selection state, UPI QR/payment information, transaction-reference and optional screenshot proof submission, manual pending review, and administrator-only credit approval. Credits must never be added before verified approval.

Transaction History must use the existing ledger and payment data, including type, amount, Credits, UTR/reference, local-time date, and real status. Withdrawal History must use existing protected request data, show masked UPI, amount, date, status, and any administrator remark, with a clear empty state. All existing server-side balance, duplicate request, duplicate UTR, authorization, and ledger protections remain mandatory.
