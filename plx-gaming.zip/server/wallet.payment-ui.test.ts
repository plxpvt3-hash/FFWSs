// @vitest-environment jsdom
import { fireEvent, render, screen, waitFor } from "@testing-library/react";
import { createElement } from "react";
import * as React from "react";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

const state = vi.hoisted(() => ({
  mode: "success" as "success" | "pending",
  mutate: vi.fn(),
}));

vi.mock("@/components/PlayerGate", () => ({ PlayerGate: ({ children }: { children: unknown }) => children }));
vi.mock("@/components/PlayerHeader", () => ({ PlayerHeader: () => createElement("div") }));
vi.mock("@/components/PublicLayout", () => ({ PublicLayout: ({ children }: { children: unknown }) => children }));
vi.mock("@/components/ui/button", () => ({ Button: ({ children, ...props }: any) => createElement("button", props, children) }));
vi.mock("@/components/ui/input", () => ({ Input: (props: any) => createElement("input", props) }));
vi.mock("sonner", () => ({ toast: { success: vi.fn(), error: vi.fn() } }));
vi.mock("qrcode", () => ({ default: { toDataURL: vi.fn().mockResolvedValue("data:image/png;base64,qr") } }));
vi.mock("@/lib/trpc", () => ({
  trpc: {
    player: {
      addCredits: {
        useQuery: () => ({
          isLoading: false,
          data: {
            packages: [{ id: 70, priceInr: 70, credits: 70 }],
            upiId: "plx@upi",
            qrCodeUrl: "https://payments.example/plx-qr.png",
            instructions: "Pay the selected package amount.",
            requests: [],
          },
        }),
      },
      dashboard: { useQuery: () => ({ data: { balance: 10 }, refetch: vi.fn() }) },
      submitPaymentRequest: {
        useMutation: (options: any) => ({
          isPending: state.mode === "pending",
          mutate: (input: unknown) => {
            state.mutate(input);
            if (state.mode === "success") options.onSuccess?.();
          },
        }),
      },
    },
    useUtils: () => ({ player: { addCredits: { invalidate: vi.fn() }, transactions: { invalidate: vi.fn() }, dashboard: { invalidate: vi.fn() } } }),
  },
}));

import Wallet from "../client/src/pages/Wallet";

async function openProofStep() {
  render(createElement(Wallet));
  fireEvent.click(screen.getByRole("button", { name: /select package/i }));
  fireEvent.click(screen.getByRole("button", { name: /pay with upi/i }));
  fireEvent.click(screen.getByRole("button", { name: /i have paid/i }));
}

describe("PLX Wallet payment proof UI", () => {
  beforeEach(() => {
    vi.stubGlobal("React", React);
    state.mode = "success";
    state.mutate.mockReset();
  });

  afterEach(() => {
    document.body.innerHTML = "";
  });

  it("renders Pending Verification after a successful payment-proof submission", async () => {
    await openProofStep();
    fireEvent.change(screen.getByLabelText(/utr/i), { target: { value: "UPI-REF-777" } });
    const file = new File(["proof"], "payment.png", { type: "image/png" });
    fireEvent.change(document.querySelector('input[type="file"]')!, { target: { files: [file] } });
    await waitFor(() => expect(screen.getByText("payment.png")).toBeTruthy());
    fireEvent.click(screen.getByRole("button", { name: /submit payment for verification/i }));
    await waitFor(() => expect(screen.getByText(/payment pending review/i)).toBeTruthy());
    expect(state.mutate).toHaveBeenCalledWith(expect.objectContaining({ packageId: 70, utr: "UPI-REF-777" }));
  });

  it("locks and shows progress on the proof-submit action while a request is in flight", async () => {
    state.mode = "pending";
    await openProofStep();
    const submitButton = screen.getByRole("button", { name: /submitting payment proof/i });
    expect(submitButton).toHaveProperty("disabled", true);
    expect(document.querySelector(".animate-spin")).toBeTruthy();
  });
});
