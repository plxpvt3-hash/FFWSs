import { randomBytes, scrypt as scryptCallback, timingSafeEqual, createHash } from "crypto";
import { promisify } from "util";
import type { Request } from "express";
import { and, eq, gt, isNull } from "drizzle-orm";
import { parse } from "cookie";
import { localCredentials, localSessions, users, wallets } from "../drizzle/schema";
import { getDb } from "./db";

const scrypt = promisify(scryptCallback);
const SESSION_DURATION_MS = 7 * 24 * 60 * 60 * 1000;
export const LOCAL_SESSION_COOKIE = "plx-local-session";

export function normalizeEmail(email: string) {
  return email.trim().toLowerCase();
}

export async function hashPassword(password: string) {
  const salt = randomBytes(16);
  const derivedKey = await scrypt(password, salt, 64) as Buffer;
  return `scrypt$${salt.toString("base64url")}$${derivedKey.toString("base64url")}`;
}

export async function verifyPassword(password: string, encoded: string) {
  const [algorithm, encodedSalt, encodedKey] = encoded.split("$");
  if (algorithm !== "scrypt" || !encodedSalt || !encodedKey) return false;
  try {
    const expected = Buffer.from(encodedKey, "base64url");
    const candidate = await scrypt(password, Buffer.from(encodedSalt, "base64url"), expected.length) as Buffer;
    return expected.length === candidate.length && timingSafeEqual(expected, candidate);
  } catch {
    return false;
  }
}

function hashSessionToken(rawToken: string) {
  return createHash("sha256").update(rawToken).digest("hex");
}

export function getLocalSessionToken(req: Request) {
  return parse(req.headers.cookie ?? "")[LOCAL_SESSION_COOKIE];
}

export async function createLocalAccount(input: { email: string; password: string; name: string }) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const email = normalizeEmail(input.email);
  const passwordHash = await hashPassword(input.password);
  const localOpenId = `local_${randomBytes(18).toString("hex")}`;

  return db.transaction(async (tx) => {
    const [existing] = await tx.select({ id: users.id }).from(users).where(eq(users.email, email)).limit(1);
    if (existing) return null;
    const [inserted] = await tx.insert(users).values({
      openId: localOpenId,
      email,
      name: input.name.trim(),
      loginMethod: "email_password",
    });
    await tx.insert(localCredentials).values({ userId: inserted.insertId, passwordHash });
    await tx.insert(wallets).values({ userId: inserted.insertId, balance: 0 });
    const [user] = await tx.select().from(users).where(eq(users.id, inserted.insertId)).limit(1);
    return user ?? null;
  });
}

export async function authenticateLocalAccount(emailInput: string, password: string) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const email = normalizeEmail(emailInput);
  const rows = await db.select({ user: users, passwordHash: localCredentials.passwordHash })
    .from(users)
    .innerJoin(localCredentials, eq(localCredentials.userId, users.id))
    .where(eq(users.email, email)).limit(1);
  const account = rows[0];
  if (!account || account.user.isBlocked || !(await verifyPassword(password, account.passwordHash))) return null;
  await db.update(users).set({ lastSignedIn: new Date() }).where(eq(users.id, account.user.id));
  return account.user;
}

export async function createLocalSession(userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const rawToken = randomBytes(32).toString("base64url");
  const expiresAt = new Date(Date.now() + SESSION_DURATION_MS);
  await db.insert(localSessions).values({ userId, tokenHash: hashSessionToken(rawToken), expiresAt });
  return { rawToken, expiresAt };
}

export async function resolveLocalSession(rawToken: string | undefined) {
  if (!rawToken) return null;
  const db = await getDb();
  if (!db) return null;
  const rows = await db.select({ user: users }).from(localSessions)
    .innerJoin(users, eq(users.id, localSessions.userId))
    .where(and(eq(localSessions.tokenHash, hashSessionToken(rawToken)), isNull(localSessions.revokedAt), gt(localSessions.expiresAt, new Date())))
    .limit(1);
  const user = rows[0]?.user ?? null;
  return user?.isBlocked ? null : user;
}

export async function revokeLocalSession(rawToken: string | undefined) {
  if (!rawToken) return;
  const db = await getDb();
  if (!db) return;
  await db.update(localSessions).set({ revokedAt: new Date() })
    .where(and(eq(localSessions.tokenHash, hashSessionToken(rawToken)), isNull(localSessions.revokedAt)));
}

export async function revokeAllLocalSessions(userId: number, dbOverride?: Awaited<ReturnType<typeof getDb>>) {
  const db = dbOverride ?? await getDb();
  if (!db) throw new Error("Database is not available");
  await db.update(localSessions).set({ revokedAt: new Date() })
    .where(and(eq(localSessions.userId, userId), isNull(localSessions.revokedAt)));
}
