import { describe, expect, it } from "vitest";

const GOOGLE_TOKEN_ENDPOINT = "https://oauth2.googleapis.com/token";
const GOOGLE_REDIRECT_URI = "https://plxgaming-kov2vkkf.manus.space/api/auth/google/callback";

describe("Google OAuth server configuration", () => {
  it("accepts the configured confidential client before rejecting a deliberately invalid authorization code", async () => {
    const clientId = process.env.GOOGLE_OAUTH_CLIENT_ID;
    const clientSecret = process.env.GOOGLE_OAUTH_CLIENT_SECRET;

    expect(clientId).toBeTruthy();
    expect(clientSecret).toBeTruthy();

    const body = new URLSearchParams({
      client_id: clientId!,
      client_secret: clientSecret!,
      code: "plx-google-oauth-credential-validation",
      grant_type: "authorization_code",
      redirect_uri: GOOGLE_REDIRECT_URI,
    });
    const response = await fetch(GOOGLE_TOKEN_ENDPOINT, {
      method: "POST",
      headers: { "content-type": "application/x-www-form-urlencoded" },
      body,
      signal: AbortSignal.timeout(15_000),
    });
    const result = await response.json() as { error?: string };

    expect(response.status).toBe(400);
    // Google validates the registered client before rejecting our intentionally
    // unusable authorization code. Do not log response payloads or secrets.
    expect(result.error).toBe("invalid_grant");
  });
});
