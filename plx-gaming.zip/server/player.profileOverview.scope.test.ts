import { beforeEach, describe, expect, it, vi } from "vitest";
import type { TrpcContext } from "./_core/context";

const platformMocks = vi.hoisted(() => ({ databaseOrThrow: vi.fn(), requireActiveAccount: vi.fn() }));
const dbMocks = vi.hoisted(() => ({ ensureWallet: vi.fn() }));
vi.mock("./platform", async (importOriginal) => ({ ...(await importOriginal<typeof import("./platform")>()), ...platformMocks }));
vi.mock("./db", async (importOriginal) => ({ ...(await importOriginal<typeof import("./db")>()), ...dbMocks }));

import { appRouter } from "./routers";

function playerContext(): TrpcContext {
  return { user: { id: 7, openId: "player-7", name: "Private Player", email: "private@plx.test", loginMethod: "email", role: "user", isBlocked: false, playerName: "Private Player", gameUid: "123456789012", avatarUrl: null, createdAt: new Date("2026-01-01"), updatedAt: new Date(), lastSignedIn: new Date() }, req: {} as TrpcContext["req"], res: {} as TrpcContext["res"] };
}

function walletQuery() { return { from: vi.fn().mockReturnValue({ where: vi.fn().mockReturnValue({ limit: vi.fn().mockResolvedValue([{ balance: 75 }]) }) }) }; }
function entriesQuery() { return { from: vi.fn().mockReturnValue({ innerJoin: vi.fn().mockReturnValue({ where: vi.fn().mockReturnValue({ orderBy: vi.fn().mockResolvedValue([]) }) }) }) }; }
function transactionsQuery() { return { from: vi.fn().mockReturnValue({ where: vi.fn().mockReturnValue({ orderBy: vi.fn().mockResolvedValue([]) }) }) }; }

describe("player.profileOverview account scope", () => {
  beforeEach(() => {
    vi.clearAllMocks();
    platformMocks.requireActiveAccount.mockResolvedValue({ id: 7, name: "Private Player", playerName: "Private Player", gameUid: "123456789012", avatarUrl: null, createdAt: new Date("2026-01-01") });
    dbMocks.ensureWallet.mockResolvedValue(undefined);
    platformMocks.databaseOrThrow.mockResolvedValue({ select: vi.fn().mockReturnValueOnce(walletQuery()).mockReturnValueOnce(entriesQuery()).mockReturnValueOnce(transactionsQuery()) });
  });

  it("anchors private profile data to ctx.user.id even when untrusted caller input suggests another player", async () => {
    const caller = appRouter.createCaller(playerContext());
    const profile = await (caller.player.profileOverview as (input?: unknown) => Promise<any>)({ userId: 99 });
    expect(platformMocks.requireActiveAccount).toHaveBeenCalledWith(7);
    expect(profile.profile).toMatchObject({ id: 7, playerId: "PLX-000007", playerName: "Private Player" });
    expect(profile.profile).not.toHaveProperty("email");
  });
});
