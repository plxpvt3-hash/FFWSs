import { TRPCError } from "@trpc/server";
import { and, asc, desc, eq, inArray, like, or, sql } from "drizzle-orm";
import { z } from "zod";
import {
  announcements,
  creditPackages,
  paymentRequests,
  platformSettings,
  socialProfiles,
  tournamentEntries,
  tournaments,
  users,
  wallets,
  walletTransactions,
  withdrawalRequests,
  withdrawalStatusHistory,
} from "../../drizzle/schema";
import { databaseOrThrow, getSettingsMap, requireActiveAdmin, saveImageDataUrl, writeAdminActivity } from "../platform";
import { assertPaymentIsPending, assertWithdrawalTransition, creditPackageRemovalAction, withdrawalStatuses } from "../security";
import { assertCreditsAmount, assertTournamentCapacity, createSlug, freeFireUidSchema, playerNicknameSchema } from "../validation";
import { calculateProfileStats } from "../profileMetrics";
import { isSafeHomeFooterDestination } from "../homeSettings";
import { adminProcedure, router } from "../_core/trpc";

const tournamentInput = z.object({
  id: z.number().int().positive().optional(),
  name: z.string().trim().min(3).max(128),
  bannerDataUrl: z.string().min(30).max(6_000_000).optional(),
  game: z.string().trim().min(2).max(64),
  mode: z.enum(["solo", "duo", "squad"]),
  map: z.string().trim().min(2).max(64),
  startsAt: z.coerce.date(),
  entryFee: z.number().int().min(0).max(100000),
  prizePool: z.number().int().min(0).max(10000000),
  totalSlots: z.number().int().min(1).max(10000),
  registrationOpen: z.boolean(),
  matchId: z.string().trim().max(128).optional(),
  rules: z.string().trim().max(8000).optional(),
  instructions: z.string().trim().max(8000).optional(),
  roomId: z.string().trim().max(128).optional(),
  roomPassword: z.string().trim().max(128).optional(),
  roomCredentialsPublished: z.boolean(),
  status: z.enum(["draft", "upcoming", "live", "completed", "closed"]),
});

const socialProfileInput = z.object({
  id: z.number().int().positive().optional(),
  platform: z.enum(["instagram", "telegram", "youtube", "whatsapp", "facebook", "discord", "twitter"]),
  handle: z.string().trim().min(1, "A username or handle is required.").max(128),
  profileUrl: z.string().trim().url("Enter a full valid profile URL.").max(2048)
    .refine((value) => {
      const protocol = new URL(value).protocol;
      return protocol === "https:" || protocol === "http:";
    }, "Use an official http or https profile URL."),
  isEnabled: z.boolean(),
  sortOrder: z.number().int().min(0).max(1000),
});

const footerDestinationSchema = z.string().trim().min(1).max(2048)
  .refine(isSafeHomeFooterDestination, "Use an internal path beginning with / or a valid http(s) URL.");

async function setPlatformSetting(key: string, value: string, adminId: number) {
  const db = await databaseOrThrow();
  await db.insert(platformSettings).values({ settingKey: key, settingValue: value, updatedBy: adminId })
    .onDuplicateKeyUpdate({ set: { settingValue: value, updatedBy: adminId } });
}

export const adminRouter = router({
  overview: adminProcedure.query(async ({ ctx }) => {
    await requireActiveAdmin(ctx.user.id);
    const db = await databaseOrThrow();
    const [userRows, pendingRows, activeRows, payments, pendingWithdrawals] = await Promise.all([
      db.select({ total: sql<number>`count(*)` }).from(users),
      db.select({ total: sql<number>`count(*)` }).from(paymentRequests).where(eq(paymentRequests.status, "pending")),
      db.select({ total: sql<number>`count(*)` }).from(tournaments).where(and(eq(tournaments.status, "upcoming"), sql`${tournaments.startsAt} >= NOW()`)),
      db.select({ total: sql<number>`COALESCE(SUM(${paymentRequests.amountPaid}), 0)` }).from(paymentRequests).where(eq(paymentRequests.status, "approved")),
      db.select({ total: sql<number>`count(*)` }).from(withdrawalRequests).where(eq(withdrawalRequests.status, "pending")),
    ]);
    return {
      totalUsers: Number(userRows[0]?.total ?? 0),
      pendingPayments: Number(pendingRows[0]?.total ?? 0),
      activeTournaments: Number(activeRows[0]?.total ?? 0),
      approvedRevenue: Number(payments[0]?.total ?? 0),
      pendingWithdrawals: Number(pendingWithdrawals[0]?.total ?? 0),
    };
  }),

  users: adminProcedure.query(async ({ ctx }) => {
    await requireActiveAdmin(ctx.user.id);
    const db = await databaseOrThrow();
    return db.select({ account: users, balance: wallets.balance, winningBalance: wallets.winningBalance, bonusBalance: wallets.bonusBalance }).from(users)
      .leftJoin(wallets, eq(wallets.userId, users.id)).orderBy(desc(users.createdAt));
  }),

  playerProfile: adminProcedure.input(z.object({ userId: z.number().int().positive() })).query(async ({ ctx, input }) => {
    await requireActiveAdmin(ctx.user.id);
    const db = await databaseOrThrow();
    const [accountRows, walletRows, entries] = await Promise.all([
      db.select({ id: users.id, name: users.name, playerName: users.playerName, gameUid: users.gameUid, avatarUrl: users.avatarUrl, isBlocked: users.isBlocked, createdAt: users.createdAt, role: users.role }).from(users).where(eq(users.id, input.userId)).limit(1),
      db.select({ balance: wallets.balance, winningBalance: wallets.winningBalance, bonusBalance: wallets.bonusBalance }).from(wallets).where(eq(wallets.userId, input.userId)).limit(1),
      db.select({ entry: tournamentEntries, tournament: tournaments }).from(tournamentEntries).innerJoin(tournaments, eq(tournaments.id, tournamentEntries.tournamentId)).where(eq(tournamentEntries.userId, input.userId)).orderBy(desc(tournamentEntries.joinedAt)),
    ]);
    const account = accountRows[0];
    if (!account) throw new TRPCError({ code: "NOT_FOUND", message: "Player account not found." });
    const stats = calculateProfileStats(entries);
    return {
      account,
      balance: walletRows[0]?.balance ?? 0,
      winningBalance: walletRows[0]?.winningBalance ?? 0,
      bonusBalance: walletRows[0]?.bonusBalance ?? 0,
      stats,
      entries,
    };
  }),

  setUserBlocked: adminProcedure
    .input(z.object({ userId: z.number().int().positive(), isBlocked: z.boolean() }))
    .mutation(async ({ ctx, input }) => {
      const admin = await requireActiveAdmin(ctx.user.id);
      if (input.userId === admin.id) throw new TRPCError({ code: "BAD_REQUEST", message: "You cannot change your own access status." });
      const db = await databaseOrThrow();
      await db.update(users).set({ isBlocked: input.isBlocked }).where(eq(users.id, input.userId));
      await writeAdminActivity({ actorId: admin.id, action: input.isBlocked ? "user.blocked" : "user.unblocked", targetType: "user", targetId: String(input.userId) });
      return { success: true };
    }),

  adjustCredits: adminProcedure
    .input(z.object({ userId: z.number().int().positive(), amount: z.number().int().min(-1000000).max(1000000), note: z.string().trim().min(3).max(200) }))
    .mutation(async ({ ctx, input }) => {
      const admin = await requireActiveAdmin(ctx.user.id);
      assertCreditsAmount(input.amount);
      const db = await databaseOrThrow();
      return db.transaction(async (tx) => {
        const [adjustment] = await tx.update(wallets).set({ balance: sql`${wallets.balance} + ${input.amount}` })
          .where(input.amount < 0
            ? and(eq(wallets.userId, input.userId), sql`${wallets.balance} >= ${Math.abs(input.amount)}`)
            : eq(wallets.userId, input.userId));
        if (!adjustment.affectedRows) throw new TRPCError({ code: "BAD_REQUEST", message: "The account does not have enough Credits for that deduction." });
        const [wallet] = await tx.select().from(wallets).where(eq(wallets.userId, input.userId)).limit(1);
        if (!wallet) throw new TRPCError({ code: "NOT_FOUND", message: "Wallet not found." });
        await tx.insert(walletTransactions).values({
          userId: input.userId,
          direction: input.amount > 0 ? "credit" : "debit",
          balanceCategory: "credits",
          type: "admin_adjustment",
          amount: Math.abs(input.amount),
          balanceAfter: wallet.balance,
          referenceType: "admin_adjustment",
          referenceId: String(admin.id),
          note: input.note,
        });
        return { balance: wallet.balance };
      }).then(async (result) => {
        await writeAdminActivity({ actorId: admin.id, action: "wallet.adjusted", targetType: "user", targetId: String(input.userId), details: JSON.stringify({ amount: input.amount, note: input.note }) });
        return result;
      });
    }),

  tournaments: adminProcedure.query(async ({ ctx }) => {
    await requireActiveAdmin(ctx.user.id);
    const db = await databaseOrThrow();
    return db.select().from(tournaments).orderBy(desc(tournaments.createdAt));
  }),

  participants: adminProcedure.input(z.object({
    search: z.string().trim().max(80).optional(),
    tournamentId: z.number().int().positive().optional(),
    status: z.enum(["registered", "withdrawn", "disqualified"]).optional(),
  }).optional()).query(async ({ ctx, input }) => {
    await requireActiveAdmin(ctx.user.id);
    const db = await databaseOrThrow();
    const filters = [];
    if (input?.tournamentId) filters.push(eq(tournamentEntries.tournamentId, input.tournamentId));
    if (input?.status) filters.push(eq(tournamentEntries.status, input.status));
    if (input?.search) {
      const term = `%${input.search}%`;
      filters.push(or(
        like(tournamentEntries.playerNickname, term),
        like(tournamentEntries.playerUid, term),
        like(users.playerName, term),
        like(users.name, term),
        like(tournaments.name, term),
        sql`CAST(${tournamentEntries.userId} AS CHAR) LIKE ${term}`,
      ));
    }
    return db.select({
      entry: tournamentEntries,
      tournamentName: tournaments.name,
      tournamentMode: tournaments.mode,
      tournamentEntryFee: tournaments.entryFee,
      accountName: users.name,
      accountNickname: users.playerName,
      accountUid: users.gameUid,
    }).from(tournamentEntries)
      .innerJoin(tournaments, eq(tournaments.id, tournamentEntries.tournamentId))
      .innerJoin(users, eq(users.id, tournamentEntries.userId))
      .where(filters.length ? and(...filters) : undefined)
      .orderBy(desc(tournamentEntries.joinedAt));
  }),

  updateParticipantIdentity: adminProcedure.input(z.object({
    entryId: z.number().int().positive(),
    playerNickname: playerNicknameSchema,
    playerUid: freeFireUidSchema,
  })).mutation(async ({ ctx, input }) => {
    const admin = await requireActiveAdmin(ctx.user.id);
    const db = await databaseOrThrow();
    const [entry] = await db.select({ id: tournamentEntries.id, tournamentId: tournamentEntries.tournamentId })
      .from(tournamentEntries).where(eq(tournamentEntries.id, input.entryId)).limit(1);
    if (!entry) throw new TRPCError({ code: "NOT_FOUND", message: "Tournament participant not found." });
    try {
      await db.update(tournamentEntries).set({ playerNickname: input.playerNickname, playerUid: input.playerUid })
        .where(eq(tournamentEntries.id, entry.id));
    } catch (error: any) {
      if (error?.code === "ER_DUP_ENTRY") throw new TRPCError({ code: "CONFLICT", message: "This Free Fire UID is already registered for that tournament." });
      throw error;
    }
    await writeAdminActivity({ actorId: admin.id, action: "tournament_entry.identity_updated", targetType: "tournament_entry", targetId: String(entry.id), details: JSON.stringify({ tournamentId: entry.tournamentId, playerUid: input.playerUid }) });
    return { success: true };
  }),

  saveTournament: adminProcedure.input(tournamentInput).mutation(async ({ ctx, input }) => {
    const admin = await requireActiveAdmin(ctx.user.id);
    const db = await databaseOrThrow();
    const { bannerDataUrl, id, ...tournamentValues } = input;
    const bannerUpload = bannerDataUrl ? await saveImageDataUrl(bannerDataUrl, "platform", admin.id) : null;
    if (input.id) {
      const [existing] = await db.select().from(tournaments).where(eq(tournaments.id, input.id)).limit(1);
      if (!existing) throw new TRPCError({ code: "NOT_FOUND", message: "Tournament not found." });
      assertTournamentCapacity(input.totalSlots, existing.filledSlots);
      await db.update(tournaments).set({ ...tournamentValues, bannerUrl: bannerUpload?.url ?? existing.bannerUrl }).where(eq(tournaments.id, existing.id));
      await writeAdminActivity({ actorId: admin.id, action: "tournament.updated", targetType: "tournament", targetId: String(existing.id), details: JSON.stringify({ registrationOpen: input.registrationOpen, roomCredentialsPublished: input.roomCredentialsPublished }) });
      return { id: existing.id, slug: existing.slug };
    }

    const slug = createSlug(input.name);
    const [created] = await db.insert(tournaments).values({ ...tournamentValues, bannerUrl: bannerUpload?.url, slug, createdBy: admin.id });
    await writeAdminActivity({ actorId: admin.id, action: "tournament.created", targetType: "tournament", targetId: String(created.insertId), details: JSON.stringify({ registrationOpen: input.registrationOpen }) });
    return { id: created.insertId, slug };
  }),

  cancelTournament: adminProcedure.input(z.object({ tournamentId: z.number().int().positive(), note: z.string().trim().max(240).optional() }))
    .mutation(async ({ ctx, input }) => {
      const admin = await requireActiveAdmin(ctx.user.id);
      const db = await databaseOrThrow();
      await db.transaction(async (tx) => {
        const [tournament] = await tx.select().from(tournaments).where(eq(tournaments.id, input.tournamentId)).limit(1);
        if (!tournament || tournament.status === "cancelled") throw new TRPCError({ code: "BAD_REQUEST", message: "This tournament cannot be cancelled." });
        await tx.update(tournaments).set({ status: "cancelled", filledSlots: 0 }).where(eq(tournaments.id, tournament.id));
        const entries = await tx.select().from(tournamentEntries).where(and(eq(tournamentEntries.tournamentId, tournament.id), eq(tournamentEntries.status, "registered")));
        for (const entry of entries) {
          await tx.update(tournamentEntries).set({ status: "withdrawn" }).where(eq(tournamentEntries.id, entry.id));
          if (tournament.entryFee > 0) {
            await tx.update(wallets).set({ balance: sql`${wallets.balance} + ${tournament.entryFee}` }).where(eq(wallets.userId, entry.userId));
            const [wallet] = await tx.select().from(wallets).where(eq(wallets.userId, entry.userId)).limit(1);
            if (wallet) {
              await tx.insert(walletTransactions).values({
                userId: entry.userId, direction: "credit", balanceCategory: "credits", type: "refund", amount: tournament.entryFee,
                balanceAfter: wallet.balance, referenceType: "tournament", referenceId: String(tournament.id),
                note: `Refund for cancelled ${tournament.name}`,
              });
            }
          }
        }
      });
      await writeAdminActivity({ actorId: admin.id, action: "tournament.cancelled", targetType: "tournament", targetId: String(input.tournamentId), details: input.note ?? null });
      return { success: true };
    }),

  deleteTournament: adminProcedure.input(z.object({ tournamentId: z.number().int().positive() })).mutation(async ({ ctx, input }) => {
    const admin = await requireActiveAdmin(ctx.user.id);
    const db = await databaseOrThrow();
    const [tournament] = await db.select().from(tournaments).where(eq(tournaments.id, input.tournamentId)).limit(1);
    if (!tournament || tournament.filledSlots > 0) throw new TRPCError({ code: "BAD_REQUEST", message: "Only an empty tournament can be permanently deleted." });
    await db.delete(tournaments).where(eq(tournaments.id, tournament.id));
    await writeAdminActivity({ actorId: admin.id, action: "tournament.deleted", targetType: "tournament", targetId: String(tournament.id) });
    return { success: true };
  }),

  payments: adminProcedure.query(async ({ ctx }) => {
    await requireActiveAdmin(ctx.user.id);
    const db = await databaseOrThrow();
    return db.select({
      request: paymentRequests,
      packageName: creditPackages.name,
      playerName: users.playerName,
      accountName: users.name,
      email: users.email,
    }).from(paymentRequests)
      .innerJoin(creditPackages, eq(creditPackages.id, paymentRequests.packageId))
      .innerJoin(users, eq(users.id, paymentRequests.userId))
      .orderBy(desc(paymentRequests.createdAt));
  }),

  reviewPayment: adminProcedure
    .input(z.object({ requestId: z.number().int().positive(), decision: z.enum(["approved", "rejected"]), reviewNote: z.string().trim().max(240).optional() }))
    .mutation(async ({ ctx, input }) => {
      const admin = await requireActiveAdmin(ctx.user.id);
      const db = await databaseOrThrow();
      await db.transaction(async (tx) => {
        const [request] = await tx.select().from(paymentRequests).where(eq(paymentRequests.id, input.requestId)).limit(1);
        if (!request) throw new TRPCError({ code: "CONFLICT", message: "This payment request has already been reviewed." });
        assertPaymentIsPending(request.status);
        const [review] = await tx.update(paymentRequests).set({ status: input.decision, reviewNote: input.reviewNote ?? null, reviewedBy: admin.id, reviewedAt: new Date() })
          .where(and(eq(paymentRequests.id, request.id), eq(paymentRequests.status, "pending")));
        if (!review.affectedRows) throw new TRPCError({ code: "CONFLICT", message: "This payment request has already been reviewed." });
        if (input.decision === "approved") {
          await tx.update(wallets).set({ balance: sql`${wallets.balance} + ${request.creditsRequested}` }).where(eq(wallets.userId, request.userId));
          const [wallet] = await tx.select().from(wallets).where(eq(wallets.userId, request.userId)).limit(1);
          if (!wallet) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Wallet not found for the payment request." });
          await tx.insert(walletTransactions).values({
            userId: request.userId, direction: "credit", balanceCategory: "credits", type: "credit_purchase", amount: request.creditsRequested,
            balanceAfter: wallet.balance, referenceType: "payment_request", referenceId: String(request.id),
            note: `UPI payment approved · ${request.utr}`,
          });
        }
      });
      await writeAdminActivity({ actorId: admin.id, action: `payment.${input.decision}`, targetType: "payment_request", targetId: String(input.requestId), details: input.reviewNote ?? null });
      return { success: true };
    }),

  withdrawals: adminProcedure.input(z.object({ status: z.enum(withdrawalStatuses).optional() }).optional()).query(async ({ ctx, input }) => {
    await requireActiveAdmin(ctx.user.id);
    const db = await databaseOrThrow();
    return db.select({
      request: withdrawalRequests,
      playerId: users.id,
      playerName: users.playerName,
      accountName: users.name,
      email: users.email,
    }).from(withdrawalRequests)
      .innerJoin(users, eq(users.id, withdrawalRequests.userId))
      .where(input?.status ? eq(withdrawalRequests.status, input.status) : undefined)
      .orderBy(desc(withdrawalRequests.createdAt));
  }),

  withdrawalAudit: adminProcedure.input(z.object({ withdrawalId: z.number().int().positive().optional() }).optional()).query(async ({ ctx, input }) => {
    await requireActiveAdmin(ctx.user.id);
    const db = await databaseOrThrow();
    return db.select({
      history: withdrawalStatusHistory,
      withdrawalCode: withdrawalRequests.withdrawalCode,
      amount: withdrawalRequests.amount,
      playerId: withdrawalRequests.userId,
      playerName: users.playerName,
      accountName: users.name,
    }).from(withdrawalStatusHistory)
      .innerJoin(withdrawalRequests, eq(withdrawalRequests.id, withdrawalStatusHistory.withdrawalRequestId))
      .innerJoin(users, eq(users.id, withdrawalRequests.userId))
      .where(input?.withdrawalId ? eq(withdrawalStatusHistory.withdrawalRequestId, input.withdrawalId) : undefined)
      .orderBy(desc(withdrawalStatusHistory.createdAt)).limit(200);
  }),

  reviewWithdrawal: adminProcedure.input(z.object({
    withdrawalId: z.number().int().positive(),
    action: z.enum(["approve", "start_processing", "mark_paid", "reject"]),
    rejectionReason: z.string().trim().min(3).max(240).optional(),
  })).mutation(async ({ ctx, input }) => {
    const admin = await requireActiveAdmin(ctx.user.id);
    const db = await databaseOrThrow();
    const nextStatus: (typeof withdrawalStatuses)[number] = input.action === "approve" ? "approved"
      : input.action === "start_processing" ? "processing"
        : input.action === "mark_paid" ? "paid" : "rejected";
    if (input.action === "reject" && !input.rejectionReason) {
      throw new TRPCError({ code: "BAD_REQUEST", message: "Add a short rejection reason for the player." });
    }

    await db.transaction(async (tx) => {
      const [request] = await tx.select().from(withdrawalRequests).where(eq(withdrawalRequests.id, input.withdrawalId)).limit(1);
      if (!request) throw new TRPCError({ code: "NOT_FOUND", message: "Withdrawal request not found." });
      assertWithdrawalTransition(request.status, nextStatus);
      const now = new Date();
      const lifecycleValues = nextStatus === "approved"
        ? { status: nextStatus, approvedBy: admin.id, approvedAt: now }
        : nextStatus === "processing"
          ? { status: nextStatus, processingBy: admin.id, processingAt: now }
          : nextStatus === "paid"
            ? { status: nextStatus, paidBy: admin.id, paidAt: now, activeUserKey: null }
            : { status: nextStatus, rejectionReason: input.rejectionReason!, activeUserKey: null };
      const [transition] = await tx.update(withdrawalRequests).set(lifecycleValues)
        .where(and(eq(withdrawalRequests.id, request.id), eq(withdrawalRequests.status, request.status)));
      if (!transition.affectedRows) throw new TRPCError({ code: "CONFLICT", message: "This withdrawal was changed by another administrator. Refresh and try again." });

      if (nextStatus === "rejected") {
        await tx.update(wallets).set({ winningBalance: sql`${wallets.winningBalance} + ${request.amount}` }).where(eq(wallets.userId, request.userId));
        const [wallet] = await tx.select().from(wallets).where(eq(wallets.userId, request.userId)).limit(1);
        if (!wallet) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "The player wallet is unavailable." });
        await tx.insert(walletTransactions).values({
          userId: request.userId,
          direction: "credit",
          balanceCategory: "winning",
          type: "withdrawal_reversal",
          amount: request.amount,
          balanceAfter: wallet.winningBalance,
          referenceType: "withdrawal",
          referenceId: String(request.id),
          note: `Withdrawal ${request.withdrawalCode} rejected: ${input.rejectionReason}`,
        });
      }

      await tx.insert(withdrawalStatusHistory).values({
        withdrawalRequestId: request.id,
        status: nextStatus,
        actorType: "admin",
        actorId: admin.id,
        note: nextStatus === "rejected" ? input.rejectionReason! : `Status changed to ${nextStatus}.`,
      });
    });
    await writeAdminActivity({
      actorId: admin.id,
      action: `withdrawal.${nextStatus}`,
      targetType: "withdrawal_request",
      targetId: String(input.withdrawalId),
      details: input.rejectionReason ?? null,
    });
    return { success: true, status: nextStatus };
  }),

  saveWithdrawalSettings: adminProcedure.input(z.object({ minimumWithdrawal: z.number().int().min(1).max(1_000_000) }))
    .mutation(async ({ ctx, input }) => {
      const admin = await requireActiveAdmin(ctx.user.id);
      await setPlatformSetting("withdrawalMinimum", String(input.minimumWithdrawal), admin.id);
      await writeAdminActivity({ actorId: admin.id, action: "withdrawal.minimum_updated", targetType: "platform_setting", targetId: "withdrawalMinimum", details: JSON.stringify({ minimumWithdrawal: input.minimumWithdrawal }) });
      return { success: true, minimumWithdrawal: input.minimumWithdrawal };
    }),

  results: adminProcedure.input(z.object({ tournamentId: z.number().int().positive() })).query(async ({ ctx, input }) => {
    await requireActiveAdmin(ctx.user.id);
    const db = await databaseOrThrow();
    return db.select({ entry: tournamentEntries, playerName: users.playerName, accountName: users.name }).from(tournamentEntries)
      .innerJoin(users, eq(users.id, tournamentEntries.userId))
      .where(eq(tournamentEntries.tournamentId, input.tournamentId)).orderBy(asc(tournamentEntries.rank));
  }),

  saveResult: adminProcedure
    .input(z.object({ entryId: z.number().int().positive(), rank: z.number().int().positive().optional(), kills: z.number().int().min(0).max(1000), score: z.number().int().min(0).max(100000), prizeAwarded: z.number().int().min(0).max(10000000) }))
    .mutation(async ({ ctx, input }) => {
      const admin = await requireActiveAdmin(ctx.user.id);
      const db = await databaseOrThrow();
      await db.update(tournamentEntries).set(input).where(eq(tournamentEntries.id, input.entryId));
      await writeAdminActivity({ actorId: admin.id, action: "result.saved", targetType: "tournament_entry", targetId: String(input.entryId) });
      return { success: true };
    }),

  publishResults: adminProcedure.input(z.object({ tournamentId: z.number().int().positive() })).mutation(async ({ ctx, input }) => {
    const admin = await requireActiveAdmin(ctx.user.id);
    const db = await databaseOrThrow();
    await db.transaction(async (tx) => {
      const [tournament] = await tx.select().from(tournaments).where(eq(tournaments.id, input.tournamentId)).limit(1);
      if (!tournament || tournament.status !== "completed") throw new TRPCError({ code: "BAD_REQUEST", message: "Only completed tournaments can publish results." });
      const winners = await tx.select().from(tournamentEntries).where(and(eq(tournamentEntries.tournamentId, tournament.id), eq(tournamentEntries.status, "registered")));
      for (const entry of winners) {
        if (!entry.prizeAwarded || entry.prizeCredited) continue;
        const [markAwarded] = await tx.update(tournamentEntries).set({ prizeCredited: true })
          .where(and(eq(tournamentEntries.id, entry.id), eq(tournamentEntries.prizeCredited, false)));
        if (!markAwarded.affectedRows) continue;
        await tx.update(wallets).set({ winningBalance: sql`${wallets.winningBalance} + ${entry.prizeAwarded}` }).where(eq(wallets.userId, entry.userId));
        const [wallet] = await tx.select().from(wallets).where(eq(wallets.userId, entry.userId)).limit(1);
        if (wallet) await tx.insert(walletTransactions).values({
          userId: entry.userId, direction: "credit", balanceCategory: "winning", type: "prize_winning", amount: entry.prizeAwarded,
          balanceAfter: wallet.winningBalance, referenceType: "tournament", referenceId: String(tournament.id), note: `Winnings from ${tournament.name}`,
        });
      }
      await tx.update(tournaments).set({ resultPublished: true }).where(eq(tournaments.id, tournament.id));
    });
    await writeAdminActivity({ actorId: admin.id, action: "results.published", targetType: "tournament", targetId: String(input.tournamentId) });
    return { success: true };
  }),

  creditPackages: adminProcedure.query(async ({ ctx }) => {
    await requireActiveAdmin(ctx.user.id);
    const db = await databaseOrThrow();
    return db.select().from(creditPackages).orderBy(asc(creditPackages.sortOrder));
  }),

  saveCreditPackage: adminProcedure
    .input(z.object({ id: z.number().int().positive().optional(), name: z.string().trim().min(2).max(80), credits: z.number().int().positive(), priceInr: z.number().int().positive(), isActive: z.boolean(), sortOrder: z.number().int().min(0).max(1000) }))
    .mutation(async ({ ctx, input }) => {
      const admin = await requireActiveAdmin(ctx.user.id);
      const db = await databaseOrThrow();
      if (input.id) await db.update(creditPackages).set(input).where(eq(creditPackages.id, input.id));
      else await db.insert(creditPackages).values(input);
      await writeAdminActivity({ actorId: admin.id, action: input.id ? "credit_package.updated" : "credit_package.created", targetType: "credit_package", targetId: input.id ? String(input.id) : null });
      return { success: true };
    }),

  removeCreditPackage: adminProcedure
    .input(z.object({ id: z.number().int().positive() }))
    .mutation(async ({ ctx, input }) => {
      const admin = await requireActiveAdmin(ctx.user.id);
      const db = await databaseOrThrow();
      const [packageToRemove, referencedRequest] = await Promise.all([
        db.select({ id: creditPackages.id }).from(creditPackages).where(eq(creditPackages.id, input.id)).limit(1),
        db.select({ id: paymentRequests.id }).from(paymentRequests).where(eq(paymentRequests.packageId, input.id)).limit(1),
      ]);
      if (!packageToRemove[0]) throw new Error("Credit package not found.");

      const action = creditPackageRemovalAction(Boolean(referencedRequest[0]));
      if (action === "archive") {
        await db.update(creditPackages).set({ isActive: false }).where(eq(creditPackages.id, input.id));
      } else {
        await db.delete(creditPackages).where(eq(creditPackages.id, input.id));
      }
      await writeAdminActivity({
        actorId: admin.id,
        action: action === "archive" ? "credit_package.archived" : "credit_package.removed",
        targetType: "credit_package",
        targetId: String(input.id),
      });
      return { success: true, archived: action === "archive" };
    }),

  socialProfiles: adminProcedure.query(async ({ ctx }) => {
    await requireActiveAdmin(ctx.user.id);
    const db = await databaseOrThrow();
    return db.select().from(socialProfiles).orderBy(asc(socialProfiles.sortOrder), asc(socialProfiles.id));
  }),

  saveSocialProfile: adminProcedure.input(socialProfileInput).mutation(async ({ ctx, input }) => {
    const admin = await requireActiveAdmin(ctx.user.id);
    const db = await databaseOrThrow();
    const { id, ...values } = input;
    try {
      if (id) {
        const [existing] = await db.select({ id: socialProfiles.id }).from(socialProfiles).where(eq(socialProfiles.id, id)).limit(1);
        if (!existing) throw new TRPCError({ code: "NOT_FOUND", message: "Social profile not found." });
        await db.update(socialProfiles).set(values).where(eq(socialProfiles.id, id));
      } else {
        await db.insert(socialProfiles).values(values);
      }
    } catch (error: any) {
      if (error?.code === "ER_DUP_ENTRY") throw new TRPCError({ code: "CONFLICT", message: "That platform already has a configured PLX profile. Edit the existing profile instead." });
      throw error;
    }
    await writeAdminActivity({ actorId: admin.id, action: id ? "social_profile.updated" : "social_profile.created", targetType: "social_profile", targetId: id ? String(id) : null, details: JSON.stringify({ platform: input.platform, enabled: input.isEnabled, sortOrder: input.sortOrder }) });
    return { success: true };
  }),

  removeSocialProfile: adminProcedure.input(z.object({ id: z.number().int().positive() })).mutation(async ({ ctx, input }) => {
    const admin = await requireActiveAdmin(ctx.user.id);
    const db = await databaseOrThrow();
    const [removed] = await db.delete(socialProfiles).where(eq(socialProfiles.id, input.id));
    if (!removed.affectedRows) throw new TRPCError({ code: "NOT_FOUND", message: "Social profile not found." });
    await writeAdminActivity({ actorId: admin.id, action: "social_profile.removed", targetType: "social_profile", targetId: String(input.id) });
    return { success: true };
  }),

  settings: adminProcedure.query(async ({ ctx }) => {
    await requireActiveAdmin(ctx.user.id);
    return getSettingsMap();
  }),

  saveSettings: adminProcedure
    .input(z.object({
      upiId: z.string().trim().max(160), paymentInstructions: z.string().trim().max(1000), supportEmail: z.string().trim().max(320), supportMessage: z.string().trim().max(1000), rules: z.string().trim().max(8000), qrCodeDataUrl: z.string().max(6_000_000).optional(), logoDataUrl: z.string().max(6_000_000).optional(),
      homeHeroTitle: z.string().trim().min(3).max(120).optional(), homeHeroDescription: z.string().trim().min(20).max(420).optional(), homeHeroDataUrl: z.string().max(6_000_000).optional(), homeFeaturedTournamentIds: z.array(z.number().int().positive()).max(3).optional(), homeLiveTournamentId: z.number().int().positive().nullable().optional(), homeStatsEnabled: z.boolean().optional(),
      footerTournamentsUrl: footerDestinationSchema.optional(), footerLeaderboardUrl: footerDestinationSchema.optional(), footerWalletUrl: footerDestinationSchema.optional(), footerProfileUrl: footerDestinationSchema.optional(), footerTermsUrl: footerDestinationSchema.optional(), footerPrivacyUrl: footerDestinationSchema.optional(), footerSupportUrl: footerDestinationSchema.optional(),
    }))
    .mutation(async ({ ctx, input }) => {
      const admin = await requireActiveAdmin(ctx.user.id);
      const db = await databaseOrThrow();
      let qrCodeUrl: string | undefined;
      if (input.qrCodeDataUrl) qrCodeUrl = (await saveImageDataUrl(input.qrCodeDataUrl, "platform", admin.id)).url;
      let logoUrl: string | undefined;
      if (input.logoDataUrl) logoUrl = (await saveImageDataUrl(input.logoDataUrl, "platform", admin.id)).url;
      let homeHeroBannerUrl: string | undefined;
      if (input.homeHeroDataUrl) homeHeroBannerUrl = (await saveImageDataUrl(input.homeHeroDataUrl, "platform", admin.id)).url;
      if (input.homeFeaturedTournamentIds?.length) {
        const selected = await db.select({ id: tournaments.id }).from(tournaments).where(inArray(tournaments.id, input.homeFeaturedTournamentIds));
        if (selected.length !== input.homeFeaturedTournamentIds.length) throw new TRPCError({ code: "BAD_REQUEST", message: "Select only existing tournaments for the Home feature." });
      }
      if (input.homeLiveTournamentId) {
        const [liveTournament] = await db.select({ id: tournaments.id, status: tournaments.status }).from(tournaments).where(eq(tournaments.id, input.homeLiveTournamentId)).limit(1);
        if (!liveTournament || liveTournament.status !== "live") throw new TRPCError({ code: "BAD_REQUEST", message: "The selected Home live tournament must have Live status." });
      }
      await Promise.all([
        setPlatformSetting("upiId", input.upiId, admin.id),
        setPlatformSetting("paymentInstructions", input.paymentInstructions, admin.id),
        setPlatformSetting("supportEmail", input.supportEmail, admin.id),
        setPlatformSetting("supportMessage", input.supportMessage, admin.id),
        setPlatformSetting("rules", input.rules, admin.id),
        ...(qrCodeUrl ? [setPlatformSetting("qrCodeUrl", qrCodeUrl, admin.id)] : []),
        ...(logoUrl ? [setPlatformSetting("logoUrl", logoUrl, admin.id)] : []),
        ...(homeHeroBannerUrl ? [setPlatformSetting("homeHeroBannerUrl", homeHeroBannerUrl, admin.id)] : []),
        ...(input.homeHeroTitle !== undefined ? [setPlatformSetting("homeHeroTitle", input.homeHeroTitle, admin.id)] : []),
        ...(input.homeHeroDescription !== undefined ? [setPlatformSetting("homeHeroDescription", input.homeHeroDescription, admin.id)] : []),
        ...(input.homeFeaturedTournamentIds !== undefined ? [setPlatformSetting("homeFeaturedTournamentIds", JSON.stringify(input.homeFeaturedTournamentIds), admin.id)] : []),
        ...(input.homeLiveTournamentId !== undefined ? [setPlatformSetting("homeLiveTournamentId", input.homeLiveTournamentId ? String(input.homeLiveTournamentId) : "", admin.id)] : []),
        ...(input.homeStatsEnabled !== undefined ? [setPlatformSetting("homeStatsEnabled", String(input.homeStatsEnabled), admin.id)] : []),
        ...(input.footerTournamentsUrl !== undefined ? [setPlatformSetting("footerTournamentsUrl", input.footerTournamentsUrl, admin.id)] : []),
        ...(input.footerLeaderboardUrl !== undefined ? [setPlatformSetting("footerLeaderboardUrl", input.footerLeaderboardUrl, admin.id)] : []),
        ...(input.footerWalletUrl !== undefined ? [setPlatformSetting("footerWalletUrl", input.footerWalletUrl, admin.id)] : []),
        ...(input.footerProfileUrl !== undefined ? [setPlatformSetting("footerProfileUrl", input.footerProfileUrl, admin.id)] : []),
        ...(input.footerTermsUrl !== undefined ? [setPlatformSetting("footerTermsUrl", input.footerTermsUrl, admin.id)] : []),
        ...(input.footerPrivacyUrl !== undefined ? [setPlatformSetting("footerPrivacyUrl", input.footerPrivacyUrl, admin.id)] : []),
        ...(input.footerSupportUrl !== undefined ? [setPlatformSetting("footerSupportUrl", input.footerSupportUrl, admin.id)] : []),
      ]);
      await writeAdminActivity({ actorId: admin.id, action: "platform.settings_updated", targetType: "platform", targetId: "settings" });
      return { success: true };
    }),

  announcements: adminProcedure.query(async ({ ctx }) => {
    await requireActiveAdmin(ctx.user.id);
    const db = await databaseOrThrow();
    return db.select().from(announcements).orderBy(desc(announcements.createdAt));
  }),

  saveAnnouncement: adminProcedure
    .input(z.object({ id: z.number().int().positive().optional(), message: z.string().trim().min(3).max(280), isActive: z.boolean() }))
    .mutation(async ({ ctx, input }) => {
      const admin = await requireActiveAdmin(ctx.user.id);
      const db = await databaseOrThrow();
      if (input.id) await db.update(announcements).set(input).where(eq(announcements.id, input.id));
      else await db.insert(announcements).values({ ...input, createdBy: admin.id });
      await writeAdminActivity({ actorId: admin.id, action: input.id ? "announcement.updated" : "announcement.created", targetType: "announcement", targetId: input.id ? String(input.id) : null });
      return { success: true };
    }),
});
