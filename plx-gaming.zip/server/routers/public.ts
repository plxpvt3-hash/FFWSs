import { and, asc, desc, eq, inArray, sql } from "drizzle-orm";
import { z } from "zod";
import { announcements, socialProfiles, tournamentEntries, tournaments, users } from "../../drizzle/schema";
import { getSettingsMap, databaseOrThrow } from "../platform";
import { publicProcedure, router } from "../_core/trpc";

function presentTournament(tournament: typeof tournaments.$inferSelect) {
  return {
    ...tournament,
    remainingSlots: Math.max(0, tournament.totalSlots - tournament.filledSlots),
  };
}

async function presentTournamentsForViewer(rows: (typeof tournaments.$inferSelect)[], userId?: number) {
  const db = await databaseOrThrow();
  const joinedIds = new Set<number>();
  if (userId && rows.length) {
    const entries = await db.select({ tournamentId: tournamentEntries.tournamentId }).from(tournamentEntries)
      .where(and(eq(tournamentEntries.userId, userId), inArray(tournamentEntries.tournamentId, rows.map((row) => row.id))));
    entries.forEach((entry) => joinedIds.add(entry.tournamentId));
  }
  return rows.map((row) => ({ ...presentTournament(row), hasJoined: joinedIds.has(row.id) }));
}

function parseStoredTournamentIds(value?: string) {
  try {
    const parsed = JSON.parse(value ?? "[]");
    return Array.isArray(parsed) ? parsed.filter((id): id is number => Number.isInteger(id) && id > 0).slice(0, 3) : [];
  } catch {
    return [];
  }
}

function homeFooterLinks(settings: Record<string, string>) {
  return {
    tournaments: settings.footerTournamentsUrl ?? "/tournaments/upcoming",
    leaderboard: settings.footerLeaderboardUrl ?? "/leaderboard",
    wallet: settings.footerWalletUrl ?? "/wallet",
    profile: settings.footerProfileUrl ?? "/profile",
    terms: settings.footerTermsUrl ?? "/terms",
    privacy: settings.footerPrivacyUrl ?? "/privacy",
    support: settings.footerSupportUrl ?? "/support",
  };
}

export const publicRouter = router({
  socialProfiles: publicProcedure.query(async () => {
    const db = await databaseOrThrow();
    return db.select().from(socialProfiles).where(eq(socialProfiles.isEnabled, true)).orderBy(asc(socialProfiles.sortOrder), asc(socialProfiles.id));
  }),

  home: publicProcedure.query(async ({ ctx }) => {
    const db = await databaseOrThrow();
    const settings = await getSettingsMap();
    const featuredIds = parseStoredTournamentIds(settings.homeFeaturedTournamentIds);
    const [featuredRows, activeAnnouncements, playersRows, tournamentRows, liveRows, topPlayers] = await Promise.all([
      featuredIds.length
        ? db.select().from(tournaments).where(inArray(tournaments.id, featuredIds))
        : db.select().from(tournaments).where(inArray(tournaments.status, ["upcoming", "live"])).orderBy(asc(tournaments.startsAt)).limit(3),
      db.select().from(announcements).where(eq(announcements.isActive, true)).orderBy(desc(announcements.createdAt)).limit(3),
      db.select({ total: sql<number>`count(*)` }).from(users).where(eq(users.isBlocked, false)),
      db.select({ total: sql<number>`count(*)`, prizeCredits: sql<number>`COALESCE(SUM(${tournaments.prizePool}), 0)`, live: sql<number>`COALESCE(SUM(CASE WHEN ${tournaments.status} = 'live' THEN 1 ELSE 0 END), 0)` }).from(tournaments).where(inArray(tournaments.status, ["upcoming", "live", "completed", "closed"])),
      db.select().from(tournaments).where(eq(tournaments.status, "live")).orderBy(asc(tournaments.startsAt)),
      db.select({
        playerId: users.id,
        nickname: users.playerName,
        avatarUrl: users.avatarUrl,
        wins: sql<number>`COALESCE(SUM(CASE WHEN ${tournamentEntries.rank} = 1 THEN 1 ELSE 0 END), 0)`,
        kills: sql<number>`COALESCE(SUM(${tournamentEntries.kills}), 0)`,
        prizeCredits: sql<number>`COALESCE(SUM(${tournamentEntries.prizeAwarded}), 0)`,
      }).from(tournamentEntries).innerJoin(users, eq(users.id, tournamentEntries.userId)).innerJoin(tournaments, eq(tournaments.id, tournamentEntries.tournamentId))
        .where(and(eq(tournamentEntries.status, "registered"), eq(tournaments.status, "completed"), eq(tournaments.resultPublished, true)))
        .groupBy(users.id, users.playerName, users.avatarUrl)
        .orderBy(desc(sql`COALESCE(SUM(${tournamentEntries.prizeAwarded}), 0)`), desc(sql`COALESCE(SUM(CASE WHEN ${tournamentEntries.rank} = 1 THEN 1 ELSE 0 END), 0)`), desc(sql`COALESCE(SUM(${tournamentEntries.kills}), 0)`)).limit(5),
    ]);
    const featured = featuredIds.length
      ? featuredIds.map((id) => featuredRows.find((item) => item.id === id)).filter((item): item is typeof tournaments.$inferSelect => Boolean(item))
      : featuredRows;
    const configuredLiveId = Number(settings.homeLiveTournamentId);
    const selectedLive = (configuredLiveId ? liveRows.find((item) => item.id === configuredLiveId) : liveRows[0]) ?? null;
    const tournamentStats = tournamentRows[0];

    return {
      featured: await presentTournamentsForViewer(featured, ctx.user?.id),
      announcements: activeAnnouncements,
      live: selectedLive ? presentTournament(selectedLive) : null,
      stats: settings.homeStatsEnabled === "false" ? null : {
        totalPlayers: Number(playersRows[0]?.total ?? 0),
        totalTournaments: Number(tournamentStats?.total ?? 0),
        liveTournaments: Number(tournamentStats?.live ?? 0),
        totalPrizeCredits: Number(tournamentStats?.prizeCredits ?? 0),
      },
      topPlayers: topPlayers.map((player, index) => ({ ...player, rank: index + 1, wins: Number(player.wins), kills: Number(player.kills), prizeCredits: Number(player.prizeCredits) })),
      platform: {
        upiId: settings.upiId ?? "",
        paymentInstructions: settings.paymentInstructions ?? "Select a package, complete your UPI payment, then submit the UTR and payment screenshot for review.",
        logoUrl: settings.logoUrl ?? "",
      },
      home: {
        heroTitle: settings.homeHeroTitle ?? "PLAY. COMPETE. WIN.",
        heroDescription: settings.homeHeroDescription ?? "Join competitive Free Fire tournaments, secure your slot with Tournament Credits and compete for prizes.",
        heroBannerUrl: settings.homeHeroBannerUrl ?? "",
        footerLinks: homeFooterLinks(settings),
      },
    };
  }),

  tournaments: publicProcedure
    .input(z.object({ status: z.enum(["upcoming", "live", "completed", "closed", "cancelled"]).optional(), mode: z.enum(["solo", "duo", "squad"]).optional() }).optional())
    .query(async ({ input, ctx }) => {
      const db = await databaseOrThrow();
      const conditions = [input?.status ? eq(tournaments.status, input.status) : inArray(tournaments.status, ["upcoming", "live", "completed", "closed"]), input?.mode ? eq(tournaments.mode, input.mode) : undefined].filter(Boolean);
      const rows = await db.select().from(tournaments)
        .where(and(...conditions))
        .orderBy(input?.status === "completed" ? desc(tournaments.startsAt) : asc(tournaments.startsAt));
      return presentTournamentsForViewer(rows, ctx.user?.id);
    }),

  tournamentBySlug: publicProcedure
    .input(z.object({ slug: z.string().min(1).max(96) }))
    .query(async ({ input, ctx }) => {
      const db = await databaseOrThrow();
      const [tournament] = await db.select().from(tournaments).where(eq(tournaments.slug, input.slug)).limit(1);
      if (!tournament) return null;

      let hasJoined = false;
      if (ctx.user) {
        const [entry] = await db.select({ id: tournamentEntries.id }).from(tournamentEntries)
          .where(and(eq(tournamentEntries.tournamentId, tournament.id), eq(tournamentEntries.userId, ctx.user.id)))
          .limit(1);
        hasJoined = Boolean(entry);
      }

      const canViewLobby = hasJoined && tournament.roomCredentialsPublished;
      return {
        ...presentTournament(tournament),
        hasJoined,
        roomId: canViewLobby ? tournament.roomId : null,
        roomPassword: canViewLobby ? tournament.roomPassword : null,
      };
    }),

  liveFeed: publicProcedure.query(async ({ ctx }) => {
    const db = await databaseOrThrow();
    const [liveRows, startingSoonRows, recentRows] = await Promise.all([
      db.select().from(tournaments).where(eq(tournaments.status, "live")).orderBy(asc(tournaments.startsAt)),
      db.select().from(tournaments).where(eq(tournaments.status, "upcoming")).orderBy(asc(tournaments.startsAt)).limit(4),
      db.select().from(tournaments).where(and(eq(tournaments.status, "completed"), eq(tournaments.resultPublished, true))).orderBy(desc(tournaments.startsAt)).limit(4),
    ]);
    return {
      live: await presentTournamentsForViewer(liveRows, ctx.user?.id),
      startingSoon: await presentTournamentsForViewer(startingSoonRows, ctx.user?.id),
      recentResults: await presentTournamentsForViewer(recentRows, ctx.user?.id),
    };
  }),

  leaderboard: publicProcedure
    .input(z.object({ tournamentId: z.number().int().positive().optional(), scope: z.enum(["overall", "weekly", "monthly", "tournament"]).optional(), mode: z.enum(["solo", "duo", "squad"]).optional() }).optional())
    .query(async ({ input, ctx }) => {
      const db = await databaseOrThrow();
      const eligible = await db.select().from(tournaments)
        .where(and(eq(tournaments.status, "completed"), eq(tournaments.resultPublished, true)))
        .orderBy(desc(tournaments.startsAt));
      const scope = input?.scope ?? "overall";
      const periodStart = new Date();
      if (scope === "weekly") periodStart.setDate(periodStart.getDate() - 7);
      if (scope === "monthly") periodStart.setMonth(periodStart.getMonth() - 1);
      const selectedTournament = input?.tournamentId ? eligible.find((item) => item.id === input.tournamentId) : undefined;
      const filtered = eligible.filter((tournament) => {
        if (input?.mode && tournament.mode !== input.mode) return false;
        if (scope === "tournament") return selectedTournament ? tournament.id === selectedTournament.id : tournament.id === eligible[0]?.id;
        if (scope === "weekly" || scope === "monthly") return tournament.startsAt >= periodStart;
        return true;
      });
      if (!filtered.length) return { tournaments: eligible.map(presentTournament), tournament: selectedTournament ? presentTournament(selectedTournament) : null, scope, entries: [], myRank: null };

      const tournamentIds = filtered.map((tournament) => tournament.id);
      const rows = await db.select({
        userId: users.id,
        playerName: users.playerName,
        accountName: users.name,
        avatarUrl: users.avatarUrl,
        matches: sql<number>`COUNT(${tournamentEntries.id})`,
        wins: sql<number>`COALESCE(SUM(CASE WHEN ${tournamentEntries.rank} = 1 THEN 1 ELSE 0 END), 0)`,
        kills: sql<number>`COALESCE(SUM(${tournamentEntries.kills}), 0)`,
        points: sql<number>`COALESCE(SUM(${tournamentEntries.score}), 0)`,
        prizeAwarded: sql<number>`COALESCE(SUM(${tournamentEntries.prizeAwarded}), 0)`,
      }).from(tournamentEntries)
        .innerJoin(users, eq(users.id, tournamentEntries.userId))
        .where(and(inArray(tournamentEntries.tournamentId, tournamentIds), eq(tournamentEntries.status, "registered")))
        .groupBy(users.id, users.playerName, users.name, users.avatarUrl)
        .orderBy(desc(sql`COALESCE(SUM(${tournamentEntries.score}), 0)`), desc(sql`COALESCE(SUM(CASE WHEN ${tournamentEntries.rank} = 1 THEN 1 ELSE 0 END), 0)`), desc(sql`COALESCE(SUM(${tournamentEntries.kills}), 0)`));
      const entries = rows.map((entry, index) => {
        const matches = Number(entry.matches);
        const wins = Number(entry.wins);
        return { ...entry, rank: index + 1, matches, wins, kills: Number(entry.kills), points: Number(entry.points), prizeAwarded: Number(entry.prizeAwarded), winRate: matches ? Math.round((wins / matches) * 100) : 0 };
      });
      const mine = ctx.user ? entries.find((entry) => entry.userId === ctx.user?.id) : undefined;
      return { tournaments: eligible.map(presentTournament), tournament: selectedTournament ? presentTournament(selectedTournament) : null, scope, entries, myRank: mine ?? null };
    }),

  content: publicProcedure.query(async () => {
    const settings = await getSettingsMap();
    return {
      rules: settings.rules ?? "Every participant must join with accurate in-game details, arrive before the room opens, and follow the published fair-play requirements. PLX Gaming may disqualify accounts that breach tournament rules.",
      supportEmail: settings.supportEmail ?? "support@plx.gaming",
      supportMessage: settings.supportMessage ?? "Need a hand with a payment, tournament entry, or result? Reach the PLX Gaming support desk and include your player name and tournament details.",
    };
  }),
});
