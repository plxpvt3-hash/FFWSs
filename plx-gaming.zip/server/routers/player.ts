import { TRPCError } from "@trpc/server";
import { and, desc, eq, sql } from "drizzle-orm";
import { randomUUID } from "crypto";
import { z } from "zod";
import {
  adminActivity,
  creditPackages,
  paymentRequests,
  tournamentEntries,
  tournaments,
  users,
  wallets,
  walletTransactions,
  withdrawalRequests,
  withdrawalStatusHistory,
} from "../../drizzle/schema";
import { ensureWallet } from "../db";
import { databaseOrThrow, getSettingsMap, requireActiveAccount, saveImageDataUrl } from "../platform";
import { assertJoinEligibility, assertWithdrawalAmount, normalizeUtr, normalizeWithdrawalDestination } from "../security";
import { calculateProfileStats } from "../profileMetrics";
import { redactUnpublishedRoomCredentials, toPrivatePlayerProfile } from "../playerProfilePrivacy";
import { freeFireUidSchema, playerNicknameSchema } from "../validation";
import { protectedProcedure, router } from "../_core/trpc";

const imageDataUrl = z.string().min(30).max(6_000_000);

export const playerRouter = router({
  dashboard: protectedProcedure.query(async ({ ctx }) => {
    const account = await requireActiveAccount(ctx.user.id);
    await ensureWallet(account.id);
    const db = await databaseOrThrow();
    const [wallet, entries, recentTransactions] = await Promise.all([
      db.select().from(wallets).where(eq(wallets.userId, account.id)).limit(1),
      db.select({
        id: tournamentEntries.id,
        entryStatus: tournamentEntries.status,
        joinedAt: tournamentEntries.joinedAt,
        rank: tournamentEntries.rank,
        kills: tournamentEntries.kills,
        score: tournamentEntries.score,
        prizeAwarded: tournamentEntries.prizeAwarded,
        tournament: tournaments,
      }).from(tournamentEntries)
        .innerJoin(tournaments, eq(tournaments.id, tournamentEntries.tournamentId))
        .where(eq(tournamentEntries.userId, account.id))
        .orderBy(desc(tournamentEntries.joinedAt)).limit(5),
      db.select().from(walletTransactions).where(eq(walletTransactions.userId, account.id))
        .orderBy(desc(walletTransactions.createdAt)).limit(5),
    ]);

    return {
      account,
      balance: wallet[0]?.balance ?? 0,
      winningBalance: wallet[0]?.winningBalance ?? 0,
      bonusBalance: wallet[0]?.bonusBalance ?? 0,
      entries,
      recentTransactions,
    };
  }),

  profile: protectedProcedure
    .input(z.object({
      playerName: playerNicknameSchema,
      gameUid: freeFireUidSchema,
      avatarDataUrl: imageDataUrl.optional(),
    }))
    .mutation(async ({ ctx, input }) => {
      const account = await requireActiveAccount(ctx.user.id);
      const db = await databaseOrThrow();
      const upload = input.avatarDataUrl ? await saveImageDataUrl(input.avatarDataUrl, "avatars", account.id) : null;
      await db.update(users).set({
        playerName: input.playerName,
        gameUid: input.gameUid,
        avatarUrl: upload?.url ?? account.avatarUrl,
      }).where(eq(users.id, account.id));
      await db.insert(adminActivity).values({
        actorId: account.id,
        action: "player.profile_updated",
        targetType: "user",
        targetId: String(account.id),
        details: JSON.stringify({ avatarChanged: Boolean(upload) }),
      });
      return { success: true, avatarUrl: upload?.url ?? account.avatarUrl };
    }),

  profileOverview: protectedProcedure.query(async ({ ctx }) => {
    const account = await requireActiveAccount(ctx.user.id);
    await ensureWallet(account.id);
    const db = await databaseOrThrow();
    const [walletRows, joinedEntries, transactions] = await Promise.all([
      db.select({ balance: wallets.balance }).from(wallets).where(eq(wallets.userId, account.id)).limit(1),
      db.select({
        id: tournamentEntries.id,
        entryStatus: tournamentEntries.status,
        joinedAt: tournamentEntries.joinedAt,
        playerNickname: tournamentEntries.playerNickname,
        playerUid: tournamentEntries.playerUid,
        rank: tournamentEntries.rank,
        kills: tournamentEntries.kills,
        score: tournamentEntries.score,
        prizeAwarded: tournamentEntries.prizeAwarded,
        prizeCredited: tournamentEntries.prizeCredited,
        tournament: tournaments,
      }).from(tournamentEntries)
        .innerJoin(tournaments, eq(tournaments.id, tournamentEntries.tournamentId))
        .where(eq(tournamentEntries.userId, account.id))
        .orderBy(desc(tournamentEntries.joinedAt)),
      db.select().from(walletTransactions).where(eq(walletTransactions.userId, account.id))
        .orderBy(desc(walletTransactions.createdAt)),
    ]);

    const stats = calculateProfileStats(joinedEntries.map((entry) => ({
      entry: { status: entry.entryStatus, rank: entry.rank, kills: entry.kills, prizeAwarded: entry.prizeAwarded },
      tournament: { status: entry.tournament.status },
    })));

    const entries = joinedEntries.map((entry) => ({
      ...entry,
      tournament: redactUnpublishedRoomCredentials(entry.tournament),
    }));

    return {
      profile: toPrivatePlayerProfile(account),
      balance: walletRows[0]?.balance ?? 0,
      stats,
      entries,
      transactions,
    };
  }),

  myTournaments: protectedProcedure.query(async ({ ctx }) => {
    const account = await requireActiveAccount(ctx.user.id);
    const db = await databaseOrThrow();
    const entries = await db.select({
      id: tournamentEntries.id,
      entryStatus: tournamentEntries.status,
      joinedAt: tournamentEntries.joinedAt,
      playerNickname: tournamentEntries.playerNickname,
      playerUid: tournamentEntries.playerUid,
      teamName: tournamentEntries.teamName,
      rank: tournamentEntries.rank,
      kills: tournamentEntries.kills,
      score: tournamentEntries.score,
      prizeAwarded: tournamentEntries.prizeAwarded,
      tournament: tournaments,
      accountNickname: users.playerName,
      accountUid: users.gameUid,
    }).from(tournamentEntries)
      .innerJoin(tournaments, eq(tournaments.id, tournamentEntries.tournamentId))
      .innerJoin(users, eq(users.id, tournamentEntries.userId))
      .where(eq(tournamentEntries.userId, account.id))
      .orderBy(desc(tournamentEntries.joinedAt));
    return entries.map((entry) => ({
      ...entry,
      tournament: redactUnpublishedRoomCredentials(entry.tournament),
    }));
  }),

  transactions: protectedProcedure.query(async ({ ctx }) => {
    const account = await requireActiveAccount(ctx.user.id);
    const db = await databaseOrThrow();
    const [wallet, transactions] = await Promise.all([
      db.select().from(wallets).where(eq(wallets.userId, account.id)).limit(1),
      db.select().from(walletTransactions).where(eq(walletTransactions.userId, account.id)).orderBy(desc(walletTransactions.createdAt)),
    ]);
    return {
      balance: wallet[0]?.balance ?? 0,
      winningBalance: wallet[0]?.winningBalance ?? 0,
      bonusBalance: wallet[0]?.bonusBalance ?? 0,
      transactions,
    };
  }),

  walletSummary: protectedProcedure.query(async ({ ctx }) => {
    const account = await requireActiveAccount(ctx.user.id);
    await ensureWallet(account.id);
    const db = await databaseOrThrow();
    const [walletRows, withdrawalRows, transactions, settings] = await Promise.all([
      db.select().from(wallets).where(eq(wallets.userId, account.id)).limit(1),
      db.select().from(withdrawalRequests).where(eq(withdrawalRequests.userId, account.id)).orderBy(desc(withdrawalRequests.createdAt)),
      db.select().from(walletTransactions).where(eq(walletTransactions.userId, account.id)).orderBy(desc(walletTransactions.createdAt)).limit(30),
      getSettingsMap(),
    ]);
    const configuredMinimum = Number(settings.withdrawalMinimum ?? "50");
    return {
      balances: {
        credits: walletRows[0]?.balance ?? 0,
        winnings: walletRows[0]?.winningBalance ?? 0,
        bonus: walletRows[0]?.bonusBalance ?? 0,
      },
      minimumWithdrawal: Number.isSafeInteger(configuredMinimum) && configuredMinimum > 0 ? configuredMinimum : 50,
      withdrawals: withdrawalRows,
      transactions,
    };
  }),

  requestWithdrawal: protectedProcedure
    .input(z.object({ amount: z.number().int().positive().max(1_000_000), upiId: z.string().trim().min(4).max(160) }))
    .mutation(async ({ ctx, input }) => {
      const account = await requireActiveAccount(ctx.user.id);
      await ensureWallet(account.id);
      const db = await databaseOrThrow();
      const settings = await getSettingsMap();
      const minimumWithdrawal = Number(settings.withdrawalMinimum ?? "50");
      assertWithdrawalAmount(input.amount, minimumWithdrawal);
      const upiId = normalizeWithdrawalDestination(input.upiId);
      const withdrawalCode = `WD-${Date.now().toString(36).toUpperCase()}-${randomUUID().replace(/-/g, "").slice(0, 10).toUpperCase()}`;

      try {
        return await db.transaction(async (tx) => {
          const [debit] = await tx.update(wallets)
            .set({ winningBalance: sql`${wallets.winningBalance} - ${input.amount}` })
            .where(and(eq(wallets.userId, account.id), sql`${wallets.winningBalance} >= ${input.amount}`));
          if (!debit.affectedRows) {
            throw new TRPCError({ code: "BAD_REQUEST", message: "Your available winning balance is not enough for this withdrawal." });
          }

          const [request] = await tx.insert(withdrawalRequests).values({
            withdrawalCode,
            userId: account.id,
            activeUserKey: String(account.id),
            upiId,
            amount: input.amount,
          });
          const [wallet] = await tx.select().from(wallets).where(eq(wallets.userId, account.id)).limit(1);
          if (!wallet) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Wallet could not be loaded." });
          await tx.insert(walletTransactions).values({
            userId: account.id,
            direction: "debit",
            balanceCategory: "winning",
            type: "withdrawal_hold",
            amount: input.amount,
            balanceAfter: wallet.winningBalance,
            referenceType: "withdrawal",
            referenceId: String(request.insertId),
            note: `Withdrawal request ${withdrawalCode}`,
          });
          await tx.insert(withdrawalStatusHistory).values({
            withdrawalRequestId: request.insertId,
            status: "pending",
            actorType: "player",
            actorId: account.id,
            note: "Withdrawal request submitted.",
          });
          await tx.insert(adminActivity).values({
            actorId: account.id,
            action: "player.withdrawal_submitted",
            targetType: "withdrawal_request",
            targetId: String(request.insertId),
            details: JSON.stringify({ withdrawalCode, amount: input.amount }),
          });
          return { success: true, withdrawalId: request.insertId, withdrawalCode, status: "pending" as const };
        });
      } catch (error: any) {
        if (error?.code === "ER_DUP_ENTRY") {
          throw new TRPCError({ code: "CONFLICT", message: "You already have an active withdrawal request. Wait for PLX Administration to complete it." });
        }
        throw error;
      }
    }),

  joinTournament: protectedProcedure
    .input(z.object({
      tournamentId: z.number().int().positive(),
      playerNickname: playerNicknameSchema,
      playerUid: freeFireUidSchema,
      teamName: z.string().trim().max(64).optional(),
    }))
    .mutation(async ({ ctx, input }) => {
      const account = await requireActiveAccount(ctx.user.id);
      const db = await databaseOrThrow();
      await ensureWallet(account.id);

      try {
        return await db.transaction(async (tx) => {
        const [tournament] = await tx.select().from(tournaments).where(eq(tournaments.id, input.tournamentId)).limit(1);
        if (!tournament) throw new TRPCError({ code: "BAD_REQUEST", message: "This tournament is not accepting entries." });

        const [existing] = await tx.select({ id: tournamentEntries.id }).from(tournamentEntries)
          .where(and(eq(tournamentEntries.tournamentId, tournament.id), eq(tournamentEntries.userId, account.id))).limit(1);
        const [duplicateUid] = await tx.select({ id: tournamentEntries.id }).from(tournamentEntries)
          .where(and(eq(tournamentEntries.tournamentId, tournament.id), eq(tournamentEntries.playerUid, input.playerUid))).limit(1);
        const [walletSnapshot] = await tx.select({ balance: wallets.balance }).from(wallets).where(eq(wallets.userId, account.id)).limit(1);
        if (duplicateUid) throw new TRPCError({ code: "CONFLICT", message: "This Free Fire UID is already registered for the tournament." });
        assertJoinEligibility({
          tournamentStatus: tournament.status,
          registrationOpen: tournament.registrationOpen,
          hasExistingEntry: Boolean(existing),
          filledSlots: tournament.filledSlots,
          totalSlots: tournament.totalSlots,
          balance: walletSnapshot?.balance ?? 0,
          entryFee: tournament.entryFee,
          mode: tournament.mode,
          teamName: input.teamName,
        });

        if (tournament.entryFee > 0) {
          const [deduction] = await tx.update(wallets)
            .set({ balance: sql`${wallets.balance} - ${tournament.entryFee}` })
            .where(and(eq(wallets.userId, account.id), sql`${wallets.balance} >= ${tournament.entryFee}`));
          if (!deduction.affectedRows) {
            throw new TRPCError({ code: "BAD_REQUEST", message: "You do not have enough Credits for this entry." });
          }
        }

        const [reservation] = await tx.update(tournaments)
          .set({ filledSlots: sql`${tournaments.filledSlots} + 1` })
          .where(and(
            eq(tournaments.id, tournament.id),
            eq(tournaments.status, "upcoming"),
            eq(tournaments.registrationOpen, true),
            sql`${tournaments.filledSlots} < ${tournaments.totalSlots}`,
          ));
        if (!reservation.affectedRows) {
          throw new TRPCError({ code: "CONFLICT", message: "All tournament slots have been filled." });
        }

        const [wallet] = await tx.select().from(wallets).where(eq(wallets.userId, account.id)).limit(1);
        if (!wallet) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Wallet could not be loaded." });

        const [entry] = await tx.insert(tournamentEntries).values({
          tournamentId: tournament.id,
          userId: account.id,
          playerNickname: input.playerNickname,
          playerUid: input.playerUid,
          teamName: tournament.mode === "solo" ? null : input.teamName ?? null,
        });

        await tx.update(users).set({ playerName: input.playerNickname, gameUid: input.playerUid }).where(eq(users.id, account.id));

        if (tournament.entryFee > 0) {
          await tx.insert(walletTransactions).values({
            userId: account.id,
            direction: "debit",
            type: "tournament_entry",
            amount: tournament.entryFee,
            balanceAfter: wallet.balance,
            referenceType: "tournament",
            referenceId: String(tournament.id),
            note: `Entry fee for ${tournament.name}`,
          });
        }

        await tx.insert(adminActivity).values({
          actorId: account.id,
          action: "player.tournament_joined",
          targetType: "tournament",
          targetId: String(tournament.id),
          details: JSON.stringify({ entryId: entry.insertId, mode: tournament.mode, playerUid: input.playerUid }),
        });

        return { success: true, entryId: entry.insertId, balance: wallet.balance };
        });
      } catch (error: any) {
        if (error?.code === "ER_DUP_ENTRY") {
          throw new TRPCError({ code: "CONFLICT", message: "This Free Fire UID is already registered for the tournament." });
        }
        throw error;
      }
    }),

  addCredits: protectedProcedure.query(async ({ ctx }) => {
    const account = await requireActiveAccount(ctx.user.id);
    const db = await databaseOrThrow();
    const [packages, settings, requests] = await Promise.all([
      db.select().from(creditPackages).where(eq(creditPackages.isActive, true)),
      getSettingsMap(),
      db.select().from(paymentRequests).where(eq(paymentRequests.userId, account.id)).orderBy(desc(paymentRequests.createdAt)),
    ]);
    return {
      packages: packages.sort((a, b) => a.sortOrder - b.sortOrder),
      upiId: settings.upiId ?? "",
      qrCodeUrl: settings.qrCodeUrl ?? "",
      instructions: settings.paymentInstructions ?? "Choose a package, pay using the UPI ID or QR code, and submit your UTR with a payment screenshot.",
      requests,
    };
  }),

  submitPaymentRequest: protectedProcedure
    .input(z.object({ packageId: z.number().int().positive(), utr: z.string().trim().min(6).max(100), screenshotDataUrl: imageDataUrl }))
    .mutation(async ({ ctx, input }) => {
      const account = await requireActiveAccount(ctx.user.id);
      const db = await databaseOrThrow();
      const utr = normalizeUtr(input.utr);
      const [pkg, duplicate] = await Promise.all([
        db.select().from(creditPackages).where(and(eq(creditPackages.id, input.packageId), eq(creditPackages.isActive, true))).limit(1),
        db.select({ id: paymentRequests.id }).from(paymentRequests).where(eq(paymentRequests.utr, utr)).limit(1),
      ]);
      if (!pkg[0]) throw new TRPCError({ code: "BAD_REQUEST", message: "This Credits package is no longer available." });
      if (duplicate[0]) throw new TRPCError({ code: "CONFLICT", message: "That UTR number has already been submitted." });

      const upload = await saveImageDataUrl(input.screenshotDataUrl, "payments", account.id);
      try {
        return await db.transaction(async (tx) => {
          const [request] = await tx.insert(paymentRequests).values({
            userId: account.id,
            packageId: pkg[0].id,
            creditsRequested: pkg[0].credits,
            amountPaid: pkg[0].priceInr,
            utr,
            screenshotKey: upload.key,
            screenshotUrl: upload.url,
          });
          await tx.insert(adminActivity).values({
            actorId: account.id,
            action: "player.payment_submitted",
            targetType: "payment_request",
            targetId: String(request.insertId),
            details: JSON.stringify({ packageId: pkg[0].id, credits: pkg[0].credits }),
          });
          return { success: true, requestId: request.insertId };
        });
      } catch (error: any) {
        if (error?.code === "ER_DUP_ENTRY") {
          throw new TRPCError({ code: "CONFLICT", message: "That UTR number has already been submitted." });
        }
        throw error;
      }
    }),
});
