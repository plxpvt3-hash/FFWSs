import { TRPCError } from "@trpc/server";

type JoinEligibility = {
  tournamentStatus: "draft" | "upcoming" | "live" | "completed" | "closed" | "cancelled";
  registrationOpen: boolean;
  hasExistingEntry: boolean;
  filledSlots: number;
  totalSlots: number;
  balance: number;
  entryFee: number;
  mode: "solo" | "duo" | "squad";
  teamName?: string;
};

export function assertJoinEligibility(input: JoinEligibility) {
  if (input.tournamentStatus !== "upcoming") throw new TRPCError({ code: "BAD_REQUEST", message: "This tournament is not accepting entries." });
  if (!input.registrationOpen) throw new TRPCError({ code: "BAD_REQUEST", message: "Registration for this tournament is closed." });
  if (input.hasExistingEntry) throw new TRPCError({ code: "CONFLICT", message: "You have already joined this tournament." });
  if (input.filledSlots >= input.totalSlots) throw new TRPCError({ code: "CONFLICT", message: "All tournament slots have been filled." });
  if (input.balance < input.entryFee) throw new TRPCError({ code: "BAD_REQUEST", message: "You do not have enough Credits for this entry." });
  if (input.mode !== "solo" && !input.teamName?.trim()) throw new TRPCError({ code: "BAD_REQUEST", message: "Enter a team name for Duo and Squad tournaments." });
}

export function normalizeUtr(utr: string) {
  return utr.trim().toUpperCase();
}

export function assertPaymentIsPending(status: "pending" | "approved" | "rejected") {
  if (status !== "pending") throw new TRPCError({ code: "CONFLICT", message: "This payment request has already been reviewed." });
}

export function creditPackageRemovalAction(hasPaymentHistory: boolean) {
  return hasPaymentHistory ? "archive" : "remove";
}

export const withdrawalStatuses = ["pending", "approved", "processing", "paid", "rejected"] as const;
export type WithdrawalStatus = (typeof withdrawalStatuses)[number];

/** A player may provide a UPI VPA or a mobile-number destination for manual payout. */
export function normalizeWithdrawalDestination(value: string) {
  const destination = value.trim();
  const isUpiVpa = /^[A-Za-z0-9._-]{2,100}@[A-Za-z0-9.-]{2,60}$/.test(destination);
  const isPhoneNumber = /^\+?[0-9][0-9 -]{8,18}$/.test(destination);
  if (!isUpiVpa && !isPhoneNumber) {
    throw new TRPCError({ code: "BAD_REQUEST", message: "Enter a valid UPI ID or UPI-linked mobile number." });
  }
  return isUpiVpa ? destination.toLowerCase() : destination.replace(/[ -]/g, "");
}

export function assertWithdrawalAmount(amount: number, minimum: number) {
  if (!Number.isSafeInteger(amount) || amount <= 0) {
    throw new TRPCError({ code: "BAD_REQUEST", message: "Enter a valid whole-number withdrawal amount." });
  }
  if (!Number.isSafeInteger(minimum) || minimum <= 0) {
    throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "The withdrawal minimum is not configured correctly." });
  }
  if (amount < minimum) {
    throw new TRPCError({ code: "BAD_REQUEST", message: `The minimum withdrawal amount is ₹${minimum}.` });
  }
}

const withdrawalTransitions: Record<Exclude<WithdrawalStatus, "paid" | "rejected">, WithdrawalStatus[]> = {
  pending: ["approved", "rejected"],
  approved: ["processing", "rejected"],
  processing: ["paid", "rejected"],
};

export function assertWithdrawalTransition(current: WithdrawalStatus, next: WithdrawalStatus) {
  if (current === "paid" || current === "rejected" || !withdrawalTransitions[current].includes(next)) {
    throw new TRPCError({ code: "CONFLICT", message: `A ${current} withdrawal cannot be changed to ${next}.` });
  }
}
