import { TRPCError } from "@trpc/server";

type JoinEligibility = {
  tournamentStatus: "draft" | "upcoming" | "live" | "completed" | "closed" | "cancelled";
  registrationOpen: boolean;
  hasExistingEntry: boolean;
  filledSlots: number;
  totalSlots: number;
  balance: number;
  entryFee: number;
  mode: "solo" | "duo" | "squad";
  teamName?: string;
};

export function assertJoinEligibility(input: JoinEligibility) {
  if (input.tournamentStatus !== "upcoming") throw new TRPCError({ code: "BAD_REQUEST", message: "This tournament is not accepting entries." });
  if (!input.registrationOpen) throw new TRPCError({ code: "BAD_REQUEST", message: "Registration for this tournament is closed." });
  if (input.hasExistingEntry) throw new TRPCError({ code: "CONFLICT", message: "You have already joined this tournament." });
  if (input.filledSlots >= input.totalSlots) throw new TRPCError({ code: "CONFLICT", message: "All tournament slots have been filled." });
  if (input.balance < input.entryFee) throw new TRPCError({ code: "BAD_REQUEST", message: "You do not have enough Credits for this entry." });
  if (input.mode !== "solo" && !input.teamName?.trim()) throw new TRPCError({ code: "BAD_REQUEST", message: "Enter a team name for Duo and Squad tournaments." });
}

export function normalizeUtr(utr: string) {
  return utr.trim().toUpperCase();
}

export function assertPaymentIsPending(status: "pending" | "approved" | "rejected") {
  if (status !== "pending") throw new TRPCError({ code: "CONFLICT", message: "This payment request has already been reviewed." });
}

export function creditPackageRemovalAction(hasPaymentHistory: boolean) {
  return hasPaymentHistory ? "archive" : "remove";
}
