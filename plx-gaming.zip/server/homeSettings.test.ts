import { describe, expect, it } from "vitest";
import { isSafeHomeFooterDestination } from "./homeSettings";

describe("Home footer destination validation", () => {
  it("allows safe internal routes and official HTTPS destinations", () => {
    expect(isSafeHomeFooterDestination("/terms")).toBe(true);
    expect(isSafeHomeFooterDestination(" /privacy ")).toBe(true);
    expect(isSafeHomeFooterDestination("https://plxgaming.example/community")).toBe(true);
  });

  it("rejects empty, protocol-relative, unsafe, and malformed destinations", () => {
    expect(isSafeHomeFooterDestination("")).toBe(false);
    expect(isSafeHomeFooterDestination("//untrusted.example")).toBe(false);
    expect(isSafeHomeFooterDestination("javascript:alert(1)")).toBe(false);
    expect(isSafeHomeFooterDestination("ftp://example.com")).toBe(false);
    expect(isSafeHomeFooterDestination("not a url")).toBe(false);
  });
});
