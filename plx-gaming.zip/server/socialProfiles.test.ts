import { describe, expect, it } from "vitest";
import type { TrpcContext } from "./_core/context";
import { appRouter } from "./routers";

function adminContext(): TrpcContext {
  return {
    user: {
      id: 91,
      openId: "social-settings-admin",
      name: "PLX Administrator",
      email: "admin@plx.test",
      loginMethod: "email",
      role: "admin",
      isBlocked: false,
      playerName: null,
      gameUid: null,
      avatarUrl: null,
      createdAt: new Date(),
      updatedAt: new Date(),
      lastSignedIn: new Date(),
    },
    req: {} as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };
}

describe("admin.saveSocialProfile validation", () => {
  it("rejects an empty official profile URL", async () => {
    await expect(appRouter.createCaller(adminContext()).admin.saveSocialProfile({
      platform: "instagram",
      handle: "@PLXGaming",
      profileUrl: "",
      isEnabled: true,
      sortOrder: 0,
    })).rejects.toThrow();
  });

  it("rejects a profile value that is not a full http or https URL", async () => {
    await expect(appRouter.createCaller(adminContext()).admin.saveSocialProfile({
      platform: "telegram",
      handle: "@PLXGaming",
      profileUrl: "t.me/plxgaming",
      isEnabled: true,
      sortOrder: 1,
    })).rejects.toThrow();
  });
});
