import { describe, expect, it } from "vitest";
import { assertCreditsAmount, assertTournamentCapacity, createSlug } from "./validation";

describe("PLX validation safeguards", () => {
  it("accepts only non-zero whole Credits adjustments", () => {
    expect(() => assertCreditsAmount(50)).not.toThrow();
    expect(() => assertCreditsAmount(-50)).not.toThrow();
    expect(() => assertCreditsAmount(0)).toThrow("non-zero whole Credits");
    expect(() => assertCreditsAmount(1.5)).toThrow("non-zero whole Credits");
  });

  it("does not allow tournament capacity below confirmed entries", () => {
    expect(() => assertTournamentCapacity(48, 48)).not.toThrow();
    expect(() => assertTournamentCapacity(47, 48)).toThrow("cannot be less than confirmed entries");
  });

  it("creates normalized and collision-resistant tournament slugs", () => {
    const first = createSlug("PLX Free Fire — Weekend Cup!");
    const second = createSlug("PLX Free Fire — Weekend Cup!");

    expect(first).toMatch(/^plx-free-fire-weekend-cup-[a-f0-9]{8}$/);
    expect(second).toMatch(/^plx-free-fire-weekend-cup-[a-f0-9]{8}$/);
    expect(first).not.toBe(second);
  });
});
