import type { CreateExpressContextOptions } from "@trpc/server/adapters/express";
import type { User } from "../../drizzle/schema";
import { getLocalSessionToken, resolveLocalSession } from "../localAuth";
import { sdk } from "./sdk";

export type TrpcContext = {
  req: CreateExpressContextOptions["req"];
  res: CreateExpressContextOptions["res"];
  user: User | null;
};

export async function createContext(
  opts: CreateExpressContextOptions
): Promise<TrpcContext> {
  let user: User | null = null;

  try {
    user = await sdk.authenticateRequest(opts.req);
  } catch (error) {
    // Manus OAuth is preferred, with an opaque local PLX session as a compatible fallback.
    user = await resolveLocalSession(getLocalSessionToken(opts.req));
  }

  return {
    req: opts.req,
    res: opts.res,
    user,
  };
}
