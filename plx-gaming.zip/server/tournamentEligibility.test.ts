import { describe, expect, it } from "vitest";
import { tournamentJoinUiState } from "../client/src/lib/tournamentEligibility";

const joinable = { isAuthenticated: true, hasJoined: false, remainingSlots: 20, status: "upcoming" as const, registrationOpen: true, walletBalance: 100, entryFee: 50 };

describe("PLX tournament card eligibility", () => {
  it("identifies joinable and insufficient-Credits states from actual Wallet and tournament values", () => {
    expect(tournamentJoinUiState(joinable)).toBe("joinable");
    expect(tournamentJoinUiState({ ...joinable, walletBalance: 49 })).toBe("insufficient_credits");
  });

  it("blocks full, closed, and duplicate tournament entries before showing a join action", () => {
    expect(tournamentJoinUiState({ ...joinable, remainingSlots: 0 })).toBe("slots_full");
    expect(tournamentJoinUiState({ ...joinable, registrationOpen: false })).toBe("registration_closed");
    expect(tournamentJoinUiState({ ...joinable, status: "closed" })).toBe("registration_closed");
    expect(tournamentJoinUiState({ ...joinable, hasJoined: true })).toBe("already_joined");
  });

  it("requires sign-in before calculating a player Wallet state", () => {
    expect(tournamentJoinUiState({ ...joinable, isAuthenticated: false, walletBalance: undefined })).toBe("sign_in");
    expect(tournamentJoinUiState({ ...joinable, walletBalance: undefined })).toBe("checking_wallet");
  });
});
