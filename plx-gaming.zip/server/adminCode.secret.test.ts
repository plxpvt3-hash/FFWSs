import { describe, expect, it } from "vitest";
import { createAdminCodeSession, getAdminCodeSession, verifyAdminLoginCode } from "./adminCode";

describe("PLX Admin Login Code", () => {
  it("accepts the configured server-only code and rejects an incorrect code", () => {
    expect(verifyAdminLoginCode("8730")).toBe(true);
    expect(verifyAdminLoginCode("0000")).toBe(false);
  });

  it("recognizes the signed code session from the incoming HTTP Cookie header", () => {
    const session = createAdminCodeSession(42);
    expect(getAdminCodeSession({ headers: { cookie: `plx-admin-code=${session.token}` } })).toEqual({ actorId: 42 });
  });
});
