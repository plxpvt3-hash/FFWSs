import { createHmac, randomBytes, timingSafeEqual } from "crypto";
import { parse } from "cookie";
import { eq } from "drizzle-orm";
import { users } from "../drizzle/schema";
import { getDb } from "./db";
import { getSessionCookieOptions } from "./_core/cookies";

export const ADMIN_CODE_COOKIE = "plx-admin-code";
const SERVICE_OPEN_ID = "plx-service-admin";
const TTL_MS = 12 * 60 * 60 * 1000;

function secret() { const value = process.env.PLX_ADMIN_LOGIN_CODE; if (!value) throw new Error("Admin Login Code is not configured"); return value; }
function sign(value: string) { return createHmac("sha256", process.env.JWT_SECRET ?? "plx-admin-session").update(value).digest("base64url"); }

export function verifyAdminLoginCode(code: string) { const a = Buffer.from(secret()); const b = Buffer.from(code); return a.length === b.length && timingSafeEqual(a, b); }

export async function getServiceAdmin() {
  const db = await getDb(); if (!db) throw new Error("Database is unavailable");
  let rows = await db.select().from(users).where(eq(users.openId, SERVICE_OPEN_ID)).limit(1);
  if (!rows[0]) { await db.insert(users).values({ openId: SERVICE_OPEN_ID, name: "PLX Service Administrator", loginMethod: "admin-code", role: "admin", isBlocked: false }); rows = await db.select().from(users).where(eq(users.openId, SERVICE_OPEN_ID)).limit(1); }
  return rows[0]!;
}

export function createAdminCodeSession(actorId: number) { const expiresAt = Date.now() + TTL_MS; const value = `${expiresAt}.${actorId}.${randomBytes(18).toString("base64url")}`; return { token: `${value}.${sign(value)}`, expiresAt }; }
export function getAdminCodeSession(req: any) { const token = parse(req.headers?.cookie ?? "")[ADMIN_CODE_COOKIE]; if (!token) return null; const [expires, actorId, nonce, signature] = token.split("."); const value = `${expires}.${actorId}.${nonce}`; if (!expires || !actorId || !nonce || !signature || Number(expires) <= Date.now()) return null; const a = Buffer.from(sign(value)); const b = Buffer.from(signature); return a.length === b.length && timingSafeEqual(a, b) ? { actorId: Number(actorId) } : null; }
export function setAdminCodeCookie(ctx: { req: any; res: any }, token: string, expiresAt: number) { ctx.res.cookie(ADMIN_CODE_COOKIE, token, { ...getSessionCookieOptions(ctx.req), sameSite: "lax", maxAge: Math.max(0, expiresAt - Date.now()) }); }
export function clearAdminCodeCookie(ctx: { req: any; res: any }) { ctx.res.clearCookie(ADMIN_CODE_COOKIE, { ...getSessionCookieOptions(ctx.req), sameSite: "lax" }); }
