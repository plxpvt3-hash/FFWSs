export function toPrivatePlayerProfile(account: {
  id: number;
  name: string | null;
  playerName: string | null;
  gameUid: string | null;
  avatarUrl: string | null;
  createdAt: Date;
}) {
  return {
    id: account.id,
    playerId: `PLX-${String(account.id).padStart(6, "0")}`,
    playerName: account.playerName || account.name || "PLX Player",
    gameUid: account.gameUid || "",
    avatarUrl: account.avatarUrl,
    joinedAt: account.createdAt,
  };
}

export function redactUnpublishedRoomCredentials<T extends {
  roomCredentialsPublished: boolean;
  roomId: string | null;
  roomPassword: string | null;
}>(tournament: T) {
  return {
    ...tournament,
    roomId: tournament.roomCredentialsPublished ? tournament.roomId : null,
    roomPassword: tournament.roomCredentialsPublished ? tournament.roomPassword : null,
  };
}
