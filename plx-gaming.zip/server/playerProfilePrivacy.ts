export function toPrivatePlayerProfile(account: {
  id: number;
  name: string | null;
  playerName: string | null;
  gameUid: string | null;
  preferredGameMode: string | null;
  avatarUrl: string | null;
  createdAt: Date;
}) {
  return {
    id: account.id,
    playerId: `PLX-${String(account.id).padStart(6, "0")}`,
    displayName: account.name || account.playerName || "PLX Player",
    playerName: account.playerName || account.name || "PLX Player",
    gameUid: account.gameUid || "",
    preferredGameMode: account.preferredGameMode || null,
    avatarUrl: account.avatarUrl,
    joinedAt: account.createdAt,
  };
}

export function redactUnpublishedRoomCredentials<T extends {
  roomCredentialsPublished: boolean;
  roomId: string | null;
  roomPassword: string | null;
}>(tournament: T) {
  return {
    ...tournament,
    roomId: tournament.roomCredentialsPublished ? tournament.roomId : null,
    roomPassword: tournament.roomCredentialsPublished ? tournament.roomPassword : null,
  };
}
