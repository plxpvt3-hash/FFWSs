import { beforeEach, describe, expect, it, vi } from "vitest";
import type { TrpcContext } from "./_core/context";

const platformMocks = vi.hoisted(() => ({ databaseOrThrow: vi.fn(), requireActiveAccount: vi.fn() }));
const dbMocks = vi.hoisted(() => ({ ensureWallet: vi.fn() }));

vi.mock("./platform", async (importOriginal) => ({ ...(await importOriginal<typeof import("./platform")>()), ...platformMocks }));
vi.mock("./db", async (importOriginal) => ({ ...(await importOriginal<typeof import("./db")>()), ...dbMocks }));

import { appRouter } from "./routers";

const tournament = { id: 12, name: "PLX Solo Cup", mode: "solo" as const, status: "upcoming" as const, registrationOpen: true, filledSlots: 12, totalSlots: 48, entryFee: 20 };
const playerIdentity = { playerNickname: "Player Seven", playerUid: "123456789" };

function playerContext(): TrpcContext {
  return { user: { id: 7, openId: "player-7", name: "Tournament Player", email: "player@plx.test", loginMethod: "email", role: "user", isBlocked: false, playerName: null, gameUid: null, avatarUrl: null, createdAt: new Date(), updatedAt: new Date(), lastSignedIn: new Date() }, req: {} as TrpcContext["req"], res: {} as TrpcContext["res"] };
}

function resultQuery(rows: unknown[]) { return { from: vi.fn().mockReturnValue({ where: vi.fn().mockReturnValue({ limit: vi.fn().mockResolvedValue(rows) }) }) }; }

function createJoinDatabase({ existingEntry = false, duplicateUid = false, balance = 100 }: { existingEntry?: boolean; duplicateUid?: boolean; balance?: number } = {}) {
  const walletDebitWhere = vi.fn().mockResolvedValue([{ affectedRows: 1 }]);
  const reservationWhere = vi.fn().mockResolvedValue([{ affectedRows: 1 }]);
  const walletDebitSet = vi.fn().mockReturnValue({ where: walletDebitWhere });
  const reservationSet = vi.fn().mockReturnValue({ where: reservationWhere });
  const entryValues = vi.fn().mockResolvedValue([{ insertId: 99 }]);
  const transactionValues = vi.fn().mockResolvedValue([{ insertId: 100 }]);
  const activityValues = vi.fn().mockResolvedValue([{ insertId: 101 }]);
  const tx = {
    select: vi.fn()
      .mockReturnValueOnce(resultQuery([tournament]))
      .mockReturnValueOnce(resultQuery(existingEntry ? [{ id: 1 }] : []))
      .mockReturnValueOnce(resultQuery(duplicateUid ? [{ id: 2 }] : []))
      .mockReturnValueOnce(resultQuery([{ balance }]))
      .mockReturnValueOnce(resultQuery([{ id: 1, userId: 7, balance: balance - tournament.entryFee }])),
    update: vi.fn().mockReturnValueOnce({ set: walletDebitSet }).mockReturnValueOnce({ set: reservationSet }).mockReturnValueOnce({ set: vi.fn().mockReturnValue({ where: vi.fn().mockResolvedValue([{ affectedRows: 1 }]) }) }),
    insert: vi.fn()
      .mockReturnValueOnce({ values: entryValues })
      .mockReturnValueOnce({ values: transactionValues })
      .mockReturnValueOnce({ values: activityValues }),
  };
  const database = { transaction: vi.fn(async (callback: (transaction: typeof tx) => Promise<unknown>) => callback(tx)) };
  return { database, tx, walletDebitSet, reservationSet, entryValues, transactionValues };
}

describe("player.joinTournament transactional entry", () => {
  beforeEach(() => {
    vi.clearAllMocks();
    platformMocks.requireActiveAccount.mockResolvedValue({ id: 7, isBlocked: false });
    dbMocks.ensureWallet.mockResolvedValue(undefined);
  });

  it("reserves a slot, records an entry and ledger debit, and returns the post-entry balance in one transaction", async () => {
    const { database, tx, walletDebitSet, reservationSet, entryValues, transactionValues } = createJoinDatabase();
    platformMocks.databaseOrThrow.mockResolvedValue(database);

    await expect(appRouter.createCaller(playerContext()).player.joinTournament({ tournamentId: 12, ...playerIdentity })).resolves.toEqual({ success: true, entryId: 99, balance: 80 });
    expect(database.transaction).toHaveBeenCalledTimes(1);
    expect(walletDebitSet).toHaveBeenCalledTimes(1);
    expect(reservationSet).toHaveBeenCalledTimes(1);
    expect(entryValues).toHaveBeenCalledWith(expect.objectContaining({ tournamentId: 12, userId: 7, playerNickname: "Player Seven", playerUid: "123456789", teamName: null }));
    expect(transactionValues).toHaveBeenCalledWith(expect.objectContaining({ type: "tournament_entry", amount: 20, balanceAfter: 80, referenceId: "12" }));
    expect(tx.insert).toHaveBeenCalledTimes(3);
  });

  it("does not issue any debit, reservation, or insert after the duplicate-entry guard rejects the transaction", async () => {
    const { database, tx } = createJoinDatabase({ existingEntry: true });
    platformMocks.databaseOrThrow.mockResolvedValue(database);

    await expect(appRouter.createCaller(playerContext()).player.joinTournament({ tournamentId: 12, ...playerIdentity })).rejects.toThrow("already joined");
    expect(tx.update).not.toHaveBeenCalled();
    expect(tx.insert).not.toHaveBeenCalled();
  });

  it("does not issue any debit, reservation, or insert when the wallet cannot cover the entry fee", async () => {
    const { database, tx } = createJoinDatabase({ balance: 19 });
    platformMocks.databaseOrThrow.mockResolvedValue(database);

    await expect(appRouter.createCaller(playerContext()).player.joinTournament({ tournamentId: 12, ...playerIdentity })).rejects.toThrow("enough Credits");
    expect(tx.update).not.toHaveBeenCalled();
    expect(tx.insert).not.toHaveBeenCalled();
  });

  it("stops before any Credit movement when the UID is already registered for the same tournament", async () => {
    const { database, tx } = createJoinDatabase({ duplicateUid: true });
    platformMocks.databaseOrThrow.mockResolvedValue(database);

    await expect(appRouter.createCaller(playerContext()).player.joinTournament({ tournamentId: 12, ...playerIdentity })).rejects.toThrow("UID is already registered");
    expect(tx.update).not.toHaveBeenCalled();
    expect(tx.insert).not.toHaveBeenCalled();
  });

  it("rejects a non-numeric UID before creating a database transaction", async () => {
    await expect(appRouter.createCaller(playerContext()).player.joinTournament({ tournamentId: 12, playerNickname: "Player Seven", playerUid: "AB12" })).rejects.toThrow("digits only");
    expect(platformMocks.databaseOrThrow).not.toHaveBeenCalled();
  });

  it("maps a concurrent database UID constraint to the duplicate registration response", async () => {
    platformMocks.databaseOrThrow.mockResolvedValue({ transaction: vi.fn().mockRejectedValue({ code: "ER_DUP_ENTRY" }) });

    await expect(appRouter.createCaller(playerContext()).player.joinTournament({ tournamentId: 12, ...playerIdentity })).rejects.toThrow("UID is already registered");
  });
});
