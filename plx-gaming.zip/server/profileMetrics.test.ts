import { describe, expect, it } from "vitest";
import { calculateProfileStats } from "./profileMetrics";

describe("calculateProfileStats", () => {
  it("aggregates registered completed entries and ignores withdrawn registrations", () => {
    const stats = calculateProfileStats([
      { entry: { status: "registered", rank: 1, kills: 8, prizeAwarded: 120 }, tournament: { status: "completed" } },
      { entry: { status: "registered", rank: 4, kills: 3, prizeAwarded: 20 }, tournament: { status: "completed" } },
      { entry: { status: "registered", rank: null, kills: 0, prizeAwarded: 0 }, tournament: { status: "upcoming" } },
      { entry: { status: "withdrawn", rank: 1, kills: 99, prizeAwarded: 999 }, tournament: { status: "completed" } },
    ]);

    expect(stats).toEqual({
      totalTournaments: 3,
      tournamentsWon: 1,
      matchesPlayed: 2,
      totalKills: 11,
      totalPrizeCredits: 140,
      winRate: 50,
      bestRank: 1,
    });
  });

  it("returns safe empty metrics before a player has completed a match", () => {
    expect(calculateProfileStats([
      { entry: { status: "registered", rank: null, kills: 0, prizeAwarded: 0 }, tournament: { status: "upcoming" } },
    ])).toMatchObject({ totalTournaments: 1, matchesPlayed: 0, winRate: 0, bestRank: null });
  });
});
