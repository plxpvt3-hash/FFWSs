import { createHash, randomBytes } from "crypto";
import { and, eq, gt, isNull, sql } from "drizzle-orm";
import { parse as parseCookieHeader } from "cookie";
import type { Express, Request, Response } from "express";
import { googleOAuthIdentities, googleOAuthStates, users, wallets } from "../drizzle/schema";
import { getDb } from "./db";
import { getSessionCookieOptions } from "./_core/cookies";
import { sdk } from "./_core/sdk";
import { createLocalSession, getLocalSessionToken, LOCAL_SESSION_COOKIE, normalizeEmail, resolveLocalSession } from "./localAuth";

const GOOGLE_AUTHORIZE_ENDPOINT = "https://accounts.google.com/o/oauth2/v2/auth";
const GOOGLE_TOKEN_ENDPOINT = "https://oauth2.googleapis.com/token";
const GOOGLE_USERINFO_ENDPOINT = "https://openidconnect.googleapis.com/v1/userinfo";
const GOOGLE_STATE_COOKIE = "plx-google-oauth-state";
const STATE_DURATION_MS = 10 * 60 * 1000;

type OAuthIntent = "login" | "link";
type GoogleUserInfo = {
  sub?: string;
  email?: string;
  email_verified?: boolean | string;
  name?: string;
  picture?: string;
};

function hashState(state: string) {
  return createHash("sha256").update(state).digest("hex");
}

export function isSafeOAuthNextPath(path: string | undefined, fallback: string) {
  if (!path || !path.startsWith("/") || path.startsWith("//") || path.includes("\\")) return fallback;
  return path.slice(0, 512);
}

function publicAppUrl() {
  return (process.env.PLX_PUBLIC_APP_URL ?? "https://plxgaming-kov2vkkf.manus.space").replace(/\/$/, "");
}

function googleRedirectUri() {
  return `${publicAppUrl()}/api/auth/google/callback`;
}

function failUrl(reason: string) {
  return `/auth?oauth=${encodeURIComponent(reason)}`;
}

function withGoogleResult(path: string, result: string) {
  const url = new URL(path, publicAppUrl());
  url.searchParams.set("google", result);
  return `${url.pathname}${url.search}${url.hash}`;
}

function setGoogleStateCookie(res: Response, req: Request, state: string) {
  res.cookie(GOOGLE_STATE_COOKIE, state, {
    ...getSessionCookieOptions(req),
    sameSite: "lax",
    maxAge: STATE_DURATION_MS,
  });
}

function clearGoogleStateCookie(res: Response, req: Request) {
  res.clearCookie(GOOGLE_STATE_COOKIE, { ...getSessionCookieOptions(req), sameSite: "lax" });
}

async function currentAccountForLink(req: Request) {
  const localUser = await resolveLocalSession(getLocalSessionToken(req));
  if (localUser) return localUser;
  try {
    return await sdk.authenticateRequest(req);
  } catch {
    return null;
  }
}

async function consumeState(state: string, requestState: string | undefined) {
  if (!requestState || state !== requestState) return null;
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const [record] = await db.select().from(googleOAuthStates)
    .where(and(eq(googleOAuthStates.stateHash, hashState(state)), isNull(googleOAuthStates.usedAt), gt(googleOAuthStates.expiresAt, new Date())))
    .limit(1);
  if (!record) return null;
  const [updated] = await db.update(googleOAuthStates).set({ usedAt: new Date() })
    .where(and(eq(googleOAuthStates.id, record.id), isNull(googleOAuthStates.usedAt)));
  return updated.affectedRows ? record : null;
}

async function fetchGoogleUser(code: string) {
  const clientId = process.env.GOOGLE_OAUTH_CLIENT_ID;
  const clientSecret = process.env.GOOGLE_OAUTH_CLIENT_SECRET;
  if (!clientId || !clientSecret) throw new Error("Google OAuth is not configured");

  const tokenBody = new URLSearchParams({
    code,
    client_id: clientId,
    client_secret: clientSecret,
    redirect_uri: googleRedirectUri(),
    grant_type: "authorization_code",
  });
  const tokenResponse = await fetch(GOOGLE_TOKEN_ENDPOINT, {
    method: "POST",
    headers: { "content-type": "application/x-www-form-urlencoded" },
    body: tokenBody,
    signal: AbortSignal.timeout(15_000),
  });
  const token = await tokenResponse.json() as { access_token?: string };
  if (!tokenResponse.ok || !token.access_token) throw new Error("Google authorization-code exchange failed");

  const profileResponse = await fetch(GOOGLE_USERINFO_ENDPOINT, {
    headers: { authorization: `Bearer ${token.access_token}` },
    signal: AbortSignal.timeout(15_000),
  });
  const profile = await profileResponse.json() as GoogleUserInfo;
  if (!profileResponse.ok || !profile.sub || !profile.email || (profile.email_verified !== true && profile.email_verified !== "true")) {
    throw new Error("Google did not confirm a verified account email");
  }
  return {
    subject: profile.sub,
    email: normalizeEmail(profile.email),
    name: profile.name?.trim().slice(0, 255) || null,
    picture: profile.picture?.trim().slice(0, 2048) || null,
  };
}

function googleOpenId(subject: string) {
  return `google_${createHash("sha256").update(subject).digest("hex").slice(0, 56)}`;
}

async function resolveGoogleAccount(input: {
  subject: string;
  email: string;
  name: string | null;
  picture: string | null;
  intent: OAuthIntent;
  requestedUserId: number | null;
}) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  return db.transaction(async (tx) => {
    const [existingIdentity] = await tx.select().from(googleOAuthIdentities)
      .where(eq(googleOAuthIdentities.googleSubject, input.subject)).limit(1);
    if (existingIdentity) {
      if (input.intent === "link" && input.requestedUserId !== existingIdentity.userId) {
        throw new Error("This Google account is already linked to another PLX account");
      }
      const [account] = await tx.select().from(users).where(eq(users.id, existingIdentity.userId)).limit(1);
      if (!account || account.isBlocked) throw new Error("This PLX account is unavailable");
      return account;
    }

    let accountId = input.requestedUserId;
    if (input.intent === "link" && !accountId) throw new Error("Sign in to PLX before linking Google");
    if (!accountId) {
      const [sameEmail] = await tx.select().from(users).where(sql`lower(${users.email}) = ${input.email}`).limit(1);
      if (sameEmail) accountId = sameEmail.id;
    }

    if (accountId) {
      const [account] = await tx.select().from(users).where(eq(users.id, accountId)).limit(1);
      if (!account || account.isBlocked) throw new Error("This PLX account is unavailable");
      await tx.update(users).set({
        name: input.name ?? account.name,
        avatarUrl: account.avatarUrl ?? input.picture,
        loginMethod: account.loginMethod === "email_password" ? "email_password_google" : "google",
        lastSignedIn: new Date(),
      }).where(eq(users.id, account.id));
    } else {
      const [inserted] = await tx.insert(users).values({
        openId: googleOpenId(input.subject),
        email: input.email,
        name: input.name,
        avatarUrl: input.picture,
        loginMethod: "google",
        lastSignedIn: new Date(),
      });
      accountId = inserted.insertId;
      await tx.insert(wallets).values({ userId: accountId, balance: 0 });
    }

    await tx.insert(googleOAuthIdentities).values({
      userId: accountId,
      googleSubject: input.subject,
      email: input.email,
      emailVerified: true,
    });
    const [account] = await tx.select().from(users).where(eq(users.id, accountId)).limit(1);
    if (!account) throw new Error("Google account link could not be completed");
    return account;
  });
}

function setLocalSession(res: Response, req: Request, rawToken: string, expiresAt: Date) {
  res.cookie(LOCAL_SESSION_COOKIE, rawToken, {
    ...getSessionCookieOptions(req),
    sameSite: "lax",
    maxAge: Math.max(0, expiresAt.getTime() - Date.now()),
  });
}

export function registerGoogleOAuthRoutes(app: Express) {
  app.get("/api/auth/google/start", async (req, res) => {
    try {
      const intent: OAuthIntent = req.query.intent === "link" ? "link" : "login";
      const account = intent === "link" ? await currentAccountForLink(req) : null;
      if (intent === "link" && !account) {
        res.redirect(302, failUrl("link_requires_login"));
        return;
      }
      const next = isSafeOAuthNextPath(typeof req.query.next === "string" ? req.query.next : undefined, intent === "link" ? "/profile" : "/dashboard");
      const state = randomBytes(32).toString("base64url");
      const db = await getDb();
      if (!db) throw new Error("Database is not available");
      await db.insert(googleOAuthStates).values({
        stateHash: hashState(state),
        intent,
        userId: account?.id ?? null,
        nextPath: next,
        expiresAt: new Date(Date.now() + STATE_DURATION_MS),
      });
      setGoogleStateCookie(res, req, state);

      const clientId = process.env.GOOGLE_OAUTH_CLIENT_ID;
      if (!clientId) throw new Error("Google OAuth is not configured");
      const authorizationUrl = new URL(GOOGLE_AUTHORIZE_ENDPOINT);
      authorizationUrl.searchParams.set("client_id", clientId);
      authorizationUrl.searchParams.set("redirect_uri", googleRedirectUri());
      authorizationUrl.searchParams.set("response_type", "code");
      authorizationUrl.searchParams.set("scope", "openid email profile");
      authorizationUrl.searchParams.set("state", state);
      authorizationUrl.searchParams.set("prompt", "select_account");
      res.redirect(302, authorizationUrl.toString());
    } catch (error) {
      console.error("[GoogleOAuth] Could not start authorization", error instanceof Error ? error.message : "unknown error");
      res.redirect(302, failUrl("google_unavailable"));
    }
  });

  app.get("/api/auth/google/callback", async (req, res) => {
    const code = typeof req.query.code === "string" ? req.query.code : undefined;
    const state = typeof req.query.state === "string" ? req.query.state : undefined;
    const stateCookie = parseCookieHeader(req.headers.cookie ?? "")[GOOGLE_STATE_COOKIE];
    clearGoogleStateCookie(res, req);
    if (!code || !state) {
      res.redirect(302, failUrl("google_cancelled"));
      return;
    }
    try {
      const request = await consumeState(state, stateCookie);
      if (!request) {
        res.redirect(302, failUrl("google_state_invalid"));
        return;
      }
      const google = await fetchGoogleUser(code);
      const account = await resolveGoogleAccount({
        ...google,
        intent: request.intent,
        requestedUserId: request.userId,
      });
      const session = await createLocalSession(account.id);
      setLocalSession(res, req, session.rawToken, session.expiresAt);
      res.redirect(302, withGoogleResult(request.nextPath, request.intent === "link" ? "linked" : "signed-in"));
    } catch (error) {
      console.error("[GoogleOAuth] Callback rejected", error instanceof Error ? error.message : "unknown error");
      res.redirect(302, failUrl("google_failed"));
    }
  });
}
