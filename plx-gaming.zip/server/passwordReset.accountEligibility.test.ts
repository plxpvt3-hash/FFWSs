import { afterEach, describe, expect, it, vi } from "vitest";

vi.mock("./db", () => ({ getDb: vi.fn() }));

import { getDb } from "./db";
import { requestPasswordReset, resetPasswordWithToken } from "./passwordReset";

const mockedGetDb = vi.mocked(getDb);
const originalFetch = global.fetch;
const originalResendApiKey = process.env.RESEND_API_KEY;
const originalResendFromEmail = process.env.RESEND_FROM_EMAIL;

afterEach(() => {
  vi.clearAllMocks();
  global.fetch = originalFetch;
  if (originalResendApiKey === undefined) delete process.env.RESEND_API_KEY;
  else process.env.RESEND_API_KEY = originalResendApiKey;
  if (originalResendFromEmail === undefined) delete process.env.RESEND_FROM_EMAIL;
  else process.env.RESEND_FROM_EMAIL = originalResendFromEmail;
});

describe("PLX password-reset account eligibility", () => {
  it("sends a recovery link to a registered, unblocked OAuth account without requiring an existing local credential", async () => {
    const limit = vi.fn().mockResolvedValue([{ userId: 1, email: "plxpvt3@gmail.com" }]);
    const where = vi.fn(() => ({ limit }));
    const from = vi.fn(() => ({ where }));
    const deleteWhere = vi.fn().mockResolvedValue(undefined);
    const insertValues = vi.fn().mockResolvedValue(undefined);
    const db = {
      select: vi.fn(() => ({ from })),
      delete: vi.fn(() => ({ where: deleteWhere })),
      insert: vi.fn(() => ({ values: insertValues })),
    };
    mockedGetDb.mockResolvedValue(db as never);
    process.env.RESEND_API_KEY = "test-resend-key";
    process.env.RESEND_FROM_EMAIL = "onboarding@resend.dev";
    global.fetch = vi.fn().mockResolvedValue({ ok: true, json: async () => ({ id: "email_test_1" }) }) as typeof fetch;

    await expect(requestPasswordReset({
      email: "plxpvt3@gmail.com",
      resetUrlBase: "https://plxgaming.example",
    })).resolves.toEqual({ requested: true });

    expect(global.fetch).toHaveBeenCalledOnce();
    expect(from).toHaveBeenCalledOnce();
    expect(insertValues).toHaveBeenCalledOnce();
  });

  it("creates or rotates a local credential through a reset token and revokes active local sessions", async () => {
    const limit = vi.fn().mockResolvedValue([{ id: 7, userId: 1 }]);
    const where = vi.fn(() => ({ limit }));
    const from = vi.fn(() => ({ where }));
    const mutationWhere = vi.fn().mockResolvedValue(undefined);
    const set = vi.fn(() => ({ where: mutationWhere }));
    const onDuplicateKeyUpdate = vi.fn().mockResolvedValue(undefined);
    const values = vi.fn(() => ({ onDuplicateKeyUpdate }));
    const tx = {
      select: vi.fn(() => ({ from })),
      insert: vi.fn(() => ({ values })),
      update: vi.fn(() => ({ set })),
    };
    const db = { transaction: vi.fn((callback: (transaction: typeof tx) => Promise<boolean>) => callback(tx)) };
    mockedGetDb.mockResolvedValue(db as never);

    await expect(resetPasswordWithToken({ token: "secure-test-token", password: "secure-password-123" })).resolves.toBe(true);

    expect(values).toHaveBeenCalledWith(expect.objectContaining({ userId: 1, passwordHash: expect.stringMatching(/^scrypt\$/) }));
    expect(onDuplicateKeyUpdate).toHaveBeenCalledOnce();
    expect(set).toHaveBeenCalledTimes(2);
  });
});
