import { describe, expect, it } from "vitest";
import { canStartUpiPayment, canSubmitPaymentProof, paymentSubmissionUiState } from "../client/src/lib/paymentFlow";

describe("PLX UPI payment screen readiness", () => {
  it("requires the administrator-configured UPI ID before a player can start payment", () => {
    expect(canStartUpiPayment("plx@upi")).toBe(true);
    expect(canStartUpiPayment("")).toBe(false);
  });

  it("requires both a transaction reference and screenshot before proof can be submitted", () => {
    expect(canSubmitPaymentProof("UPI-REF-001", "data:image/png;base64,abc")).toBe(true);
    expect(canSubmitPaymentProof("", "data:image/png;base64,abc")).toBe(false);
    expect(canSubmitPaymentProof("UPI-REF-001", "")).toBe(false);
  });

  it("locks the action while payment proof is being sent and reveals Pending Verification after success", () => {
    expect(canSubmitPaymentProof("UPI-REF-001", "data:image/png;base64,abc", true)).toBe(false);
    expect(paymentSubmissionUiState(true, false)).toMatchObject({ isLocked: true, buttonLabel: "SUBMITTING PAYMENT PROOF", showPendingConfirmation: false });
    expect(paymentSubmissionUiState(false, true)).toMatchObject({ isLocked: true, showPendingConfirmation: true });
  });
});
