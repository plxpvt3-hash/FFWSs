import { afterEach, describe, expect, it, vi } from "vitest";

vi.mock("./db", () => ({ getDb: vi.fn() }));

import { getDb } from "./db";
import { hashPasswordResetToken, resetPasswordWithToken } from "./passwordReset";

const mockedGetDb = vi.mocked(getDb);

afterEach(() => {
  vi.clearAllMocks();
});

describe("PLX password-reset security", () => {
  it("derives a fixed-length one-way hash rather than persisting a raw reset token", () => {
    const rawToken = "mGf1f9dJQX7k8YuvPMqN4H-fjxY6N9ZBf9lX_kW3AUw";
    const hash = hashPasswordResetToken(rawToken);
    expect(hash).toMatch(/^[a-f0-9]{64}$/);
    expect(hash).not.toContain(rawToken);
    expect(hashPasswordResetToken(rawToken)).toBe(hash);
  });

  it("does not change a password when a reset token is invalid, expired, or already used", async () => {
    const limit = vi.fn().mockResolvedValue([]);
    const where = vi.fn(() => ({ limit }));
    const from = vi.fn(() => ({ where }));
    const transaction = { select: vi.fn(() => ({ from })) };
    mockedGetDb.mockResolvedValue({ transaction: vi.fn((callback: (tx: typeof transaction) => Promise<boolean>) => callback(transaction)) } as never);

    await expect(resetPasswordWithToken({ token: "a".repeat(43), password: "secure-password-123" })).resolves.toBe(false);
    expect(transaction.select).toHaveBeenCalledOnce();
  });

  it("uses a fixed-length opaque token suitable for a one-time reset URL", () => {
    const token = "mGf1f9dJQx7k8YuvPMqN4H-fjxY6N9ZBf9lX_kW3AUw";
    expect(token).toHaveLength(43);
    expect(hashPasswordResetToken(token)).not.toBe(token);
  });
});
