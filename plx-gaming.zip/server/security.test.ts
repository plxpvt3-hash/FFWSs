import { describe, expect, it } from "vitest";
import { assertJoinEligibility, assertPaymentIsPending, assertWithdrawalAmount, assertWithdrawalTransition, creditPackageRemovalAction, normalizeUtr, normalizeWithdrawalDestination } from "./security";

const validJoin = {
  tournamentStatus: "upcoming" as const,
  registrationOpen: true,
  hasExistingEntry: false,
  filledSlots: 47,
  totalSlots: 48,
  balance: 500,
  entryFee: 50,
  mode: "solo" as const,
};

describe("PLX server-side integrity rules", () => {
  it("rejects non-open, registration-closed, duplicate, full, and unfunded tournament entries before reservation", () => {
    expect(() => assertJoinEligibility(validJoin)).not.toThrow();
    expect(() => assertJoinEligibility({ ...validJoin, tournamentStatus: "live" })).toThrow("not accepting entries");
    expect(() => assertJoinEligibility({ ...validJoin, registrationOpen: false })).toThrow("Registration for this tournament is closed");
    expect(() => assertJoinEligibility({ ...validJoin, hasExistingEntry: true })).toThrow("already joined");
    expect(() => assertJoinEligibility({ ...validJoin, filledSlots: 48 })).toThrow("slots have been filled");
    expect(() => assertJoinEligibility({ ...validJoin, balance: 49 })).toThrow("enough Credits");
  });

  it("requires a team name for Duo and Squad entries", () => {
    expect(() => assertJoinEligibility({ ...validJoin, mode: "duo" })).toThrow("team name");
    expect(() => assertJoinEligibility({ ...validJoin, mode: "squad", teamName: "PLX Storm" })).not.toThrow();
  });

  it("normalizes UTR values and permits review only from pending state", () => {
    expect(normalizeUtr("  plx-utr-7k9  ")).toBe("PLX-UTR-7K9");
    expect(() => assertPaymentIsPending("pending")).not.toThrow();
    expect(() => assertPaymentIsPending("approved")).toThrow("already been reviewed");
    expect(() => assertPaymentIsPending("rejected")).toThrow("already been reviewed");
  });

  it("archives packages with payment history and only removes unused packages", () => {
    expect(creditPackageRemovalAction(true)).toBe("archive");
    expect(creditPackageRemovalAction(false)).toBe("remove");
  });

  it("validates withdrawal destinations and minimum whole-number payout amounts server-side", () => {
    expect(normalizeWithdrawalDestination("  Player.Pay@UPI  ")).toBe("player.pay@upi");
    expect(normalizeWithdrawalDestination("+91 98765 43210")).toBe("+919876543210");
    expect(() => normalizeWithdrawalDestination("not a payout destination")).toThrow("valid UPI ID");
    expect(() => assertWithdrawalAmount(49, 50)).toThrow("minimum withdrawal");
    expect(() => assertWithdrawalAmount(50.5, 50)).toThrow("whole-number");
    expect(() => assertWithdrawalAmount(50, 50)).not.toThrow();
  });

  it("permits only the protected withdrawal lifecycle and never reopens final payouts", () => {
    expect(() => assertWithdrawalTransition("pending", "approved")).not.toThrow();
    expect(() => assertWithdrawalTransition("pending", "paid")).toThrow("cannot be changed");
    expect(() => assertWithdrawalTransition("approved", "processing")).not.toThrow();
    expect(() => assertWithdrawalTransition("processing", "paid")).not.toThrow();
    expect(() => assertWithdrawalTransition("paid", "processing")).toThrow("cannot be changed");
    expect(() => assertWithdrawalTransition("rejected", "approved")).toThrow("cannot be changed");
  });
});
