import { COOKIE_NAME } from "@shared/const";
import { TRPCError } from "@trpc/server";
import { and, eq } from "drizzle-orm";
import { z } from "zod";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { protectedProcedure, publicProcedure, router } from "./_core/trpc";
import { clearAdminCodeCookie, createAdminCodeSession, getAdminCodeSession, getServiceAdmin, setAdminCodeCookie, verifyAdminLoginCode } from "./adminCode";
import { authenticateLocalAccount, createLocalAccount, createLocalSession, getLocalSessionToken, LOCAL_SESSION_COOKIE, revokeAllLocalSessions, revokeLocalSession } from "./localAuth";
import { adminRouter } from "./routers/admin";
import { playerRouter } from "./routers/player";
import { publicRouter } from "./routers/public";
import { requestPasswordReset, resetPasswordWithToken } from "./passwordReset";
import { googleOAuthIdentities, localCredentials } from "../drizzle/schema";
import { databaseOrThrow, requireActiveAccount } from "./platform";

const localAuthInput = z.object({
  email: z.string().trim().email().max(320),
  password: z.string().min(10).max(128),
});

function setLocalSessionCookie(ctx: { req: any; res: any }, rawToken: string, expiresAt: Date) {
  ctx.res.cookie(LOCAL_SESSION_COOKIE, rawToken, {
    ...getSessionCookieOptions(ctx.req),
    sameSite: "lax",
    maxAge: Math.max(0, expiresAt.getTime() - Date.now()),
  });
}

const PLX_PUBLIC_APP_URL = process.env.PLX_PUBLIC_APP_URL ?? "https://plxgaming-kov2vkkf.manus.space";

export const appRouter = router({
  system: systemRouter,
  adminAuth: router({
    status: publicProcedure.query(async ({ ctx }) => { const session = getAdminCodeSession(ctx.req); if (!session) return { verified: false }; const actor = await getServiceAdmin(); return { verified: actor.id === session.actorId && actor.role === "admin" && !actor.isBlocked }; }),
    login: publicProcedure.input(z.object({ code: z.string().min(1).max(32) })).mutation(async ({ ctx, input }) => { if (!verifyAdminLoginCode(input.code)) throw new TRPCError({ code: "UNAUTHORIZED", message: "Invalid admin code" }); const actor = await getServiceAdmin(); const session = createAdminCodeSession(actor.id); setAdminCodeCookie(ctx, session.token, session.expiresAt); return { success: true }; }),
    logout: publicProcedure.mutation(({ ctx }) => { clearAdminCodeCookie(ctx); return { success: true } as const; }),
  }),
  auth: router({
    me: publicProcedure.query((opts) => opts.ctx.user),
    register: publicProcedure.input(localAuthInput.extend({ name: z.string().trim().min(2).max(80) })).mutation(async ({ ctx, input }) => {
      const user = await createLocalAccount(input);
      if (!user) throw new TRPCError({ code: "CONFLICT", message: "An account already exists for this email address." });
      const session = await createLocalSession(user.id);
      setLocalSessionCookie(ctx, session.rawToken, session.expiresAt);
      return { success: true, user };
    }),
    login: publicProcedure.input(localAuthInput).mutation(async ({ ctx, input }) => {
      const user = await authenticateLocalAccount(input.email, input.password);
      if (!user) throw new TRPCError({ code: "UNAUTHORIZED", message: "Invalid email or password." });
      const session = await createLocalSession(user.id);
      setLocalSessionCookie(ctx, session.rawToken, session.expiresAt);
      return { success: true, user };
    }),
    requestPasswordReset: publicProcedure.input(z.object({ email: z.string().trim().email().max(320) })).mutation(async ({ ctx, input }) => {
      try {
        return await requestPasswordReset({ email: input.email, resetUrlBase: PLX_PUBLIC_APP_URL });
      } catch (error) {
        console.error("[PasswordReset] Unable to deliver reset email", error instanceof Error ? error.message : "unknown error");
        return { requested: true } as const;
      }
    }),
    resetPassword: publicProcedure.input(z.object({ token: z.string().min(40).max(200), password: z.string().min(10).max(128) })).mutation(async ({ input }) => {
      const reset = await resetPasswordWithToken(input);
      if (!reset) throw new TRPCError({ code: "UNAUTHORIZED", message: "This reset link is invalid, expired, or has already been used." });
      return { success: true } as const;
    }),
    googleStatus: protectedProcedure.query(async ({ ctx }) => {
      const account = await requireActiveAccount(ctx.user.id);
      const db = await databaseOrThrow();
      const [[identity], [credential]] = await Promise.all([
        db.select({ email: googleOAuthIdentities.email, linkedAt: googleOAuthIdentities.linkedAt })
          .from(googleOAuthIdentities).where(eq(googleOAuthIdentities.userId, account.id)).limit(1),
        db.select({ userId: localCredentials.userId }).from(localCredentials).where(eq(localCredentials.userId, account.id)).limit(1),
      ]);
      return {
        linked: Boolean(identity),
        email: identity?.email ?? null,
        linkedAt: identity?.linkedAt ?? null,
        canUnlink: Boolean(identity && credential),
      };
    }),
    unlinkGoogle: protectedProcedure.mutation(async ({ ctx }) => {
      const account = await requireActiveAccount(ctx.user.id);
      const db = await databaseOrThrow();
      const [[identity], [credential]] = await Promise.all([
        db.select({ id: googleOAuthIdentities.id }).from(googleOAuthIdentities).where(eq(googleOAuthIdentities.userId, account.id)).limit(1),
        db.select({ userId: localCredentials.userId }).from(localCredentials).where(eq(localCredentials.userId, account.id)).limit(1),
      ]);
      if (!identity) throw new TRPCError({ code: "BAD_REQUEST", message: "No Google account is linked to this PLX profile." });
      if (!credential) throw new TRPCError({ code: "BAD_REQUEST", message: "Set a PLX password through Forgot Password before unlinking Google." });
      await db.delete(googleOAuthIdentities).where(and(eq(googleOAuthIdentities.id, identity.id), eq(googleOAuthIdentities.userId, account.id)));
      return { success: true } as const;
    }),
    logoutAllLocalSessions: protectedProcedure.mutation(async ({ ctx }) => {
      const account = await requireActiveAccount(ctx.user.id);
      await revokeAllLocalSessions(account.id);
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, cookieOptions);
      ctx.res.clearCookie(LOCAL_SESSION_COOKIE, { ...cookieOptions, sameSite: "lax" });
      return { success: true } as const;
    }),
    logout: publicProcedure.mutation(async ({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, cookieOptions);
      await revokeLocalSession(getLocalSessionToken(ctx.req));
      ctx.res.clearCookie(LOCAL_SESSION_COOKIE, { ...cookieOptions, sameSite: "lax" });
      return { success: true } as const;
    }),
  }),
  public: publicRouter,
  player: playerRouter,
  admin: adminRouter,
});

export type AppRouter = typeof appRouter;
