import { COOKIE_NAME } from "@shared/const";
import { TRPCError } from "@trpc/server";
import { z } from "zod";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router } from "./_core/trpc";
import { authenticateLocalAccount, createLocalAccount, createLocalSession, getLocalSessionToken, LOCAL_SESSION_COOKIE, revokeLocalSession } from "./localAuth";
import { adminRouter } from "./routers/admin";
import { playerRouter } from "./routers/player";
import { publicRouter } from "./routers/public";

const localAuthInput = z.object({
  email: z.string().trim().email().max(320),
  password: z.string().min(10).max(128),
});

function setLocalSessionCookie(ctx: { req: any; res: any }, rawToken: string, expiresAt: Date) {
  ctx.res.cookie(LOCAL_SESSION_COOKIE, rawToken, {
    ...getSessionCookieOptions(ctx.req),
    sameSite: "lax",
    maxAge: Math.max(0, expiresAt.getTime() - Date.now()),
  });
}

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query((opts) => opts.ctx.user),
    register: publicProcedure.input(localAuthInput.extend({ name: z.string().trim().min(2).max(80) })).mutation(async ({ ctx, input }) => {
      const user = await createLocalAccount(input);
      if (!user) throw new TRPCError({ code: "CONFLICT", message: "An account already exists for this email address." });
      const session = await createLocalSession(user.id);
      setLocalSessionCookie(ctx, session.rawToken, session.expiresAt);
      return { success: true, user };
    }),
    login: publicProcedure.input(localAuthInput).mutation(async ({ ctx, input }) => {
      const user = await authenticateLocalAccount(input.email, input.password);
      if (!user) throw new TRPCError({ code: "UNAUTHORIZED", message: "Invalid email or password." });
      const session = await createLocalSession(user.id);
      setLocalSessionCookie(ctx, session.rawToken, session.expiresAt);
      return { success: true, user };
    }),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      void revokeLocalSession(getLocalSessionToken(ctx.req));
      ctx.res.clearCookie(LOCAL_SESSION_COOKIE, { ...cookieOptions, sameSite: "lax", maxAge: -1 });
      return { success: true } as const;
    }),
  }),
  public: publicRouter,
  player: playerRouter,
  admin: adminRouter,
});

export type AppRouter = typeof appRouter;
