import { TRPCError } from "@trpc/server";
import { eq } from "drizzle-orm";
import { adminActivity, platformSettings, users } from "../drizzle/schema";
import { getDb } from "./db";
import { storagePut } from "./storage";

export async function databaseOrThrow() {
  const db = await getDb();
  if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "The platform database is temporarily unavailable." });
  return db;
}

export async function requireActiveAccount(userId: number) {
  const db = await databaseOrThrow();
  const [account] = await db.select().from(users).where(eq(users.id, userId)).limit(1);
  if (!account) throw new TRPCError({ code: "UNAUTHORIZED", message: "Your account is not available." });
  if (account.isBlocked) throw new TRPCError({ code: "FORBIDDEN", message: "This account is currently restricted. Please contact support." });
  return account;
}

export async function requireActiveAdmin(userId: number) {
  const account = await requireActiveAccount(userId);
  if (account.role !== "admin") throw new TRPCError({ code: "FORBIDDEN", message: "Administrator access is required." });
  return account;
}

export async function writeAdminActivity(input: {
  actorId: number;
  action: string;
  targetType: string;
  targetId?: string | null;
  details?: string | null;
}) {
  const db = await databaseOrThrow();
  await db.insert(adminActivity).values(input);
}

export async function getSettingsMap() {
  const db = await databaseOrThrow();
  const rows = await db.select().from(platformSettings);
  return Object.fromEntries(rows.map((row) => [row.settingKey, row.settingValue ?? ""]));
}

export async function saveImageDataUrl(dataUrl: string, folder: "payments" | "platform" | "avatars", ownerId: number) {
  const match = dataUrl.match(/^data:(image\/(?:png|jpeg|webp));base64,([A-Za-z0-9+/=]+)$/);
  if (!match) throw new TRPCError({ code: "BAD_REQUEST", message: "Upload a PNG, JPEG, or WebP image." });

  const buffer = Buffer.from(match[2], "base64");
  if (!buffer.length || buffer.length > 4 * 1024 * 1024) {
    throw new TRPCError({ code: "PAYLOAD_TOO_LARGE", message: "Images must be smaller than 4 MB." });
  }

  const extensions: Record<string, string> = { "image/png": "png", "image/jpeg": "jpg", "image/webp": "webp" };
  const extension = extensions[match[1]];
  const timestamp = Date.now();
  return storagePut(`${folder}/${ownerId}/${timestamp}.${extension}`, buffer, match[1]);
}
