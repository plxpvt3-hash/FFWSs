import { createHash, randomBytes } from "crypto";
import { and, eq, gt, isNull } from "drizzle-orm";
import { localCredentials, localSessions, passwordResetTokens, users } from "../drizzle/schema";
import { getDb } from "./db";
import { hashPassword, normalizeEmail } from "./localAuth";

const RESET_TOKEN_DURATION_MS = 60 * 60 * 1000;

export function hashPasswordResetToken(token: string) {
  return createHash("sha256").update(token).digest("hex");
}

function resetSender() {
  const sender = process.env.RESEND_FROM_EMAIL?.trim();
  if (!sender) throw new Error("Password reset email sender is not configured");
  return sender;
}

async function sendPasswordResetEmail(input: { email: string; resetUrl: string }) {
  const apiKey = process.env.RESEND_API_KEY;
  if (!apiKey) throw new Error("Password reset email delivery is not configured");

  const response = await fetch("https://api.resend.com/emails", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${apiKey}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      from: resetSender(),
      to: [input.email],
      subject: "Reset your PLX Gaming password",
      text: `A password reset was requested for your PLX Gaming account. Reset your password within 60 minutes: ${input.resetUrl}\n\nIf you did not request this, you can safely ignore this email.`,
      html: `<p>A password reset was requested for your <strong>PLX Gaming</strong> account.</p><p><a href="${input.resetUrl}">Reset your password</a></p><p>This link expires in 60 minutes and can be used once. If you did not request this, you can safely ignore this email.</p>`,
    }),
  });

  const payload = await response.json().catch(() => null) as { id?: unknown; message?: unknown } | null;
  if (!response.ok) {
    const providerMessage = typeof payload?.message === "string" ? payload.message.slice(0, 180) : "no provider message";
    throw new Error(`Password reset email delivery failed with status ${response.status}: ${providerMessage}`);
  }

  const messageId = typeof payload?.id === "string" ? payload.id : "unavailable";
  const recipientDomain = input.email.split("@")[1] ?? "invalid-domain";
  console.info("[PasswordReset] Resend accepted reset email", { messageId, recipientDomain });
}

export async function requestPasswordReset(input: { email: string; resetUrlBase: string }) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");

  const email = normalizeEmail(input.email);
  const rows = await db.select({ userId: users.id, email: users.email })
    .from(users)
    .where(and(eq(users.email, email), eq(users.isBlocked, false)))
    .limit(1);
  const account = rows[0];
  if (!account?.email) return { requested: true } as const;

  const rawToken = randomBytes(32).toString("base64url");
  const expiresAt = new Date(Date.now() + RESET_TOKEN_DURATION_MS);
  await db.delete(passwordResetTokens).where(and(eq(passwordResetTokens.userId, account.userId), isNull(passwordResetTokens.usedAt)));
  await db.insert(passwordResetTokens).values({ userId: account.userId, tokenHash: hashPasswordResetToken(rawToken), expiresAt });

  const resetUrl = new URL("/reset-password", input.resetUrlBase);
  resetUrl.searchParams.set("token", rawToken);
  try {
    await sendPasswordResetEmail({ email: account.email, resetUrl: resetUrl.toString() });
  } catch (error) {
    await db.delete(passwordResetTokens).where(eq(passwordResetTokens.tokenHash, hashPasswordResetToken(rawToken)));
    throw error;
  }
  return { requested: true } as const;
}

export async function resetPasswordWithToken(input: { token: string; password: string }) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const tokenHash = hashPasswordResetToken(input.token);
  const passwordHash = await hashPassword(input.password);

  return db.transaction(async (tx) => {
    const rows = await tx.select({ id: passwordResetTokens.id, userId: passwordResetTokens.userId })
      .from(passwordResetTokens)
      .where(and(eq(passwordResetTokens.tokenHash, tokenHash), isNull(passwordResetTokens.usedAt), gt(passwordResetTokens.expiresAt, new Date())))
      .limit(1);
    const reset = rows[0];
    if (!reset) return false;

    await tx.insert(localCredentials).values({ userId: reset.userId, passwordHash })
      .onDuplicateKeyUpdate({ set: { passwordHash } });
    await tx.update(passwordResetTokens).set({ usedAt: new Date() }).where(eq(passwordResetTokens.id, reset.id));
    await tx.update(localSessions).set({ revokedAt: new Date() })
      .where(and(eq(localSessions.userId, reset.userId), isNull(localSessions.revokedAt)));
    return true;
  });
}
