import { describe, expect, it } from "vitest";
import { redactUnpublishedRoomCredentials, toPrivatePlayerProfile } from "./playerProfilePrivacy";

describe("private player profile serialization", () => {
  it("does not include account secrets in the player-visible profile payload", () => {
    const profile = toPrivatePlayerProfile({
      id: 27, name: "Account name", playerName: "PLX Rusher", gameUid: "123456789012", avatarUrl: null,
      createdAt: new Date("2026-08-19T00:00:00.000Z"),
      // Extra account-only fields intentionally cannot be returned by the serializer.
      email: "private@example.test", openId: "secret-open-id", isBlocked: false,
    } as never);
    expect(profile).toMatchObject({ playerId: "PLX-000027", playerName: "PLX Rusher", gameUid: "123456789012" });
    expect(profile).not.toHaveProperty("email");
    expect(profile).not.toHaveProperty("openId");
    expect(profile).not.toHaveProperty("isBlocked");
  });

  it("redacts room access until an administrator publishes it", () => {
    const restricted = redactUnpublishedRoomCredentials({ roomCredentialsPublished: false, roomId: "12345", roomPassword: "secret" });
    const published = redactUnpublishedRoomCredentials({ roomCredentialsPublished: true, roomId: "12345", roomPassword: "secret" });
    expect(restricted).toMatchObject({ roomId: null, roomPassword: null });
    expect(published).toMatchObject({ roomId: "12345", roomPassword: "secret" });
  });
});
