import { describe, expect, it } from "vitest";

describe("PLX password-reset email configuration", () => {
  it("authenticates the configured Resend credential against a lightweight provider endpoint", async () => {
    const apiKey = process.env.RESEND_API_KEY;
    const sender = process.env.RESEND_FROM_EMAIL;

    expect(apiKey, "RESEND_API_KEY must be configured server-side").toBeTruthy();
    expect(sender, "RESEND_FROM_EMAIL must be configured server-side").toMatch(/^[^\s@]+@[^\s@]+\.[^\s@]+$/);

    const response = await fetch("https://api.resend.com/domains", {
      headers: { Authorization: `Bearer ${apiKey}` },
    });

    expect(response.ok, `Resend credential check failed with HTTP ${response.status}`).toBe(true);
  }, 15_000);
});
