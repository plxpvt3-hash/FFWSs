import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

function playerContext(): TrpcContext {
  return {
    user: {
      id: 999,
      openId: "test-player",
      name: "Player",
      email: "player@example.com",
      loginMethod: "manus",
      role: "user",
      isBlocked: false,
      playerName: null,
      gameUid: null,
      avatarUrl: null,
      createdAt: new Date(),
      updatedAt: new Date(),
      lastSignedIn: new Date(),
    },
    req: {} as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };
}

describe("PLX administrator procedure boundary", () => {
  it("rejects a normal authenticated player before any administrator operation can run", async () => {
    const caller = appRouter.createCaller(playerContext());
    await expect(caller.admin.overview()).rejects.toMatchObject({ code: "FORBIDDEN" });
  });
});
