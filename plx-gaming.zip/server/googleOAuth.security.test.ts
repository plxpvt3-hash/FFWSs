import { describe, expect, it } from "vitest";
import { isSafeOAuthNextPath } from "./googleOAuth";

describe("Google OAuth redirect safety", () => {
  it("preserves a same-origin PLX destination", () => {
    expect(isSafeOAuthNextPath("/profile?tab=security", "/dashboard")).toBe("/profile?tab=security");
  });

  it("rejects absolute, protocol-relative, and backslash redirect destinations", () => {
    expect(isSafeOAuthNextPath("https://attacker.example", "/dashboard")).toBe("/dashboard");
    expect(isSafeOAuthNextPath("//attacker.example", "/dashboard")).toBe("/dashboard");
    expect(isSafeOAuthNextPath("/\\attacker.example", "/dashboard")).toBe("/dashboard");
  });

  it("uses the context-specific fallback when no destination is supplied", () => {
    expect(isSafeOAuthNextPath(undefined, "/profile")).toBe("/profile");
  });
});
