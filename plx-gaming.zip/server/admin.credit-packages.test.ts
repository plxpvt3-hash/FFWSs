import { beforeEach, describe, expect, it, vi } from "vitest";
import type { TrpcContext } from "./_core/context";

const mocks = vi.hoisted(() => ({
  databaseOrThrow: vi.fn(),
  requireActiveAdmin: vi.fn(),
  writeAdminActivity: vi.fn(),
}));

vi.mock("./platform", async (importOriginal) => {
  const actual = await importOriginal<typeof import("./platform")>();
  return { ...actual, ...mocks };
});

import { appRouter } from "./routers";

function queryResult(rows: unknown[]) {
  return {
    from: vi.fn().mockReturnValue({
      where: vi.fn().mockReturnValue({
        limit: vi.fn().mockResolvedValue(rows),
      }),
    }),
  };
}

function adminContext(): TrpcContext {
  return {
    user: {
      id: 44,
      openId: "package-admin",
      name: "PLX Administrator",
      email: "admin@plx.test",
      loginMethod: "email",
      role: "admin",
      isBlocked: false,
      playerName: null,
      gameUid: null,
      avatarUrl: null,
      createdAt: new Date(),
      updatedAt: new Date(),
      lastSignedIn: new Date(),
    },
    req: {} as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };
}

function createDatabase(hasPaymentHistory: boolean) {
  const deleteWhere = vi.fn().mockResolvedValue({ affectedRows: 1 });
  const updateWhere = vi.fn().mockResolvedValue({ affectedRows: 1 });
  const updateSet = vi.fn().mockReturnValue({ where: updateWhere });
  const database = {
    select: vi.fn()
      .mockReturnValueOnce(queryResult([{ id: 12 }]))
      .mockReturnValueOnce(queryResult(hasPaymentHistory ? [{ id: 77 }] : [])),
    delete: vi.fn().mockReturnValue({ where: deleteWhere }),
    update: vi.fn().mockReturnValue({ set: updateSet }),
  };
  return { database, deleteWhere, updateSet };
}

describe("admin.removeCreditPackage", () => {
  beforeEach(() => {
    vi.clearAllMocks();
    mocks.requireActiveAdmin.mockResolvedValue({ id: 44 });
    mocks.writeAdminActivity.mockResolvedValue(undefined);
  });

  it("deletes an unused package", async () => {
    const { database } = createDatabase(false);
    mocks.databaseOrThrow.mockResolvedValue(database);

    const result = await appRouter.createCaller(adminContext()).admin.removeCreditPackage({ id: 12 });

    expect(result).toEqual({ success: true, archived: false });
    expect(database.delete).toHaveBeenCalledTimes(1);
    expect(database.update).not.toHaveBeenCalled();
    expect(mocks.writeAdminActivity).toHaveBeenCalledWith(expect.objectContaining({ action: "credit_package.removed", targetId: "12" }));
  });

  it("archives a package with payment history rather than deleting it", async () => {
    const { database, updateSet } = createDatabase(true);
    mocks.databaseOrThrow.mockResolvedValue(database);

    const result = await appRouter.createCaller(adminContext()).admin.removeCreditPackage({ id: 12 });

    expect(result).toEqual({ success: true, archived: true });
    expect(database.delete).not.toHaveBeenCalled();
    expect(database.update).toHaveBeenCalledTimes(1);
    expect(updateSet).toHaveBeenCalledWith({ isActive: false });
    expect(mocks.writeAdminActivity).toHaveBeenCalledWith(expect.objectContaining({ action: "credit_package.archived", targetId: "12" }));
  });
});
