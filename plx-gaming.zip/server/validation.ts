import { TRPCError } from "@trpc/server";
import { z } from "zod";

export const playerNicknameSchema = z.string()
  .trim()
  .min(3, "Player Nickname must be at least 3 characters.")
  .max(32, "Player Nickname must be 32 characters or fewer.")
  .regex(/^[A-Za-z0-9][A-Za-z0-9 _.'-]*$/, "Use letters, numbers, spaces, apostrophes, periods, hyphens, or underscores only.");

export const freeFireUidSchema = z.string()
  .trim()
  .regex(/^\d{6,20}$/, "Free Fire Player UID must contain 6–20 digits only.");

export function createSlug(name: string) {
  const stem = name
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 72) || "plx-tournament";
  return `${stem}-${crypto.randomUUID().slice(0, 8)}`;
}

export function assertCreditsAmount(amount: number) {
  if (!Number.isInteger(amount) || amount === 0) {
    throw new TRPCError({ code: "BAD_REQUEST", message: "Enter a non-zero whole Credits amount." });
  }
}

export function assertTournamentCapacity(totalSlots: number, filledSlots: number) {
  if (totalSlots < filledSlots) {
    throw new TRPCError({ code: "BAD_REQUEST", message: "Total slots cannot be less than confirmed entries." });
  }
}
