export type ProfileMetricEntry = {
  entry: { status: string; rank: number | null; kills: number; score?: number; prizeAwarded: number };
  tournament: { status: string };
};

export function calculateProfileStats(entries: ProfileMetricEntry[]) {
  const registered = entries.filter((row) => row.entry.status === "registered");
  const results = registered.filter((row) => row.tournament.status === "completed" || row.entry.rank !== null);
  const ranked = results.filter((row) => row.entry.rank !== null);
  const tournamentsWon = results.filter((row) => row.entry.rank === 1).length;
  const matchesPlayed = results.length;
  return {
    totalTournaments: registered.length,
    tournamentsWon,
    matchesPlayed,
    totalKills: results.reduce((total, row) => total + row.entry.kills, 0),
    totalPrizeCredits: results.reduce((total, row) => total + row.entry.prizeAwarded, 0),
    winRate: matchesPlayed ? Math.round((tournamentsWon / matchesPlayed) * 1000) / 10 : 0,
    bestRank: ranked.length ? Math.min(...ranked.map((row) => row.entry.rank!)) : null,
  };
}
