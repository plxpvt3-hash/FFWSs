import { describe, expect, it } from "vitest";
import { hashPassword, normalizeEmail, verifyPassword } from "./localAuth";

describe("PLX local email-password authentication", () => {
  it("normalizes email addresses before database lookups", () => {
    expect(normalizeEmail("  PLAYER@PLX.GG ")).toBe("player@plx.gg");
  });

  it("stores a salted scrypt password hash that accepts only the original password", async () => {
    const hash = await hashPassword("safe-player-password");
    expect(hash).toMatch(/^scrypt\$[^$]+\$[^$]+$/);
    await expect(verifyPassword("safe-player-password", hash)).resolves.toBe(true);
    await expect(verifyPassword("wrong-password", hash)).resolves.toBe(false);
  });

  it("rejects malformed stored password values", async () => {
    await expect(verifyPassword("any-password", "malformed")).resolves.toBe(false);
  });
});

