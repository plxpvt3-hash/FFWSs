export function isSafeHomeFooterDestination(value: string) {
  const destination = value.trim();
  if (!destination) return false;
  if (destination.startsWith("/") && !destination.startsWith("//")) return true;

  try {
    const protocol = new URL(destination).protocol;
    return protocol === "https:" || protocol === "http:";
  } catch {
    return false;
  }
}
